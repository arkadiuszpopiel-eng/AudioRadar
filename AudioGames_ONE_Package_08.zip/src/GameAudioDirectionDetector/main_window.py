from PyQt5 import QtCore, QtWidgets, QtGui
from .audio_engine import AudioEngine, RunMode
from .widgets import PointRadarWidget, LedBarsWidget
# Optional psutil import for auto game detection; if unavailable the feature
# will be disabled gracefully.
try:
    import psutil
except Exception:
    psutil = None

class MainWindow(QtWidgets.QMainWindow):
    """
    Main application window.  This class is responsible for loading the
    configuration from the provided ``settings_path``, instantiating the audio
    engine, positioning and sizing the floating widgets, and wiring up UI
    controls and keyboard shortcuts.

    The ``settings.json`` file can define default run mode, widget
    visibility, position, size and opacity.  See the project documentation
    for the full schema.
    """
    def __init__(self, settings_path, demo_default=True, autowidgets=True):
        super().__init__()

        # Remember where to save configuration
        self._settings_path = settings_path
        # Load configuration from the JSON file on disk.  Missing values will
        # fall back to the parameters passed into this constructor.  Any
        # exception during loading is ignored and the defaults are used.
        cfg = {}
        try:
            import json, os
            if settings_path and os.path.isfile(settings_path):
                with open(settings_path, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
        except Exception:
            cfg = {}

        # Determine whether demo mode should be the default and whether to
        # automatically display floating widgets on start.  Values from the
        # configuration file override function arguments when present.
        ui_cfg = cfg.get('ui', {}) if isinstance(cfg.get('ui', {}), dict) else {}
        demo_default = bool(ui_cfg.get('demo_default', demo_default))
        autowidgets  = bool(ui_cfg.get('autowidgets', autowidgets))
        # Read HUD profile preference (``cinematic`` or ``ambient``).  If
        # unspecified or invalid, fall back to ``cinematic``.  This value
        # controls the colour palette used by the floating widgets.
        profile = str(ui_cfg.get('profile', 'cinematic')).strip().lower()
        if profile not in ('cinematic', 'ambient'):
            profile = 'cinematic'

        # Read audio configuration early so ``layout`` and ``scout_mode`` are defined
        audio_cfg = cfg.get('audio', {}) if isinstance(cfg.get('audio', {}), dict) else {}
        fs = int(audio_cfg.get('fs', 48000))
        blocksize = int(audio_cfg.get('blocksize', 1024))
        layout = str(audio_cfg.get('layout', 'auto')).lower()
        scout_mode = bool(audio_cfg.get('scout_mode', False))
        # Read gating sensitivity factor; default 0.30.  Values outside 0–1
        # are clamped later when applied to the engine.
        try:
            gate_factor = float(audio_cfg.get('gate_factor', 0.30))
        except Exception:
            gate_factor = 0.30

        # Read adaptive gating flag.  When true the audio engine will
        # dynamically adjust the gate factor to maintain a consistent
        # detection rate based on observed background noise.  If
        # unspecified, adaptive gating is disabled by default.
        adaptive_gate = bool(audio_cfg.get('adaptive_gate', False))

        # Read the stored input and output device indices/names if present.  These
        # values will be used to preselect the input and output devices in the
        # combo boxes.  They are stored on the instance for later use in
        # ``_populate_devices``.  If not present or invalid, ``None`` is used.
        try:
            in_dev = audio_cfg.get('input_device', None)
        except Exception:
            in_dev = None
        self._stored_input_device = in_dev
        try:
            out_dev = audio_cfg.get('output_device', None)
        except Exception:
            out_dev = None
        self._stored_output_device = out_dev
        # Read the auto game detection flag.  When true a timer will run to
        # periodically inspect running processes and switch modes when a
        # recognised game is found.
        auto_game_detect = bool(audio_cfg.get('auto_game_detect', False))
        # Load custom game process identifiers.  Users can specify a list of
        # substrings in ``audio.game_processes`` within the configuration
        # file.  These strings are matched case‑insensitively against
        # running process names and executable paths when auto game
        # detection is enabled.  If no custom list is provided the
        # application uses a built‑in set of common game process names.
        try:
            gp = audio_cfg.get('game_processes', [])
            if isinstance(gp, (list, tuple)):
                self._game_processes = [str(x).strip().lower() for x in gp if x]
            else:
                self._game_processes = []
        except Exception:
            self._game_processes = []

        # Window setup
        self.setWindowTitle('AudioGames ONE — PRO AUDIO WIDGET (v9.9.32)')
        self.resize(1080, 720)
        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)

        # Build the preview tab with check boxes and a mode selector
        tprev = QtWidgets.QWidget()
        vp = QtWidgets.QFormLayout(tprev)
        self.chkRadar = QtWidgets.QCheckBox('Radar (floating)')
        self.chkLeds  = QtWidgets.QCheckBox('LED Bars (floating)')
        self.cmbMode  = QtWidgets.QComboBox()
        self.cmbMode.addItems(['DEMO', 'REAL'])
        self.cmbMode.setCurrentIndex(0 if demo_default else 1)
        # Split device selection into input (capture) and output (playback)
        self.cmbInputDevice = QtWidgets.QComboBox()
        self.cmbOutputDevice = QtWidgets.QComboBox()
        # Populate both combo boxes with available devices
        self._populate_devices()
        # Layout selection combo box
        self.cmbLayout = QtWidgets.QComboBox()
        # Provide layout options: AUTO detects number of channels from device; STEREO forces first 2; 5.1 forces 6; 7.1 forces 8
        self.cmbLayout.addItems(['AUTO', 'STEREO', '5.1', '7.1'])
        # Determine initial layout from configuration
        try:
            layout_map = {'auto': 0, 'stereo': 1, '5.1': 2, '7.1': 3}
            self.cmbLayout.setCurrentIndex(layout_map.get(layout, 0))
        except Exception:
            self.cmbLayout.setCurrentIndex(0)
        # Scout Mode checkbox
        self.chkScout = QtWidgets.QCheckBox('Scout Mode')
        self.chkScout.setChecked(scout_mode)
        # initial visibility for checkboxes
        self.chkRadar.setChecked(True)
        self.chkLeds.setChecked(True)
        vp.addRow(self.chkRadar)
        vp.addRow(self.chkLeds)
        vp.addRow('Tryb', self.cmbMode)
        vp.addRow('Wejście audio', self.cmbInputDevice)
        vp.addRow('Wyjście audio', self.cmbOutputDevice)
        vp.addRow('Układ', self.cmbLayout)
        vp.addRow(self.chkScout)
        # HUD profile selection combo box
        self.cmbProfile = QtWidgets.QComboBox()
        self.cmbProfile.addItems(['Cinematic', 'Ambient'])
        try:
            prof_map = {'cinematic': 0, 'ambient': 1}
            self.cmbProfile.setCurrentIndex(prof_map.get(profile, 0))
        except Exception:
            self.cmbProfile.setCurrentIndex(0)
        vp.addRow('Profil HUD', self.cmbProfile)
        # Save settings button
        self.btnSave = QtWidgets.QPushButton('Zapisz ustawienia')
        vp.addRow(self.btnSave)
        self.btnSave.clicked.connect(self._save_settings)

        # Calibration reset button
        self.btnCalibrate = QtWidgets.QPushButton('Reset kalibracji')
        vp.addRow(self.btnCalibrate)
        self.btnCalibrate.clicked.connect(self._reset_calibration)

        # Gating sensitivity slider.  Allows the user to adjust how
        # aggressively the noise gate suppresses weak signals when in
        # REAL mode.  A lower value makes the gate more permissive,
        # letting quieter sounds through; a higher value makes it stricter.
        self.sliderGate = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sliderGate.setRange(0, 100)
        try:
            self.sliderGate.setValue(int(max(0, min(100, gate_factor * 100))))
        except Exception:
            self.sliderGate.setValue(30)
        vp.addRow('Czułość bramkowania', self.sliderGate)
        self.sliderGate.valueChanged.connect(self._on_gate_factor_changed)

        # Adaptive gating checkbox.  When checked the engine will
        # automatically adjust the gate factor to maintain a target ratio
        # of silence frames.  The initial state is read from the
        # configuration file.
        self.chkAdaptiveGate = QtWidgets.QCheckBox('Adaptacyjne bramkowanie')
        self.chkAdaptiveGate.setChecked(adaptive_gate)
        vp.addRow(self.chkAdaptiveGate)
        self.chkAdaptiveGate.toggled.connect(self._on_adaptive_gate_changed)
        # Auto game detection checkbox and timer.  This checkbox enables a timer
        # that periodically scans running processes for known games.  When a
        # recognised game is detected the application switches to REAL mode.
        self.chkAutoGame = QtWidgets.QCheckBox('Auto detekcja gry')
        self.chkAutoGame.setChecked(auto_game_detect)
        vp.addRow(self.chkAutoGame)
        # Create the timer but do not start it yet; it will be started when
        # the checkbox is toggled on.
        self._game_timer = QtCore.QTimer(self)
        self._game_timer.setInterval(5000)  # 5 seconds
        self._game_timer.timeout.connect(self._check_for_games)
        # Add the preview tab now that all controls have been added
        self.tabs.addTab(tprev, 'Widget Preview')

        # Channel activity display.  This label shows which audio channels
        # currently contain significant signal.  Each entry consists of a
        # channel name followed by a filled (●) or empty (○) bullet to
        # indicate activity.  The label is updated periodically in
        # ``_ui_update``.  The row is added after the auto game detection
        # checkbox so that it appears near related audio controls.
        self.lblChannelActivity = QtWidgets.QLabel('brak danych')
        vp.addRow('Aktywne kanały', self.lblChannelActivity)


        # Instantiate the audio engine using settings from the config
        # The ``fs``, ``blocksize``, ``layout`` and ``scout_mode`` variables were
        # read earlier in this constructor.  They are used here to configure
        # the engine.  Note: variables are explicitly referenced to avoid
        # accidental shadowing in local scope.
        # Create the audio engine without specifying a capture device or
        # output device initially.  These will be set based on the
        # currently selected items in the input/output combo boxes below.
        self.eng = AudioEngine(
            fs=fs,
            blocksize=blocksize,
            layout=layout,
            scout_mode=scout_mode,
            gate_factor=gate_factor,
            # Use stored input device if provided; otherwise default to None.  The
            # engine will set the device in ``_on_input_device_changed`` when
            # populating devices.
            device=self._stored_input_device,
            output_device=self._stored_output_device
            , adaptive_gate=adaptive_gate
        )
        self.eng.on_detect(self.on_dets)
        # Apply selected devices to the engine before starting it.
        try:
            dev_idx = self.cmbInputDevice.itemData(self.cmbInputDevice.currentIndex())
            self.eng.set_device(dev_idx)
        except Exception:
            pass
        try:
            out_idx = self.cmbOutputDevice.itemData(self.cmbOutputDevice.currentIndex())
            self.eng.set_output_device(out_idx)
        except Exception:
            pass
        # Apply device-specific profile based on the currently selected input
        # device name.  This may adjust layout and gating factor for
        # recognised devices (e.g., Sound Blaster Z SE).  Apply after both
        # devices have been set to ensure the profile is not overwritten.
        try:
            dev_name = str(self.cmbInputDevice.currentText())
            self._apply_device_profiles(dev_name)
        except Exception:
            pass

        # Create the floating widgets
        self.radar = PointRadarWidget()
        self.leds  = LedBarsWidget()

        # Apply HUD profile to widgets before configuration; this ensures
        # their initial colours reflect the chosen palette.  The profile
        # string was determined earlier from the configuration file.
        try:
            self.radar.set_profile(profile)
            self.leds.set_profile(profile)
        except Exception:
            pass

        # Register callbacks so that when the widgets are moved via drag and drop
        # the customisation controls are synchronised to their new positions.  The
        # callbacks call helper methods defined later in this class.
        self.radar.drag_finished_callback = lambda w: self._update_radar_controls()
        self.leds.drag_finished_callback  = lambda w: self._update_led_controls()
        # Register callbacks for resize completion so that size controls
        # update after interactive resizing via the bottom‑right handle.
        self.radar.resize_finished_callback = lambda w: self._update_radar_controls()
        self.leds.resize_finished_callback  = lambda w: self._update_led_controls()

        # Apply configuration for radar and LED widgets.  If no
        # configuration exists, derive sensible defaults based on the
        # primary screen resolution so that the widgets are appropriately
        # sized and positioned on ultrawide and standard monitors.
        w_cfg = cfg.get('widgets', {}) if isinstance(cfg.get('widgets', {}), dict) else {}
        radar_cfg = w_cfg.get('radar', {}) if isinstance(w_cfg.get('radar', {}), dict) else {}
        leds_cfg  = w_cfg.get('leds', {}) if isinstance(w_cfg.get('leds', {}), dict) else {}
        # Determine primary screen size
        try:
            scr = QtWidgets.QApplication.primaryScreen()
            geo = scr.availableGeometry() if scr else None
            sw = geo.width() if geo else 1920
            sh = geo.height() if geo else 1080
        except Exception:
            sw, sh = 1920, 1080
        # Compute default sizes and positions based on screen size
        def_r_size = max(160, int(min(sw, sh) * 0.15))
        def_l_width = max(200, int(sw * 0.30))
        def_l_height = max(100, int(sh * 0.08))
        def_r_x = int(sw * 0.05)
        def_r_y = int(sh * 0.65)
        def_l_x = int(sw * 0.65)
        def_l_y = int(sh * 0.05)
        # Radar configuration
        if radar_cfg:
            try:
                x = int(radar_cfg.get('x', def_r_x))
                y = int(radar_cfg.get('y', def_r_y))
                size = int(radar_cfg.get('size', def_r_size))
                self.radar.move(x, y)
                self.radar.resize(size, size)
            except Exception:
                pass
            try:
                op = float(radar_cfg.get('opacity', self.radar._opacity))
                self.radar.set_opacity(op)
            except Exception:
                pass
            if radar_cfg.get('visible', True) is False:
                self.chkRadar.setChecked(False)
        else:
            # No configuration: set defaults
            try:
                self.radar.resize(def_r_size, def_r_size)
                self.radar.move(def_r_x, def_r_y)
            except Exception:
                pass
        # LED configuration
        if leds_cfg:
            try:
                x = int(leds_cfg.get('x', def_l_x))
                y = int(leds_cfg.get('y', def_l_y))
                w = int(leds_cfg.get('w', def_l_width))
                h = int(leds_cfg.get('h', def_l_height))
                self.leds.move(x, y)
                self.leds.resize(w, h)
            except Exception:
                pass
            try:
                op = float(leds_cfg.get('opacity', self.leds._opacity))
                self.leds.set_opacity(op)
            except Exception:
                pass
            if leds_cfg.get('visible', True) is False:
                self.chkLeds.setChecked(False)
        else:
            try:
                self.leds.resize(def_l_width, def_l_height)
                self.leds.move(def_l_x, def_l_y)
            except Exception:
                pass

        # ------------------------------------------------------------------
        # Customisation controls for the floating widgets.  Each widget has
        # sliders for size and opacity, as well as spin boxes for its
        # position (X/Y).  Adjusting these controls updates the floating
        # widgets in real time.  Initial values come from the configuration
        # dictionaries ``radar_cfg`` and ``leds_cfg`` above.
        # Radar customisation group
        radar_settings = QtWidgets.QGroupBox('Ustawienia radaru')
        radar_layout = QtWidgets.QFormLayout(radar_settings)
        # Size slider (160–800)
        self.radarSizeSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.radarSizeSlider.setRange(160, 800)
        rs = int(radar_cfg.get('size', self.radar.width()))
        self.radarSizeSlider.setValue(rs)
        radar_layout.addRow('Rozmiar', self.radarSizeSlider)
        # Opacity slider (10–100 → 0.1–1.0)
        self.radarOpacitySlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.radarOpacitySlider.setRange(10, 100)
        rop = float(radar_cfg.get('opacity', self.radar._opacity))
        self.radarOpacitySlider.setValue(int(max(10, min(100, rop * 100))))
        radar_layout.addRow('Przezroczystość', self.radarOpacitySlider)
        # Position spin boxes
        self.radarXSpin = QtWidgets.QSpinBox(); self.radarYSpin = QtWidgets.QSpinBox()
        self.radarXSpin.setRange(0, 5000); self.radarYSpin.setRange(0, 5000)
        self.radarXSpin.setValue(int(radar_cfg.get('x', self.radar.x())))
        self.radarYSpin.setValue(int(radar_cfg.get('y', self.radar.y())))
        radar_layout.addRow('Pozycja X', self.radarXSpin)
        radar_layout.addRow('Pozycja Y', self.radarYSpin)
        # Connect signals
        self.radarSizeSlider.valueChanged.connect(self._on_radar_size_changed)
        self.radarOpacitySlider.valueChanged.connect(self._on_radar_opacity_changed)
        self.radarXSpin.valueChanged.connect(self._on_radar_position_changed)
        self.radarYSpin.valueChanged.connect(self._on_radar_position_changed)
        vp.addRow(radar_settings)

        # LED bars customisation group
        leds_settings = QtWidgets.QGroupBox('Ustawienia belki LED')
        leds_layout = QtWidgets.QFormLayout(leds_settings)
        # Width and height sliders
        self.ledWidthSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        # Increase the width range to accommodate ultrawide monitors.  The
        # slider now spans 200–2000 pixels; the LED widget itself enforces
        # its own minimum size.
        self.ledWidthSlider.setRange(200, 4000)
        lw = int(leds_cfg.get('w', self.leds.width()))
        self.ledWidthSlider.setValue(lw)
        leds_layout.addRow('Szerokość', self.ledWidthSlider)
        self.ledHeightSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        # Increase the height range to allow taller LED bars.  The slider
        # now spans 100–1200 pixels.
        self.ledHeightSlider.setRange(100, 2000)
        lh = int(leds_cfg.get('h', self.leds.height()))
        self.ledHeightSlider.setValue(lh)
        leds_layout.addRow('Wysokość', self.ledHeightSlider)
        # Opacity slider for LEDs
        self.ledOpacitySlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.ledOpacitySlider.setRange(10, 100)
        lop = float(leds_cfg.get('opacity', self.leds._opacity))
        self.ledOpacitySlider.setValue(int(max(10, min(100, lop * 100))))
        leds_layout.addRow('Przezroczystość', self.ledOpacitySlider)
        # Position spin boxes
        self.ledXSpin = QtWidgets.QSpinBox(); self.ledYSpin = QtWidgets.QSpinBox()
        self.ledXSpin.setRange(0, 5000); self.ledYSpin.setRange(0, 5000)
        self.ledXSpin.setValue(int(leds_cfg.get('x', self.leds.x())))
        self.ledYSpin.setValue(int(leds_cfg.get('y', self.leds.y())))
        leds_layout.addRow('Pozycja X', self.ledXSpin)
        leds_layout.addRow('Pozycja Y', self.ledYSpin)
        # Connect signals
        self.ledWidthSlider.valueChanged.connect(self._on_led_size_changed)
        self.ledHeightSlider.valueChanged.connect(self._on_led_size_changed)
        self.ledOpacitySlider.valueChanged.connect(self._on_led_opacity_changed)
        self.ledXSpin.valueChanged.connect(self._on_led_position_changed)
        self.ledYSpin.valueChanged.connect(self._on_led_position_changed)
        vp.addRow(leds_settings)

        # Show widgets automatically according to autowidgets flag
        if autowidgets:
            if self.chkRadar.isChecked():
                self.radar.show()
            if self.chkLeds.isChecked():
                self.leds.show()

        # Connect UI signals
        self.chkRadar.toggled.connect(lambda on: (self.radar.show() if on else self.radar.hide()))
        self.chkLeds.toggled.connect(lambda on: (self.leds.show() if on else self.leds.hide()))
        self.cmbMode.currentIndexChanged.connect(self.set_mode)
        self.cmbInputDevice.currentIndexChanged.connect(self._on_input_device_changed)
        self.cmbOutputDevice.currentIndexChanged.connect(self._on_output_device_changed)
        self.cmbLayout.currentIndexChanged.connect(self._on_layout_changed)
        self.chkScout.toggled.connect(self._on_scout_changed)
        self.cmbProfile.currentIndexChanged.connect(self._on_profile_changed)
        # Connect auto game detection toggle
        self.chkAutoGame.toggled.connect(self._on_auto_game_detect_toggled)

        # If auto game detection was enabled in the configuration, start the
        # timer now.  Simply setting ``chkAutoGame`` to checked does not
        # trigger the toggled signal after the connection is made.
        try:
            if auto_game_detect and psutil is not None:
                self._on_auto_game_detect_toggled(True)
        except Exception:
            pass

        # Setup keyboard shortcuts for quick toggles
        self._setup_shortcuts()

        # The audio engine has already been started earlier when applying selected devices.
        # Do not call set_mode here again to prevent restarting the engine.

        # ------------------------------------------------------------------
        # Customisation tab
        #
        # Provide UI controls that allow the user to adjust the position,
        # size and opacity of the floating widgets at runtime.  These
        # controls live on their own tab so that they do not clutter the
        # preview page.  Each control is initialised with the current
        # settings of the corresponding widget.  When values are changed
        # the floating widgets are updated immediately.  Users can still
        # drag the windows manually if desired; there is no automatic
        # synchronisation from widget movement back into the controls.
        ctab = QtWidgets.QWidget()
        clayout = QtWidgets.QVBoxLayout(ctab)

        # Radar customisation group
        grp_radar = QtWidgets.QGroupBox('Ustawienia radaru')
        form_radar = QtWidgets.QFormLayout(grp_radar)
        # X coordinate
        self.spinRadarX = QtWidgets.QSpinBox()
        self.spinRadarX.setRange(0, 10000)
        self.spinRadarX.setValue(self.radar.x())
        self.spinRadarX.valueChanged.connect(lambda v: self._on_radar_pos_changed(v, None))
        # Y coordinate
        self.spinRadarY = QtWidgets.QSpinBox()
        self.spinRadarY.setRange(0, 10000)
        self.spinRadarY.setValue(self.radar.y())
        self.spinRadarY.valueChanged.connect(lambda v: self._on_radar_pos_changed(None, v))
        # Size (square)
        self.spinRadarSize = QtWidgets.QSpinBox()
        self.spinRadarSize.setRange(50, 2000)
        self.spinRadarSize.setValue(self.radar.width())
        self.spinRadarSize.valueChanged.connect(self._on_radar_size_changed)
        # Opacity slider (0–100)
        self.sliderRadarOp = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sliderRadarOp.setRange(0, 100)
        self.sliderRadarOp.setValue(int(self.radar._opacity * 100.0))
        # Connect directly to the opacity handler with the slider value (0–100)
        self.sliderRadarOp.valueChanged.connect(lambda v: self._on_radar_opacity_changed(v))
        # Add radar controls to form
        form_radar.addRow('Pozycja X', self.spinRadarX)
        form_radar.addRow('Pozycja Y', self.spinRadarY)
        form_radar.addRow('Rozmiar', self.spinRadarSize)
        form_radar.addRow('Przezroczystość', self.sliderRadarOp)
        clayout.addWidget(grp_radar)

        # LED bars customisation group
        grp_led = QtWidgets.QGroupBox('Ustawienia pasków LED')
        form_led = QtWidgets.QFormLayout(grp_led)
        # X coordinate
        self.spinLedX = QtWidgets.QSpinBox()
        self.spinLedX.setRange(0, 10000)
        self.spinLedX.setValue(self.leds.x())
        self.spinLedX.valueChanged.connect(lambda v: self._on_led_pos_changed(v, None))
        # Y coordinate
        self.spinLedY = QtWidgets.QSpinBox()
        self.spinLedY.setRange(0, 10000)
        self.spinLedY.setValue(self.leds.y())
        self.spinLedY.valueChanged.connect(lambda v: self._on_led_pos_changed(None, v))
        # Width
        self.spinLedW = QtWidgets.QSpinBox()
        self.spinLedW.setRange(50, 4000)
        self.spinLedW.setValue(self.leds.width())
        self.spinLedW.valueChanged.connect(lambda v: self._on_led_size_changed(v, None))
        # Height
        self.spinLedH = QtWidgets.QSpinBox()
        self.spinLedH.setRange(50, 2000)
        self.spinLedH.setValue(self.leds.height())
        self.spinLedH.valueChanged.connect(lambda v: self._on_led_size_changed(None, v))
        # Opacity slider
        self.sliderLedOp = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sliderLedOp.setRange(0, 100)
        self.sliderLedOp.setValue(int(self.leds._opacity * 100.0))
        # Connect directly to the opacity handler with the slider value (0–100)
        self.sliderLedOp.valueChanged.connect(lambda v: self._on_led_opacity_changed(v))
        # Segment count spin boxes.  Allow adjustment of the number of
        # segments for each edge independently.  Values are clamped to
        # between 1 and 20.
        self.spinLedSegTop = QtWidgets.QSpinBox()
        self.spinLedSegTop.setRange(1, 20)
        self.spinLedSegTop.setValue(len(self.leds.energy.get('top', [])))
        self.spinLedSegTop.valueChanged.connect(lambda v: self._on_led_segments_changed())
        self.spinLedSegBottom = QtWidgets.QSpinBox()
        self.spinLedSegBottom.setRange(1, 20)
        self.spinLedSegBottom.setValue(len(self.leds.energy.get('bottom', [])))
        self.spinLedSegBottom.valueChanged.connect(lambda v: self._on_led_segments_changed())
        self.spinLedSegLeft = QtWidgets.QSpinBox()
        self.spinLedSegLeft.setRange(1, 20)
        self.spinLedSegLeft.setValue(len(self.leds.energy.get('left', [])))
        self.spinLedSegLeft.valueChanged.connect(lambda v: self._on_led_segments_changed())
        self.spinLedSegRight = QtWidgets.QSpinBox()
        self.spinLedSegRight.setRange(1, 20)
        self.spinLedSegRight.setValue(len(self.leds.energy.get('right', [])))
        self.spinLedSegRight.valueChanged.connect(lambda v: self._on_led_segments_changed())
        # Add LED controls to form
        form_led.addRow('Pozycja X', self.spinLedX)
        form_led.addRow('Pozycja Y', self.spinLedY)
        form_led.addRow('Szerokość', self.spinLedW)
        form_led.addRow('Wysokość', self.spinLedH)
        form_led.addRow('Przezroczystość', self.sliderLedOp)
        form_led.addRow('Segmenty góra', self.spinLedSegTop)
        form_led.addRow('Segmenty dół', self.spinLedSegBottom)
        form_led.addRow('Segmenty lewa', self.spinLedSegLeft)
        form_led.addRow('Segmenty prawa', self.spinLedSegRight)
        clayout.addWidget(grp_led)
        clayout.addStretch(1)
        # Add the customisation tab to the tab widget
        self.tabs.addTab(ctab, 'Ustawienia widżetów')

        # ------------------------------------------------------------------
        # Sound card profiles tab
        #
        # Provide a separate tab that allows the user to select a preset
        # configuration for specific audio devices and manually tune
        # gating sensitivity and channel layout.  This tab contains its
        # own controls and applies settings immediately.  The chosen
        # profile settings are not automatically saved; users can save
        # them via the general "Zapisz ustawienia" button on the preview
        # tab if desired.
        card_tab = QtWidgets.QWidget()
        card_layout = QtWidgets.QVBoxLayout(card_tab)
        grp_card = QtWidgets.QGroupBox('Profil karty dźwiękowej')
        form_card = QtWidgets.QFormLayout(grp_card)
        # Profile selection combo box
        self.cmbCardProfile = QtWidgets.QComboBox()
        self.cmbCardProfile.addItems(['AUTO', 'Sound Blaster Z SE', 'Realtek ALC1220', 'Inny'])
        self.cmbCardProfile.currentIndexChanged.connect(self._on_card_profile_changed)
        # Gating sensitivity slider (0–100)
        self.sliderCardGate = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sliderCardGate.setRange(0, 100)
        self.sliderCardGate.setValue(int(getattr(self.eng, 'gate_factor', 0.3) * 100.0))
        self.sliderCardGate.valueChanged.connect(self._on_card_gate_factor_changed)
        # Layout selection (AUTO/STEREO/5.1/7.1)
        self.cmbCardLayout = QtWidgets.QComboBox()
        self.cmbCardLayout.addItems(['AUTO', 'STEREO', '5.1', '7.1'])
        try:
            # Attempt to copy current layout from preview drop-down if available
            self.cmbCardLayout.setCurrentIndex(self.cmbLayout.currentIndex())
        except Exception:
            self.cmbCardLayout.setCurrentIndex(0)
        self.cmbCardLayout.currentIndexChanged.connect(self._on_card_layout_changed)
        # Add controls to form
        form_card.addRow('Profil', self.cmbCardProfile)
        form_card.addRow('Bramkowanie', self.sliderCardGate)
        form_card.addRow('Układ kanałów', self.cmbCardLayout)
        card_layout.addWidget(grp_card)
        card_layout.addStretch(1)
        # Add the new tab to the tab widget
        self.tabs.addTab(card_tab, 'Karty dźwiękowe')
        # Start a UI update timer to avoid widgets freezing when no detections occur.
        self._ui_timer = QtCore.QTimer(self)
        self._ui_timer.setInterval(50)
        self._ui_timer.timeout.connect(self._ui_update)
        self._ui_timer.start()
        # State tracking for LED full‑screen mode.
        self._led_fullscreen = False
        self._led_prev_geom = None

    def set_mode(self):
        m = RunMode.DEMO if self.cmbMode.currentIndex()==0 else RunMode.REAL
        self.eng.stop(); self.eng.set_run_mode(m); self.eng.start()

    def on_dets(self, dets):
        if dets:
            a=float(dets[0].get('angle_deg',0.0)); lvl=float(dets[0].get('level_db',-60.0))
        else:
            a,lvl=0.0,-60.0
        self.radar.update_detection(a,lvl); self.leds.update_energy(dets,lvl)

    def _setup_shortcuts(self):
        """
        Install global keyboard shortcuts to allow quick toggling of the
        radar and LED widgets as well as switching between demo and real
        modes.  These shortcuts operate even when the main window does not
        have focus (floating widgets won't capture keyboard focus).
        
        * F1 – Toggle the radar widget on/off.
        * F2 – Toggle the LED bars on/off.
        * F3 – Switch between DEMO and REAL modes.
        * F4 – Toggle between HUD colour profiles (Cinematic/Ambient).
        """
        # Toggle radar visibility
        QtWidgets.QShortcut(QtGui.QKeySequence('F1'), self, activated=lambda: self.chkRadar.toggle())
        # Toggle LED visibility
        QtWidgets.QShortcut(QtGui.QKeySequence('F2'), self, activated=lambda: self.chkLeds.toggle())
        # Switch run mode
        QtWidgets.QShortcut(QtGui.QKeySequence('F3'), self, activated=self._toggle_mode)
        # Toggle HUD profile
        QtWidgets.QShortcut(QtGui.QKeySequence('F4'), self, activated=self._toggle_profile)
        # Toggle LED full‑screen mode
        QtWidgets.QShortcut(QtGui.QKeySequence('F5'), self, activated=self._toggle_led_fullscreen)

    def _toggle_mode(self):
        """Internal helper to toggle between DEMO and REAL run modes."""
        idx = self.cmbMode.currentIndex()
        self.cmbMode.setCurrentIndex(1 - idx)

    # ------------------------------------------------------------------
    # HUD profile management
    def _toggle_profile(self):
        """
        Toggle between the Cinematic and Ambient HUD colour profiles.  This
        method is invoked via the F4 keyboard shortcut.  It updates the
        profile combo box, which in turn triggers ``_on_profile_changed`` to
        apply the new palette to the floating widgets.
        """
        try:
            idx = self.cmbProfile.currentIndex()
            # Only two profiles are supported; wrap index
            self.cmbProfile.setCurrentIndex(1 - idx)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Gating sensitivity management
    def _on_gate_factor_changed(self, value: int) -> None:
        """
        Update the gating factor used by the audio engine.  The slider
        supplies integer values in the range 0–100; these are mapped to
        0.0–1.0 and clamped.  A smaller factor makes the noise gate
        more permissive, while a larger factor requires stronger
        signals to register as detections.  Changes apply immediately
        without restarting the engine.
        """
        try:
            v = float(value)
            v = max(0.0, min(100.0, v))
            gf = v / 100.0
            # Clamp to [0.0, 1.0]
            gf = max(0.0, min(1.0, gf))
            self.eng.gate_factor = gf
        except Exception:
            pass

    def _on_profile_changed(self, index: int) -> None:
        """
        Apply the selected HUD colour profile to both floating widgets.
        The combo box stores human‑readable names ('Cinematic', 'Ambient');
        these are mapped to lowercase identifiers used by the widgets.
        """
        try:
            mapping = ['cinematic', 'ambient']
            if 0 <= index < len(mapping):
                new_profile = mapping[index]
            else:
                new_profile = 'cinematic'
            self.radar.set_profile(new_profile)
            self.leds.set_profile(new_profile)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Sound card profile management
    def _on_card_profile_changed(self, index: int) -> None:
        """
        Apply a preset based on the selected audio hardware profile.  This
        convenience method adjusts the layout and gating sensitivity to
        reasonable defaults for known hardware.  Selecting "AUTO" or
        "Inny" leaves existing settings unchanged.  After applying the
        preset the corresponding UI controls are updated and the engine
        settings take effect immediately.
        """
        try:
            name = self.cmbCardProfile.currentText().strip().lower()
            if 'sound blaster z' in name or 'z se' in name:
                # Use 5.1 layout and a moderate gate factor for the Sound Blaster Z SE
                self.cmbCardLayout.setCurrentIndex(2)  # 5.1
                self.sliderCardGate.setValue(35)
            elif 'realtek' in name:
                # Typical Realtek ALC1220 layout is stereo with conservative gate
                self.cmbCardLayout.setCurrentIndex(1)  # STEREO
                self.sliderCardGate.setValue(30)
            else:
                # For AUTO or unknown profiles, leave current selections
                pass
            # Apply card gate and layout changes
            self._on_card_gate_factor_changed(self.sliderCardGate.value())
            self._on_card_layout_changed(self.cmbCardLayout.currentIndex())
        except Exception:
            pass

    def _on_card_gate_factor_changed(self, value: int) -> None:
        """
        Update the engine's gate factor from the card profile slider.  This
        mirrors the behaviour of the main gating slider, mapping 0–100 to
        0.0–1.0.  The main slider remains independent; however, both
        sliders control the same engine parameter.
        """
        try:
            # Normalise to 0.0–1.0
            gf = max(0.0, min(1.0, float(value) / 100.0))
            self.eng.gate_factor = gf
            # Update the primary gating slider to reflect the change
            try:
                self.sliderGate.setValue(int(gf * 100.0))
            except Exception:
                pass
        except Exception:
            pass

    def _on_card_layout_changed(self, index: int) -> None:
        """
        Update the engine and UI when the layout selection in the card
        profile tab changes.  This simply proxies to the main layout combo
        box, which in turn triggers its own handler to restart the engine
        if necessary.
        """
        try:
            # Synchronise with the main layout combo if present
            try:
                self.cmbLayout.setCurrentIndex(index)
            except Exception:
                pass
            # If there is no main combo, apply directly to the engine
            if not hasattr(self, 'cmbLayout'):
                # Map index to layout string
                mapping = ['auto', 'stereo', '5.1', '7.1']
                if index < 0 or index >= len(mapping):
                    return
                self.eng.stop()
                self.eng.layout = mapping[index]
                self.set_mode()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Device management
    def _populate_devices(self):
        """
        Populate the input and output device selection combo boxes with
        available devices.  Input devices (with ``max_input_channels > 0``)
        are listed in ``cmbInputDevice``, while output devices
        (``max_output_channels > 0``) are listed in ``cmbOutputDevice``.
        The first device in each list is selected by default.  If a stored
        output device index is present (``self._stored_output_device``),
        attempt to select it in the output combo box.
        """
        # Populate input devices.  Insert an AUTO option at the top which
        # triggers automatic selection of a suitable loopback capture device.
        try:
            self.cmbInputDevice.blockSignals(True)
            self.cmbInputDevice.clear()
            # Insert AUTO entry.  Data payload ``None`` indicates
            # auto-selection.
            self.cmbInputDevice.addItem('AUTO', None)
            inputs = AudioEngine.list_input_devices()
            for idx, name in inputs:
                self.cmbInputDevice.addItem(f'[{idx}] {name}', idx)
        except Exception:
            pass
        finally:
            try:
                self.cmbInputDevice.blockSignals(False)
            except Exception:
                pass
        # Attempt to select the stored input device if available.  When
        # ``None`` (stored as AUTO) we default to the AUTO entry.
        try:
            stored_in = getattr(self, '_stored_input_device', None)
            if stored_in is not None:
                # Find the row matching the stored device index (skip AUTO at row 0)
                for row in range(1, self.cmbInputDevice.count()):
                    if self.cmbInputDevice.itemData(row) == stored_in:
                        self.cmbInputDevice.setCurrentIndex(row)
                        break
            else:
                # Use AUTO when no stored input
                self.cmbInputDevice.setCurrentIndex(0)
        except Exception:
            pass
        # Ensure a valid selection
        try:
            if self.cmbInputDevice.count() > 0 and self.cmbInputDevice.currentIndex() < 0:
                self.cmbInputDevice.setCurrentIndex(0)
        except Exception:
            pass
        # Populate output devices.  Insert an AUTO option to select the
        # system default output automatically.  The data payload ``None``
        # signals auto-selection.
        try:
            self.cmbOutputDevice.blockSignals(True)
            self.cmbOutputDevice.clear()
            self.cmbOutputDevice.addItem('AUTO', None)
            outputs = AudioEngine.list_output_devices()
            for idx, name in outputs:
                self.cmbOutputDevice.addItem(f'[{idx}] {name}', idx)
        except Exception:
            pass
        finally:
            try:
                self.cmbOutputDevice.blockSignals(False)
            except Exception:
                pass
        # Attempt to select the stored output device if available; use AUTO
        # when no stored value
        try:
            stored_out = getattr(self, '_stored_output_device', None)
            if stored_out is not None:
                for row in range(1, self.cmbOutputDevice.count()):
                    if self.cmbOutputDevice.itemData(row) == stored_out:
                        self.cmbOutputDevice.setCurrentIndex(row)
                        break
            else:
                self.cmbOutputDevice.setCurrentIndex(0)
        except Exception:
            pass
        # Ensure selection is valid
        try:
            if self.cmbOutputDevice.count() > 0 and self.cmbOutputDevice.currentIndex() < 0:
                self.cmbOutputDevice.setCurrentIndex(0)
        except Exception:
            pass

    def _on_input_device_changed(self, index: int):
        """
        Handle changes to the input device selection.  When the user selects
        a new capture device the audio engine is restarted using the new
        device.  Device-specific profiles are applied immediately.
        """
        if index < 0:
            return
        try:
            dev_idx = self.cmbInputDevice.itemData(index)
            # When AUTO is selected (dev_idx is None) perform automatic
            # input/output selection and update combo boxes accordingly.
            if dev_idx is None:
                try:
                    auto_in, auto_out = AudioEngine.auto_select_io()
                except Exception:
                    auto_in, auto_out = (None, None)
                # Update the engine with the selected devices
                try:
                    self.eng.stop()
                except Exception:
                    pass
                try:
                    self.eng.set_device(auto_in)
                except Exception:
                    pass
                try:
                    self.eng.set_output_device(auto_out)
                except Exception:
                    pass
                # Update input combo to the newly selected device
                # Skip row 0 (AUTO) when searching for matching index
                try:
                    for row in range(1, self.cmbInputDevice.count()):
                        if self.cmbInputDevice.itemData(row) == auto_in:
                            # block signals temporarily to avoid reentrancy
                            self.cmbInputDevice.blockSignals(True)
                            self.cmbInputDevice.setCurrentIndex(row)
                            self.cmbInputDevice.blockSignals(False)
                            break
                except Exception:
                    pass
                # Update output combo similarly
                try:
                    for row in range(1, self.cmbOutputDevice.count()):
                        if self.cmbOutputDevice.itemData(row) == auto_out:
                            self.cmbOutputDevice.blockSignals(True)
                            self.cmbOutputDevice.setCurrentIndex(row)
                            self.cmbOutputDevice.blockSignals(False)
                            break
                except Exception:
                    pass
                # Apply profile for the selected input device name
                try:
                    name = str(self.cmbInputDevice.currentText())
                    self._apply_device_profiles(name)
                except Exception:
                    pass
                # Restart engine in current mode
                try:
                    self.set_mode()
                except Exception:
                    pass
            else:
                # Manual selection: stop engine, set device, apply profile and restart
                try:
                    self.eng.stop()
                except Exception:
                    pass
                try:
                    self.eng.set_device(dev_idx)
                except Exception:
                    pass
                # Apply device-specific profile based on input device name
                try:
                    name = str(self.cmbInputDevice.currentText())
                    self._apply_device_profiles(name)
                except Exception:
                    pass
                # Restart engine in current mode
                try:
                    self.set_mode()
                except Exception:
                    pass
        except Exception:
            pass

    def _on_output_device_changed(self, index: int):
        """
        Handle changes to the output device selection.  Changing the output
        device does not affect the audio analysis directly, but the selection
        is stored in the engine and may be used by device-specific profiles.
        """
        if index < 0:
            return
        try:
            out_idx = self.cmbOutputDevice.itemData(index)
            # When AUTO is selected (None) automatically choose a sensible
            # output device via the audio engine helper.  Do not change
            # the input device here.
            if out_idx is None:
                try:
                    _, auto_out = AudioEngine.auto_select_io()
                except Exception:
                    auto_out = None
                try:
                    self.eng.set_output_device(auto_out)
                except Exception:
                    pass
                # Update the combo box to reflect the chosen output device
                try:
                    for row in range(1, self.cmbOutputDevice.count()):
                        if self.cmbOutputDevice.itemData(row) == auto_out:
                            self.cmbOutputDevice.blockSignals(True)
                            self.cmbOutputDevice.setCurrentIndex(row)
                            self.cmbOutputDevice.blockSignals(False)
                            break
                except Exception:
                    pass
            else:
                # Manual selection: update engine output device
                try:
                    self.eng.set_output_device(out_idx)
                except Exception:
                    pass
        except Exception:
            pass

    def _apply_device_profiles(self, device_name: str) -> None:
        """
        Apply special settings for recognised devices.  For example, if the
        device name contains 'sound blaster z' or 'z se' we set the layout
        to 5.1 (6 channels) and adjust the gating factor.  Additional
        profiles can be added here as elif clauses.
        """
        try:
            name_lower = (device_name or '').lower()
            if 'sound blaster z' in name_lower or 'z se' in name_lower:
                try:
                    if self.cmbLayout.currentIndex() != 2:
                        self.cmbLayout.setCurrentIndex(2)
                except Exception:
                    pass
                try:
                    self.sliderGate.setValue(35)
                except Exception:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Layout and Scout Mode management
    def _on_layout_changed(self, index: int):
        """
        Change the channel layout for the audio analysis.  When the user
        selects a different layout (AUTO/STEREO/5.1/7.1) the audio engine is
        restarted with the new setting to reconfigure the stream.  The
        engine must be stopped before changing its configuration.
        """
        mapping = ['auto', 'stereo', '5.1', '7.1']
        if index < 0 or index >= len(mapping):
            return
        new_layout = mapping[index]
        try:
            # Stop the engine, set layout and restart
            self.eng.stop()
            self.eng.layout = new_layout
            # Start using the existing run mode
            self.set_mode()
        except Exception:
            pass

    def _on_scout_changed(self, checked: bool):
        """
        Enable or disable Scout Mode.  When Scout Mode is on the audio
        engine will emphasise frequency bands associated with footsteps and
        human voice.  This setting can be toggled at runtime without
        restarting the engine.
        """
        try:
            self.eng.scout_mode = bool(checked)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Saving configuration
    def _save_settings(self):
        """
        Persist the current UI and audio configuration to the settings
        file.  This method reads the existing configuration (if any),
        updates the UI and audio parameters, and writes the file back
        atomically.  Any errors during saving are silently ignored.
        """
        import json, os
        path = getattr(self, '_settings_path', None)
        if not path:
            return
        # Load existing configuration
        try:
            cfg: dict = {}
            if os.path.isfile(path):
                with open(path, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
        except Exception:
            cfg = {}
        # Ensure sections exist
        if not isinstance(cfg.get('ui'), dict):
            cfg['ui'] = {}
        if not isinstance(cfg.get('widgets'), dict):
            cfg['widgets'] = {}
        if not isinstance(cfg.get('audio'), dict):
            cfg['audio'] = {}
        # Update UI settings
        cfg['ui']['demo_default'] = (self.cmbMode.currentIndex() == 0)
        # Keep autowidgets as is or default to True
        if 'autowidgets' not in cfg['ui']:
            cfg['ui']['autowidgets'] = True
        # Persist the selected HUD profile.  Store the lowercase identifier
        # corresponding to the human‑readable combo box text.
        try:
            cfg['ui']['profile'] = str(self.cmbProfile.currentText()).strip().lower()
        except Exception:
            cfg['ui']['profile'] = 'cinematic'
        # Update widget positions, sizes and opacities
        # Radar
        if not isinstance(cfg['widgets'].get('radar'), dict):
            cfg['widgets']['radar'] = {}
        rcfg = cfg['widgets']['radar']
        rcfg['x'] = int(self.radar.x())
        rcfg['y'] = int(self.radar.y())
        rcfg['size'] = int(self.radar.width())  # radar is square
        rcfg['opacity'] = float(self.radar._opacity)
        rcfg['visible'] = bool(self.chkRadar.isChecked())
        # LED bars
        if not isinstance(cfg['widgets'].get('leds'), dict):
            cfg['widgets']['leds'] = {}
        lcfg = cfg['widgets']['leds']
        lcfg['x'] = int(self.leds.x())
        lcfg['y'] = int(self.leds.y())
        lcfg['w'] = int(self.leds.width())
        lcfg['h'] = int(self.leds.height())
        lcfg['opacity'] = float(self.leds._opacity)
        lcfg['visible'] = bool(self.chkLeds.isChecked())
        # Update audio settings
        cfg['audio']['fs'] = int(self.eng.fs)
        cfg['audio']['blocksize'] = int(self.eng.blocksize)
        # Persist current layout selection.  Use lowercase to remain consistent.
        try:
            cfg['audio']['layout'] = str(self.cmbLayout.currentText()).strip().lower()
        except Exception:
            cfg['audio']['layout'] = 'auto'
        cfg['audio']['scout_mode'] = bool(self.chkScout.isChecked())
        # Persist gating factor to configuration.  The value is a float
        # in the range 0.0–1.0 and is read when creating the engine.
        try:
            cfg['audio']['gate_factor'] = float(getattr(self.eng, 'gate_factor', 0.30))
        except Exception:
            cfg['audio']['gate_factor'] = 0.30
        # Persist adaptive gating flag
        try:
            cfg['audio']['adaptive_gate'] = bool(self.chkAdaptiveGate.isChecked())
        except Exception:
            cfg['audio']['adaptive_gate'] = False
        # Persist custom game process identifiers if any are set.  When
        # ``_game_processes`` is non‑empty the identifiers are stored
        # exactly as configured; otherwise remove the entry to fall back
        # to the built‑in defaults.
        try:
            gps = getattr(self, '_game_processes', [])
            if gps:
                cfg['audio']['game_processes'] = list(gps)
            else:
                cfg['audio'].pop('game_processes', None)
        except Exception:
            pass
        # Persist input and output device indices.  When None no entry is written.
        try:
            in_idx = self.cmbInputDevice.itemData(self.cmbInputDevice.currentIndex())
            if in_idx is not None:
                cfg['audio']['input_device'] = in_idx
        except Exception:
            # Remove stale entry if present
            cfg['audio'].pop('input_device', None)
        try:
            out_idx = self.cmbOutputDevice.itemData(self.cmbOutputDevice.currentIndex())
            if out_idx is not None:
                cfg['audio']['output_device'] = out_idx
        except Exception:
            cfg['audio'].pop('output_device', None)
        # Persist auto game detection state
        try:
            cfg['audio']['auto_game_detect'] = bool(self.chkAutoGame.isChecked())
        except Exception:
            pass
        # Write back to file
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(cfg, f, indent=2)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Customisation handlers
    def _on_radar_pos_changed(self, x: int | None, y: int | None):
        """
        Update the position of the radar widget.  When either ``x`` or
        ``y`` is ``None`` the current coordinate of that axis is used.  The
        widget is moved immediately to the new location.
        """
        try:
            new_x = x if x is not None else self.radar.x()
            new_y = y if y is not None else self.radar.y()
            self.radar.move(int(new_x), int(new_y))
        except Exception:
            pass

    def _on_radar_size_changed(self, size: int):
        """
        Update the size of the radar widget.  The radar is always drawn
        square so both width and height are set to the same value.
        """
        try:
            s = max(10, int(size))
            self.radar.resize(s, s)
        except Exception:
            pass

    def _on_radar_opacity_changed(self, opacity: float):
        """
        Update the opacity of the radar widget.  The value is expected to
        be between 0.0 and 1.0.  Values outside this range are clamped.
        """
        try:
            op = float(opacity)
            if op < 0.0:
                op = 0.0
            if op > 1.0:
                op = 1.0
            self.radar.set_opacity(op)
        except Exception:
            pass

    def _on_led_pos_changed(self, x: int | None, y: int | None):
        """
        Update the position of the LED bars widget.  When either ``x`` or
        ``y`` is ``None`` the current coordinate of that axis is used.
        """
        try:
            new_x = x if x is not None else self.leds.x()
            new_y = y if y is not None else self.leds.y()
            self.leds.move(int(new_x), int(new_y))
        except Exception:
            pass

    def _on_led_size_changed(self, w: int | None, h: int | None):
        """
        Update the size of the LED bars widget.  When either ``w`` or
        ``h`` is ``None`` the current dimension is used.  Width and height
        are updated independently.
        """
        try:
            new_w = w if w is not None else self.leds.width()
            new_h = h if h is not None else self.leds.height()
            # enforce minimum dimensions
            new_w = max(10, int(new_w))
            new_h = max(10, int(new_h))
            self.leds.resize(int(new_w), int(new_h))
        except Exception:
            pass

    def _on_led_opacity_changed(self, opacity: float):
        """
        Update the opacity of the LED bars widget.  The value is expected to
        be between 0.0 and 1.0.  Values outside this range are clamped.
        """
        try:
            op = float(opacity)
            if op < 0.0:
                op = 0.0
            if op > 1.0:
                op = 1.0
            self.leds.set_opacity(op)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Drag callback helpers
    def _update_radar_controls(self):
        """
        Synchronise the customisation spin boxes and sliders with the current
        position, size and opacity of the radar widget.  This is called
        automatically when the user moves the radar by dragging its handle.
        """
        try:
            self.spinRadarX.setValue(self.radar.x())
            self.spinRadarY.setValue(self.radar.y())
            self.spinRadarSize.setValue(self.radar.width())
            self.sliderRadarOp.setValue(int(self.radar._opacity * 100.0))
        except Exception:
            pass

    def _update_led_controls(self):
        """
        Synchronise the customisation spin boxes and sliders with the current
        position, size and opacity of the LED bars widget.  This is called
        automatically when the user moves the LED widget by dragging its handle.
        """
        try:
            self.spinLedX.setValue(self.leds.x())
            self.spinLedY.setValue(self.leds.y())
            self.spinLedW.setValue(self.leds.width())
            self.spinLedH.setValue(self.leds.height())
            self.sliderLedOp.setValue(int(self.leds._opacity * 100.0))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Calibration reset
    def _reset_calibration(self):
        """
        Reset the adaptive calibration state in the audio engine.  This clears
        the stored minimum and maximum energy values for both multi‑channel
        processing and stereo gating.  After calling this method the engine
        will re‑learn the noise floor and peak energies.  This can be useful
        when the environment changes significantly.
        """
        try:
            # Use the dedicated reset method on the audio engine.  This
            # clears both AutoCal and noise floor tracking.  Ignore
            # exceptions silently.
            if hasattr(self.eng, 'reset_calibration'):
                self.eng.reset_calibration()
            else:
                # Fallback: manually reset internal attributes
                self.eng._energy_min = None
                self.eng._energy_max = None
                self.eng._stereo_min = None
                self.eng._stereo_max = None
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Radar customisation handlers
    def _on_radar_size_changed(self, value: int):
        """Adjust the size of the radar floating widget."""
        try:
            size = max(160, int(value))
            self.radar.resize(size, size)
        except Exception:
            pass

    def _on_radar_opacity_changed(self, value):
        """
        Adjust the opacity of the radar floating widget.  This handler
        accepts either an integer slider value (0–100) or a normalised
        float (0.0–1.0).  The opacity is clamped to the range 0.0–1.0.
        After updating the radar widget, both the preview slider
        (``radarOpacitySlider``) and the customisation slider
        (``sliderRadarOp``) are synchronised to reflect the new value
        without emitting additional valueChanged signals.  This avoids
        the broken behaviour where a single adjustment makes the sliders
        appear stuck.
        """
        try:
            # Determine the opacity from the given value.  If the value
            # appears to be a float within 0–1, treat it as an
            # opacity directly; otherwise assume it is a slider value
            # between 0 and 100.  Strings are converted to float.
            op: float
            try:
                # Attempt to convert to float first
                fval = float(value)
            except Exception:
                # If conversion fails, default to current opacity
                fval = self.radar._opacity
            if 0.0 <= fval <= 1.0:
                op = fval
                slider_val = int(op * 100.0)
            else:
                # Treat as 0–100 slider value
                iv = int(round(fval))
                iv = max(0, min(100, iv))
                op = iv / 100.0
                slider_val = iv
            # Clamp to 0.0–1.0
            if op < 0.0:
                op = 0.0
            if op > 1.0:
                op = 1.0
            # Apply opacity to widget
            self.radar.set_opacity(op)
            # Synchronise the preview slider (range 10–100) and
            # customisation slider (range 0–100).  We block signals
            # temporarily to avoid recursive callbacks.
            val_preview = int(max(0, min(100, op * 100.0)))
            val_preview = max(10, val_preview)  # preview slider starts at 10
            if hasattr(self, 'radarOpacitySlider'):
                try:
                    self.radarOpacitySlider.blockSignals(True)
                    self.radarOpacitySlider.setValue(val_preview)
                    self.radarOpacitySlider.blockSignals(False)
                except Exception:
                    pass
            if hasattr(self, 'sliderRadarOp'):
                try:
                    self.sliderRadarOp.blockSignals(True)
                    self.sliderRadarOp.setValue(int(max(0, min(100, op * 100.0))))
                    self.sliderRadarOp.blockSignals(False)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_radar_position_changed(self, *args):
        """Move the radar floating widget to the X/Y coordinates specified by the spin boxes."""
        try:
            x = int(self.radarXSpin.value())
            y = int(self.radarYSpin.value())
            self.radar.move(x, y)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # LED bars customisation handlers
    def _on_led_size_changed(self, *args):
        """Adjust the width and height of the LED bars widget."""
        try:
            w = int(self.ledWidthSlider.value())
            h = int(self.ledHeightSlider.value())
            # Minimum sizes enforced by widget; apply new size
            self.leds.resize(w, h)
        except Exception:
            pass

    def _on_led_opacity_changed(self, value):
        """
        Adjust the opacity of the LED bars widget.  This handler
        accepts either an integer slider value (0–100) or a normalised
        float (0.0–1.0).  After applying the opacity, both the preview
        slider (``ledOpacitySlider``) and the customisation slider
        (``sliderLedOp``) are synchronised to reflect the new value.
        """
        try:
            # Convert to float if possible
            try:
                fval = float(value)
            except Exception:
                fval = self.leds._opacity
            if 0.0 <= fval <= 1.0:
                op = fval
                slider_val = int(op * 100.0)
            else:
                iv = int(round(fval))
                iv = max(0, min(100, iv))
                op = iv / 100.0
                slider_val = iv
            # Clamp
            if op < 0.0:
                op = 0.0
            if op > 1.0:
                op = 1.0
            # Apply opacity
            self.leds.set_opacity(op)
            # Synchronise sliders
            val_preview = int(max(0, min(100, op * 100.0)))
            val_preview = max(10, val_preview)
            if hasattr(self, 'ledOpacitySlider'):
                try:
                    self.ledOpacitySlider.blockSignals(True)
                    self.ledOpacitySlider.setValue(val_preview)
                    self.ledOpacitySlider.blockSignals(False)
                except Exception:
                    pass
            if hasattr(self, 'sliderLedOp'):
                try:
                    self.sliderLedOp.blockSignals(True)
                    self.sliderLedOp.setValue(int(max(0, min(100, op * 100.0))))
                    self.sliderLedOp.blockSignals(False)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_led_position_changed(self, *args):
        """Move the LED bars widget to the X/Y coordinates specified by the spin boxes."""
        try:
            x = int(self.ledXSpin.value())
            y = int(self.ledYSpin.value())
            self.leds.move(x, y)
        except Exception:
            pass

    def _on_led_segments_changed(self) -> None:
        """
        Adjust the number of LED segments based on the spin boxes in the
        customisation tab.  Each edge (top, bottom, left, right) can
        have between 1 and 20 segments.  When the counts change, the
        LED widget is updated to reflect the new segmentation.
        """
        try:
            top = int(self.spinLedSegTop.value()) if hasattr(self, 'spinLedSegTop') else len(self.leds.energy.get('top', []))
            bottom = int(self.spinLedSegBottom.value()) if hasattr(self, 'spinLedSegBottom') else len(self.leds.energy.get('bottom', []))
            left = int(self.spinLedSegLeft.value()) if hasattr(self, 'spinLedSegLeft') else len(self.leds.energy.get('left', []))
            right = int(self.spinLedSegRight.value()) if hasattr(self, 'spinLedSegRight') else len(self.leds.energy.get('right', []))
            try:
                self.leds.set_segment_counts(top, bottom, left, right)
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Auto game detection
    def _on_auto_game_detect_toggled(self, checked: bool) -> None:
        """
        Enable or disable automatic game detection.  When enabled and
        ``psutil`` is available, a timer periodically scans the list of
        running processes for known game names.  If a recognised game is
        detected the application switches to REAL mode automatically; if
        no games are running it reverts to DEMO mode.  When disabled the
        timer is stopped.  If ``psutil`` is not available this function
        does nothing.
        """
        if psutil is None:
            return
        try:
            if checked:
                # Perform an immediate check to set the correct mode now
                self._check_for_games()
                # Start periodic scanning
                self._game_timer.start()
            else:
                self._game_timer.stop()
        except Exception:
            pass

    def _check_for_games(self) -> None:
        """
        Inspect running processes to determine whether a supported game is
        running.  If a game is found the run mode is switched to REAL; if
        none are found the mode is switched to DEMO.  The list of known
        games can be extended as needed.  Requires ``psutil`` to be
        available; otherwise this method does nothing.
        """
        if psutil is None:
            return
        try:
            # Determine list of process identifiers to check.  Use the
            # custom list from the configuration when available; otherwise
            # fall back to a built‑in set of popular game names.  All
            # identifiers are matched case‑insensitively against both
            # process names and executable paths.
            custom = getattr(self, '_game_processes', []) or []
            if custom:
                identifiers = [x.lower() for x in custom]
            else:
                identifiers = [
                    'csgo', 'counter-strike', 'counter strike', 'valorant',
                    'pubg', 'apex', 'fortnite', 'overwatch', 'warzone',
                    'call of duty', 'r6', 'rainbow six', 'palworld',
                    'league of legends', 'dota2', 'dota 2'
                ]
            found_game = False
            # Query both name and executable path to improve detection
            for proc in psutil.process_iter(['name', 'exe']):
                try:
                    pname = proc.info.get('name', '') or ''
                    pexe = proc.info.get('exe', '') or ''
                    # Lowercase both for case‑insensitive comparison
                    nlow = pname.lower()
                    elow = pexe.lower()
                    for ident in identifiers:
                        if ident in nlow or (ident and ident in elow):
                            found_game = True
                            break
                    if found_game:
                        break
                except Exception:
                    continue
            # Switch to REAL mode if a game is detected; otherwise DEMO
            try:
                # 1 = REAL, 0 = DEMO for combo box indices
                if found_game and self.cmbMode.currentIndex() != 1:
                    self.cmbMode.setCurrentIndex(1)
                elif not found_game and self.cmbMode.currentIndex() != 0:
                    self.cmbMode.setCurrentIndex(0)
            except Exception:
                pass
        except Exception:
            pass


    # ------------------------------------------------------------------
    # UI refresh timer handler
    def _ui_update(self) -> None:
        """
        Periodically refresh the LED and radar widgets to ensure that the UI
        remains responsive even when no new detections arrive.  This method
        decays LED segment energies and repaints both widgets.
        """
        try:
            if hasattr(self.leds, 'decay_energy'):
                self.leds.decay_energy()
            # Trigger repaint
            self.leds.update()
        except Exception:
            pass
        try:
            # Radar does not decay energy but still needs to repaint
            self.radar.update()
        except Exception:
            pass
        # Update the channel activity display with current per-channel state
        try:
            self._update_channel_activity_display()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Channel activity display updater
    def _update_channel_activity_display(self) -> None:
        """
        Update the channel activity label to reflect which channels are
        currently active.  The audio engine provides per‑channel names and
        activity flags.  For each channel a filled bullet (●) indicates
        that its energy exceeds the adaptive threshold; an empty bullet (○)
        indicates relative silence.  If no activity information is
        available the label displays 'brak danych'.
        """
        try:
            names = self.eng.get_channel_names() or []
            states = self.eng.get_channel_activity() or []
            if not names or not states or len(names) != len(states):
                self.lblChannelActivity.setText('brak danych')
                return
            parts: list[str] = []
            for name, active in zip(names, states):
                bullet = '●' if active else '○'
                parts.append(f'{name}{bullet}')
            self.lblChannelActivity.setText(' '.join(parts))
        except Exception:
            try:
                self.lblChannelActivity.setText('brak danych')
            except Exception:
                pass

    # ------------------------------------------------------------------
    # LED full‑screen toggle handler
    def _toggle_led_fullscreen(self) -> None:
        """
        Toggle the LED bar between its current geometry and a full‑screen
        layout.  When expanded to full screen the drag and resize handles are
        hidden.  When restored the previous size and position are reapplied
        and the handles are shown again.  The current LED geometry is
        synchronised back to the UI controls after each toggle.
        """
        try:
            if not getattr(self, '_led_fullscreen', False):
                # Store current geometry
                self._led_prev_geom = (self.leds.x(), self.leds.y(), self.leds.width(), self.leds.height())
                # Determine available screen geometry
                scr = QtWidgets.QApplication.primaryScreen()
                geo = scr.availableGeometry() if scr else QtCore.QRect(0, 0, 1920, 1080)
                # Move and resize LED widget to cover the screen
                self.leds.move(geo.x(), geo.y())
                self.leds.resize(geo.width(), geo.height())
                # Hide drag and resize handles
                try:
                    self.leds._dragHandle.hide()
                    self.leds._resizeHandle.hide()
                except Exception:
                    pass
                self._led_fullscreen = True
            else:
                # Restore previous geometry if available
                try:
                    x, y, w, h = self._led_prev_geom
                    self.leds.move(int(x), int(y))
                    self.leds.resize(int(w), int(h))
                except Exception:
                    pass
                # Show drag and resize handles
                try:
                    self.leds._dragHandle.show()
                    self.leds._resizeHandle.show()
                except Exception:
                    pass
                self._led_fullscreen = False
            # Synchronise UI controls with new geometry
            try:
                self._update_led_controls()
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Adaptive gating management
    def _on_adaptive_gate_changed(self, checked: bool) -> None:
        """
        Toggle adaptive gating on the audio engine.  When enabled the
        engine will dynamically adjust its noise gate threshold based on
        the proportion of frames classified as silence.  This aims to
        maintain a consistent detection rate under varying noise
        conditions.  When disabled the gate factor remains fixed as
        controlled by the slider(s).

        Parameters
        ----------
        checked : bool
            Whether the adaptive gating checkbox is checked.
        """
        try:
            self.eng.adaptive_gate = bool(checked)
            if bool(checked):
                # Reset counters so that the next adaptation window starts
                # fresh.  Without resetting, stale counts could skew the
                # adjustment in the first window after enabling.
                try:
                    self.eng._gate_count = 0
                    self.eng._gate_total = 0
                except Exception:
                    pass
        except Exception:
            pass

import sys
import os
from PyQt5 import QtWidgets

# Import our application components.  When this module is executed as part
# of a package (e.g. via ``python -m GameAudioDirectionDetector`` or
# when bundled by PyInstaller) the relative imports below will resolve
# correctly.  However, if a user attempts to run ``__main__.py`` directly
# (``python __main__.py``) the package context is not established and
# relative imports will fail with ``ImportError: attempted relative import
# with no known parent package``.  To make the application more robust,
# we fall back to absolute imports in that situation.
try:
    # preferred relative imports when executed as a package
    from .main_window import MainWindow  # type: ignore
    from .utils import Tee  # type: ignore
except ImportError:
    # fallback absolute imports for direct execution
    from GameAudioDirectionDetector.main_window import MainWindow  # type: ignore
    from GameAudioDirectionDetector.utils import Tee  # type: ignore

def main():
    base = os.path.abspath(os.path.dirname(__file__))
    logdir = os.path.abspath(os.path.join(base, '..', 'logs'))
    os.makedirs(logdir, exist_ok=True)
    tee = Tee(sys.stdout, os.path.join(logdir, 'run_log.txt'))
    sys.stdout = tee; sys.stderr = tee
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(os.path.join(base,'settings.json'), demo_default=True, autowidgets=True)
    win.show()
    return app.exec_()

if __name__=='__main__':
    sys.exit(main())

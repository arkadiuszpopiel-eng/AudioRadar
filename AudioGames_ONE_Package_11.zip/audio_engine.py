import threading, time, math
try:
    import sounddevice as sd
    import numpy as np
except Exception:
    sd = None
    np = None

class RunMode:
    REAL='real'; DEMO='demo'

class AudioEngine:
    def __init__(
        self,
        fs: int = 48000,
        blocksize: int = 1024,
        device: int | str | None = None,
        output_device: int | str | None = None,
        layout: str = 'auto',
        scout_mode: bool = False,
        gate_factor: float = 0.20,
        adaptive_gate: bool = False,
        detect_steps: bool = True,
        detect_shots: bool = True,
    ):
        """
        Create a new audio engine.

        :param fs:          Sampling frequency in Hz.
        :param blocksize:   Number of samples per block; determines latency.
        :param device:      Index or name of the audio capture device (WASAPI loopback).  If None,
                            the default loopback device is used.
        :param layout:      Desired channel layout for analysis.  Valid values are 'auto',
                            'stereo', '5.1' or '7.1'.  When set to 'auto' the engine will
                            use whatever number of channels the input device provides.  For
                            the other options, the input is truncated to the first 2, 6 or
                            8 channels respectively, provided the device exposes that many
                            channels.
        :param scout_mode: When True the analysis emphasises frequency bands associated
                            with footsteps and human voice (around 100–250 Hz and
                            2–4 kHz) to improve detection in competitive play.  This
                            weighting is applied only when processing stereo audio (two
                            channels).  Multi‑channel processing currently ignores this
                            flag.
        """
        self.fs = fs
        self.blocksize = blocksize
        self.device = device
        # store output playback device index/name separately.  The audio engine
        # does not use the output device internally (audio is captured via
        # loopback), but we keep it for configuration purposes and to support
        # future enhancements (e.g. channel-specific calibration).
        self.output_device = output_device
        self.mode = RunMode.DEMO
        self._run = False
        self._detcbs: list = []
        # runtime state for diagnostics
        self.opened = 'DEMO'
        self.curr_channels = 2
        # store requested layout and scout mode
        self.layout = (layout or 'auto').lower()
        self.scout_mode = bool(scout_mode)
        # gating factor controls the fraction between the baseline noise
        # floor and the peak energy used for adaptive thresholding in
        # stereo processing.  Valid values are in the range [0.0, 1.0].  A
        # higher value requires stronger signals to register as a
        # detection, while a lower value makes the gate more lenient.
        try:
            gf = float(gate_factor)
        except Exception:
            gf = 0.30
        # Use a more permissive default noise gate factor.  Lower values make
        # the gate less strict, allowing quieter sounds (e.g. footsteps) to
        # register as detections.  Clamped to [0.0, 1.0].
        self.gate_factor = max(0.0, min(1.0, gf))
        self.curr_layout = 'stereo'
        self._lvl = -30.0
        # previous estimated angle for smoothing
        self._prev_angle = 0.0
        # energy calibration (AutoCal) tracking per channel
        self._energy_min: list[float] | None = None
        self._energy_max: list[float] | None = None
        # adaptive noise floor tracking for stereo gating
        self._stereo_min: float | None = None
        self._stereo_max: float | None = None
        # Adaptive gating control.  When ``adaptive_gate`` is True the engine
        # adjusts the ``gate_factor`` dynamically based on the fraction of
        # frames that fall below the noise threshold.  This helps maintain
        # a consistent detection rate across varying background noise
        # conditions.  Counters `_gate_count` and `_gate_total` track the
        # number of gated (silence) frames and the total frames processed
        # since the last adaptation.  These counters are reset after
        # updating the gate factor.
        self.adaptive_gate = bool(adaptive_gate)
        self._gate_count = 0
        self._gate_total = 0
        # Track which channels currently carry significant audio.  This list
        # is updated in the audio callback.  Each entry corresponds to a
        # channel in the processed input (after layout truncation) and
        # indicates whether that channel's energy exceeds a dynamic
        # threshold.  The names associated with each channel are stored
        # separately in ``_channel_names``.
        self._current_channel_activity: list[bool] | None = None
        self._channel_names: list[str] | None = None
        # Detection mode flags.  When ``detect_steps`` is True the engine
        # will emit detections classified as footsteps (walking/running).  When
        # ``detect_shots`` is True the engine will emit detections classified
        # as shots (loud impulses).  These flags can be modified at runtime
        # via ``set_detection_modes``.
        self.detect_steps = bool(detect_steps)
        self.detect_shots = bool(detect_shots)

    def set_detection_modes(self, steps: bool, shots: bool) -> None:
        """
        Enable or disable detection of footsteps and shots.  When a class of
        sounds is disabled the engine will suppress emissions classified
        as that type.

        :param steps: emit detections classified as footsteps when True
        :param shots: emit detections classified as shots when True
        """
        self.detect_steps = bool(steps)
        self.detect_shots = bool(shots)

    def reset_calibration(self) -> None:
        """
        Reset the adaptive calibration state.  This clears the stored
        minimum and maximum energy values for multi‑channel AutoCal and
        the stereo noise floor tracking.  After invoking this method the
        engine will re‑learn the noise floor and peaks.  This method can
        be called at runtime, typically in response to a UI action.
        """
        self._energy_min = None
        self._energy_max = None
        self._stereo_min = None
        self._stereo_max = None

    def on_detect(self, cb): self._detcbs.append(cb)
    def set_run_mode(self, m): self.mode=m
    def start(self):
        if self._run: return True
        self._run=True
        if self.mode==RunMode.REAL and sd is not None:
            threading.Thread(target=self._loop_real,daemon=True).start()
        else:
            threading.Thread(target=self._loop_demo,daemon=True).start()
        return True
    def stop(self): self._run=False

    def set_device(self, device: int | str | None):
        """
        Change the audio input device.  This must be called when the engine is
        not running.  The device can be specified either by index (as returned
        by ``sounddevice.query_devices``) or by name.
        """
        if self._run:
            raise RuntimeError('Cannot change device while engine is running')
        self.device = device

    def set_output_device(self, output_device: int | str | None):
        """
        Change the output playback device.  This does not affect the audio
        analysis, which always captures from the input loopback device, but
        allows storing the user's preferred playback device in the engine.
        """
        # output device can be changed at any time; it is not used internally
        self.output_device = output_device

    @staticmethod
    def auto_select_io() -> tuple[int | str | None, int | str | None]:
        """
        Attempt to automatically select reasonable input and output devices.

        For the input (capture) device the selection prioritises loopback
        devices (those whose name contains common loopback keywords such as
        ``What U Hear``, ``Mapowanie dźwięku`` or ``loopback``).  If no
        loopback device can be found, the system default input device is
        returned.  For the output device the system default output device is
        used.  If device enumeration fails, ``None`` values are returned.

        :returns: a tuple (input_device, output_device)
        """
        try:
            import sounddevice as sd_local
            # Determine system defaults
            default_input, default_output = sd_local.default.device
            # Build a list of candidate loopback devices
            loopback_candidates: list[int] = []
            for idx, dev in enumerate(sd_local.query_devices()):
                try:
                    name = dev.get('name', '')
                    # Consider devices with "loopback" capabilities; sounddevice
                    # reports loopback devices as input devices with non‑zero
                    # max_input_channels and names containing known keywords.
                    if dev.get('max_input_channels', 0) > 0:
                        name_lc = name.lower()
                        if ('what u hear' in name_lc
                            or 'mapowanie dźwięku' in name_lc
                            or 'mapowanie dzwieku' in name_lc
                            or 'loopback' in name_lc
                            or 'stereo mix' in name_lc):
                            loopback_candidates.append(idx)
                except Exception:
                    continue
            # Pick the first loopback candidate if available
            selected_input: int | str | None
            if loopback_candidates:
                selected_input = loopback_candidates[0]
            else:
                selected_input = default_input
            selected_output: int | str | None = default_output
            return selected_input, selected_output
        except Exception:
            return None, None

    def get_channel_activity(self) -> list[bool] | None:
        """Return the current activity state of each processed channel.

        Each entry corresponds to a processed channel after layout
        truncation.  ``True`` indicates that the channel energy exceeds a
        dynamic threshold; ``False`` indicates relative silence.  When no
        data has been processed yet, ``None`` is returned.
        """
        return self._current_channel_activity

    def get_channel_names(self) -> list[str] | None:
        """Return the names assigned to each processed channel.

        Names are determined based on the selected layout.  For stereo
        processing the names are ``['L', 'R']``.  For 5.1 and 7.1 the names
        correspond to standard channel abbreviations.  For unknown
        multi‑channel configurations, generic names ``Ch1``, ``Ch2`` etc.
        are used.  When no data has been processed yet, ``None`` is
        returned.
        """
        return self._channel_names

    @staticmethod
    def list_input_devices() -> list[tuple[int, str]]:
        """
        Return a list of available input devices suitable for WASAPI loopback.  Each
        entry is a tuple of ``(index, name)``.  Only devices that report
        ``max_input_channels > 0`` are included.
        """
        devices: list[tuple[int, str]] = []
        try:
            import sounddevice as sd_local  # local import to avoid failing at module import
            for idx, dev in enumerate(sd_local.query_devices()):
                try:
                    if dev.get('max_input_channels', 0) > 0:
                        devices.append((idx, dev.get('name', f'Device {idx}')))
                except Exception:
                    continue
        except Exception:
            pass
        return devices

    @staticmethod
    def list_output_devices() -> list[tuple[int, str]]:
        """
        Return a list of available output devices.  Each entry is a tuple
        of ``(index, name)``.  Only devices that report ``max_output_channels > 0``
        are included.  This is primarily used to present a list of playback
        devices to the user; the audio engine itself does not utilise the
        selected output device, as it always captures via the input loopback
        device.
        """
        devices: list[tuple[int, str]] = []
        try:
            import sounddevice as sd_local
            for idx, dev in enumerate(sd_local.query_devices()):
                try:
                    if dev.get('max_output_channels', 0) > 0:
                        devices.append((idx, dev.get('name', f'Device {idx}')))
                except Exception:
                    continue
        except Exception:
            pass
        return devices

    def _emit(self, angle, level, label='det'):
        det={'ts':time.time(),'angle_deg':angle,'level_db':level,'label':label}
        for cb in list(self._detcbs):
            try: cb([det])
            except Exception: pass

    def _loop_demo(self):
        t0=time.time()
        while self._run:
            t=time.time()-t0
            angle=(t*36.0)%360.0
            lvl=-28.0+6.0*math.sin(t*1.7)
            self._lvl=lvl
            self._emit(angle, lvl, 'demo')
            time.sleep(0.05)

    def _loop_real(self):
        try:
            if sd is None:
                raise RuntimeError('sounddevice not available')
            fs=self.fs; block=self.blocksize
            self.curr_channels=2; self.curr_layout='stereo'
            def callback(indata, frames, timeinfo, status):
                """
                Process an audio block and estimate the direction and level.

                This implementation uses both Interaural Level Difference (ILD)
                and Interaural Time Difference (ITD) to produce a smoother and
                more robust angle estimate.  The ILD provides a quick left/right
                estimate based on channel energy, while the ITD uses
                cross‑correlation to infer the relative delay between channels.
                The two estimates are fused with a configurable weighting, and
                the result is smoothed over time.
                """
                # Determine number of channels
                n_ch = indata.shape[1]
                # Apply layout override by truncating channels.  When a specific layout
                # is requested (e.g. stereo, 5.1 or 7.1) and the device exposes at
                # least that many channels, only the first N channels are used.  In
                # auto mode all available channels are consumed.
                proc = indata
                lo = self.layout
                try:
                    # Normalise layout string
                    lo_norm = lo.lower() if isinstance(lo, str) else 'auto'
                except Exception:
                    lo_norm = 'auto'
                if lo_norm in ('stereo', 'st', '2', '2ch', '2ch', '2.0') and n_ch >= 2:
                    proc = indata[:, :2]
                elif lo_norm in ('5.1', '51', 'surround', '5ch') and n_ch >= 6:
                    proc = indata[:, :6]
                elif lo_norm in ('7.1', '71', '8ch') and n_ch >= 8:
                    proc = indata[:, :8]
                # Update number of channels after potential truncation
                n_ch = proc.shape[1]
                if n_ch < 2:
                    return
                # Always convert to float for processing
                proc = proc.astype(float)
                # Two-channel (stereo) processing: ILD/ITD fusion
                if n_ch == 2:
                    # Extract channels
                    L = proc[:, 0]
                    R = proc[:, 1]
                    # If Scout Mode is enabled, emphasise footstep/voice frequency bands
                    if self.scout_mode and np is not None:
                        try:
                            n = len(L)
                            # Compute FFTs of both channels
                            L_fft = np.fft.rfft(L)
                            R_fft = np.fft.rfft(R)
                            freqs = np.fft.rfftfreq(n, d=1.0 / fs)
                            w = np.ones_like(freqs)
                            # Boost energy in the 100–250 Hz and 2–4 kHz bands
                            w[(freqs >= 100.0) & (freqs <= 250.0)] = 2.0
                            w[(freqs >= 2000.0) & (freqs <= 4000.0)] = 2.0
                            L_fft *= w
                            R_fft *= w
                            # Transform back to time domain
                            L = np.fft.irfft(L_fft, n)
                            R = np.fft.irfft(R_fft, n)
                        except Exception:
                            # Fallback: proceed without weighting
                            pass
                    eps = 1e-9
                    # Root-mean-square level per channel
                    l = float((L * L).mean() ** 0.5)
                    r = float((R * R).mean() ** 0.5)
                    # Set channel names for stereo processing
                    try:
                        self._channel_names = ['L', 'R']
                    except Exception:
                        pass
                    # Adaptive gating based on observed noise floor.  If the
                    # combined energy falls below a dynamic threshold, we
                    # suppress spurious detections by not updating the angle.
                    try:
                        # Compute instantaneous energy as the maximum RMS across the two channels
                        energy = max(l, r)
                        # When adaptive gating is enabled, increment the total
                        # frame counter for gating adaptation.  We perform
                        # this increment here since energy is always
                        # computed.  The gated frame count is updated only
                        # when energy falls below the dynamic threshold.
                        if self.adaptive_gate:
                            self._gate_total += 1
                        # Initialise or update adaptive noise floor and peak trackers.  We use
                        # an exponential moving average to track the baseline noise level
                        # (``_stereo_min``) and the observed peak energy (``_stereo_max``).  The
                        # small update coefficients (0.01) give long time constants so that
                        # transient spikes do not immediately collapse the threshold.  When
                        # energy dips below the baseline the minimum is updated immediately to
                        # ensure silence is captured.
                        if self._stereo_min is None or self._stereo_max is None:
                            self._stereo_min = energy
                            self._stereo_max = energy
                        else:
                            # Update baseline (noise floor)
                            if energy < self._stereo_min:
                                # New low point: update immediately
                                self._stereo_min = energy
                            else:
                                # Otherwise relax baseline slowly towards energy
                                self._stereo_min = self._stereo_min * 0.99 + energy * 0.01
                            # Update peak (maximum)
                            if energy > self._stereo_max:
                                # New high point: update immediately
                                self._stereo_max = energy
                            else:
                                # Otherwise relax peak slowly downwards
                                self._stereo_max = self._stereo_max * 0.99 + energy * 0.01
                        # Compute dynamic threshold somewhere between baseline and peak.  A
                        # larger factor tightens the gate to require stronger signals.  Here
                        # we use 30 % above baseline.  When the dynamic range collapses the
                        # threshold equals the instantaneous energy and no gating occurs.
                        thr = None
                        if self._stereo_min is not None and self._stereo_max is not None:
                            diff = self._stereo_max - self._stereo_min
                            if diff > 1e-12:
                                # Use gate_factor to interpolate between the baseline
                                # and the peak.  A larger gate_factor means a stricter
                                # threshold; a smaller gate_factor is more permissive.
                                thr = self._stereo_min + diff * float(getattr(self, 'gate_factor', 0.30))
                        # Determine which stereo channel(s) are currently active.  If a
                        # dynamic threshold is available, compare each channel's RMS
                        # against it; otherwise use a fallback threshold based on
                        # overall energy.  Store the result so that the UI can
                        # indicate per‑channel activity.  When the threshold
                        # collapses (e.g., at startup) both channels will be
                        # considered active if their energy exceeds a minimal
                        # fraction of the combined energy.
                        try:
                            if thr is not None:
                                L_active = bool(l > thr)
                                R_active = bool(r > thr)
                            else:
                                baseline_thr = energy * 0.5 if energy is not None else 0.0
                                L_active = bool(l > baseline_thr)
                                R_active = bool(r > baseline_thr)
                            self._current_channel_activity = [L_active, R_active]
                        except Exception:
                            pass
                        # If energy falls below the threshold we classify it as
                        # insignificant and suppress angle updates.  We still update the
                        # reported level to reflect the noise floor so that the UI
                        # displays a fading bar when no sound is present.
                        if thr is not None and energy <= thr:
                            level_db = 20.0 * np.log10(energy + eps) - 20.0
                            self._lvl = float(level_db)
                            # Adaptive gating: count this frame as a gated (silence)
                            # frame.  When enough frames have been processed we
                            # adjust the gate_factor up or down to maintain a
                            # target silence rate.  Increasing gate_factor makes
                            # the gate more strict (fewer detections); decreasing
                            # makes it more lenient.
                            try:
                                # Increment counters when adaptive gating is enabled
                                if self.adaptive_gate:
                                    self._gate_count += 1
                            except Exception:
                                pass
                            # Emit a silence event using the last angle; this prevents
                            # intermittent spikes from jerking the radar when there is no
                            # meaningful audio.  A distinct label allows downstream
                            # components to differentiate between silence and real
                            # detections if desired.
                            self._emit(float(self._prev_angle), float(level_db), 'silence')
                            # If adaptive gating is enabled, perform dynamic
                            # adjustment of the gate factor when we have
                            # processed enough frames.
                            try:
                                if self.adaptive_gate and self._gate_total >= 100:
                                    # Compute fraction of frames gated (silence)
                                    total = float(self._gate_total) if self._gate_total > 0 else 1.0
                                    silence_rate = float(self._gate_count) / total
                                    # Target silence rate around 50% (tune as needed).
                                    target = 0.5
                                    # Adjust gate_factor: if silence is higher
                                    # than target, lower gate_factor to be more
                                    # permissive; otherwise raise it to tighten
                                    # the gate.  Clamp to [0.05, 0.95].  The
                                    # update step (0.02) controls adaptation speed.
                                    if silence_rate > target:
                                        self.gate_factor = max(0.05, self.gate_factor - 0.02)
                                    else:
                                        self.gate_factor = min(0.95, self.gate_factor + 0.02)
                                    # Reset counters for next adaptation window
                                    self._gate_count = 0
                                    self._gate_total = 0
                            except Exception:
                                pass
                            return
                    except Exception:
                        pass
                    # ILD estimate (level difference in dB scaled to angle)
                    ild = 20.0 * np.log10((l + eps) / (r + eps))
                    ild_angle = 180.0 / (1.0 + np.exp(-ild))
                    # ITD via full cross‑correlation
                    corr = np.correlate(L, R, mode='full')
                    max_idx = int(np.argmax(corr))
                    n = len(L)
                    delay_samples = max_idx - (n - 1)
                    itd_sec = delay_samples / float(fs)
                    max_itd = 0.001  # saturate at ±1 ms
                    normalized = max(-1.0, min(1.0, itd_sec / max_itd))
                    itd_angle = 90.0 * (1.0 - normalized)
                    # Fuse ILD and ITD with weighting (α)
                    alpha = 0.6
                    fused = alpha * ild_angle + (1.0 - alpha) * itd_angle
                    angle_est = (fused * 2.0) % 360.0
                    # Temporal smoothing
                    smooth_factor = 0.85
                    smooth_angle = (
                        smooth_factor * self._prev_angle
                        + (1.0 - smooth_factor) * angle_est
                    ) % 360.0
                    self._prev_angle = smooth_angle
                    # Compute level (max RMS channel, convert to dBFS)
                    level = 20.0 * np.log10(max(l, r) + eps) - 20.0
                    self._lvl = float(level)
                    # Classify sound type (step vs shot) using spectral energy
                    classification: str = 'step'
                    try:
                        if np is not None:
                            # Mix stereo channels and compute spectrum
                            mix = (L + R) * 0.5
                            n = len(mix)
                            if n > 0:
                                spec = np.abs(np.fft.rfft(mix))
                                freqs = np.fft.rfftfreq(n, d=1.0 / fs)
                                # Footstep energy: low frequencies 60–300 Hz and mid 2000–4000 Hz
                                foot_mask = ((freqs >= 60.0) & (freqs <= 300.0)) | ((freqs >= 2000.0) & (freqs <= 4000.0))
                                step_energy = float(spec[foot_mask].sum())
                                # Shot energy: high frequencies 500–6000 Hz
                                shot_mask = (freqs >= 500.0) & (freqs <= 6000.0)
                                shot_energy = float(spec[shot_mask].sum())
                                if shot_energy > (step_energy * 1.5):
                                    classification = 'shot'
                                else:
                                    classification = 'step'
                    except Exception:
                        classification = 'step'
                    # Respect detection mode flags: suppress emissions based on type
                    if classification == 'step' and not getattr(self, 'detect_steps', True):
                        return
                    if classification == 'shot' and not getattr(self, 'detect_shots', True):
                        return
                    # Emit event with the determined classification
                    self._emit(float(smooth_angle), float(level), classification)
                else:
                    # Multi-channel processing (5.1/7.1). Compute per-channel energies.
                    energies: list[float] = []
                    for c in range(n_ch):
                        ch = proc[:, c]
                        energies.append(float((ch * ch).mean() ** 0.5))
                    # Initialise AutoCal state if needed
                    if (
                        self._energy_min is None
                        or self._energy_max is None
                        or len(self._energy_min) != n_ch
                    ):
                        self._energy_min = [float('inf')] * n_ch
                        self._energy_max = [0.0] * n_ch
                    # Update min/max energies (adaptive calibration)
                    for i, e in enumerate(energies):
                        if e < self._energy_min[i]:
                            self._energy_min[i] = e
                        if e > self._energy_max[i]:
                            self._energy_max[i] = e
                    # Determine threshold and compute per-channel weights
                    weights: list[float] = []
                    for i, e in enumerate(energies):
                        e_min = self._energy_min[i]
                        e_max = self._energy_max[i]
                        if e_max <= e_min:
                            weights.append(0.0)
                        else:
                            thr = e_min + (e_max - e_min) * 0.2
                            w = (e - thr) / (e_max - thr) if e > thr else 0.0
                            weights.append(max(0.0, min(1.0, w)))
                    # Update channel names and activity flags.  Assign
                    # human‑readable names based on common layouts; for
                    # unknown channel counts use generic ``Ch#`` labels.  A
                    # channel is marked active if its computed weight is
                    # greater than zero, indicating that its energy exceeds
                    # the adaptive threshold.
                    try:
                        names: list[str]
                        if n_ch == 6:
                            names = ['FL', 'FR', 'C', 'LFE', 'SL', 'SR']
                        elif n_ch == 8:
                            names = ['FL', 'FR', 'C', 'LFE', 'SL', 'SR', 'RL', 'RR']
                        elif n_ch == 2:
                            names = ['L', 'R']
                        else:
                            names = [f'Ch{i+1}' for i in range(n_ch)]
                        self._channel_names = names
                        self._current_channel_activity = [bool(w > 0.0) for w in weights]
                    except Exception:
                        pass
                    # Determine channel layout mapping (angles in degrees)
                    angles: list[float | None] = []
                    # Basic mapping based on commonly used layouts; otherwise distribute uniformly
                    if n_ch == 6:
                        # 5.1 layout: FL, FR, C, LFE, SL, SR
                        layout_angles = [330.0, 30.0, 0.0, None, 110.0, 250.0]
                        for i in range(n_ch):
                            ang = layout_angles[i]
                            angles.append(ang if ang is not None else None)
                    elif n_ch == 8:
                        # 7.1 layout: FL, FR, C, LFE, SL, SR, RL, RR
                        layout_angles = [330.0, 30.0, 0.0, None, 110.0, 250.0, 200.0, 160.0]
                        for i in range(n_ch):
                            ang = layout_angles[i]
                            angles.append(ang if ang is not None else None)
                    else:
                        # Uniform distribution for unknown channel counts
                        for i in range(n_ch):
                            angles.append((360.0 * i) / float(n_ch))
                    # Compute weighted vector sum to obtain direction
                    sum_x = 0.0
                    sum_y = 0.0
                    total_w = 0.0
                    for w, ang in zip(weights, angles):
                        if ang is None:
                            continue  # ignore non-directional channels (e.g., LFE)
                        rad = math.radians(ang)
                        sum_x += w * math.cos(rad)
                        sum_y += w * math.sin(rad)
                        total_w += w
                    # Derive angle from vector sum or fallback to previous angle
                    if total_w > 0.0:
                        raw_angle = (math.degrees(math.atan2(sum_y, sum_x)) + 360.0) % 360.0
                    else:
                        raw_angle = self._prev_angle
                    # Temporal smoothing
                    smooth_factor = 0.85
                    smooth_angle = (
                        smooth_factor * self._prev_angle
                        + (1.0 - smooth_factor) * raw_angle
                    ) % 360.0
                    self._prev_angle = smooth_angle
                    # Level: use max energy among channels, convert to dBFS
                    eps = 1e-9
                    max_e = max(energies)
                    level = 20.0 * math.log10(max_e + eps) - 20.0
                    self._lvl = float(level)
                    self._emit(float(smooth_angle), float(level), 'real')
            # When using ``sounddevice`` we explicitly specify the device if provided.  If
            # no device is set, the default loopback device will be used.  The
            # ``channels`` argument is set to ``None`` to let the stream open with
            # however many channels the device provides; we determine the layout
            # based on the number of channels reported in the callback.
            stream_kwargs = {
                'samplerate': fs,
                'blocksize': block,
                'dtype': 'float32',
                'callback': callback
            }
            if self.device is not None:
                stream_kwargs['device'] = self.device
            # Opening an InputStream with channels=None uses the device's default
            # number of channels.  PyQt5 will still call the callback with the
            # right shape.
            with sd.InputStream(channels=None, **stream_kwargs):
                while self._run:
                    time.sleep(0.05)
        except Exception:
            self.mode=RunMode.DEMO
            self._loop_demo()

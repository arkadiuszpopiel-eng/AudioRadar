from PyQt5 import QtCore
import os, datetime

class Tee(QtCore.QObject):
    def __init__(self, real, path):
        super().__init__()
        self.real = real
        self.path = path
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            self.f = open(path, "a", encoding="utf-8")
            self.f.write("\n===== START {} =====\n".format(datetime.datetime.now().isoformat()))
        except Exception:
            self.f = None
    def write(self, s):
        try:
            if self.real: self.real.write(s)
            if self.f: self.f.write(s); self.f.flush()
        except Exception:
            pass
        return len(s)
    def flush(self):
        try:
            if self.real: self.real.flush()
            if self.f: self.f.flush()
        except Exception:
            pass

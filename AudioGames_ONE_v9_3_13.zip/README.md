# AudioGames ONE (v9.3.7)

- HUD (radar + beacony + mini-pasma)
- Adaptive WASAPI loopback (różne wersje sounddevice/PortAudio)
- Auto-wybór domyślnego urządzenia (WASAPI output)
- Fallback na mikrofon (opcjonalny przełącznik w zakładce Audio)
- Profile JSON + auto-profil po nazwie procesu
- Logowanie CSV
- QSS theme, always-on-top, click-through

## DEV
START_DEBUG.bat

## Build EXE
RUN_BUILD_ALL.cmd → portable\AudioGames_ONE.exe

## v9.3.8
- Dodano "LED edge strips" – punktowe paski LED na krawędziach, wskazujące kierunek i siłę dźwięku (kolor od cyjanu do czerwieni wraz ze wzrostem natężenia).

## v9.3.11
- Ustawienia HUD (włącz/wyłącz: radar, beacony, pasma, LED-ramka).
- LED konfigurowalne: segmenty h/v, grubość, margines, smoothing, kolory low/high. Zapis do settings.json.

## v9.3.12
- Suwak „Wielkość radaru (stretch 1..10)” — zmienia udział radaru w pionowym układzie HUD.
- Tryb bezramkowy (frameless) — włącz/wyłącz z poziomu Ustawień HUD; przeciąganie okna działa myszą. Skrót: Ctrl+F11.
- Ustawienia zapisywane do `settings.json` (hud.layout.radar_stretch i window.frameless).

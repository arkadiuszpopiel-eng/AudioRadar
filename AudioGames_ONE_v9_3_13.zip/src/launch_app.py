from GameAudioDirectionDetector.__main__ import main
if __name__ == "__main__":
    main()


# hidden imports sentinel for PyInstaller
import GameAudioDirectionDetector.main_window  # noqa: F401
import GameAudioDirectionDetector.hud          # noqa: F401
import GameAudioDirectionDetector.audio_engine # noqa: F401
import GameAudioDirectionDetector.autoprofile  # noqa: F401
import GameAudioDirectionDetector.profiles     # noqa: F401

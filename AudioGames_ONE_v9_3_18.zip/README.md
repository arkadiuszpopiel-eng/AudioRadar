# AudioGames ONE (v9.3.18)

- HUD: radar, beacony, pasma, LED-ramka na 4 krawędziach (konfigurowalna).
- Ustawienia HUD: włącz/wyłącz moduły, kolory LED, segmenty, grubość, margines, smoothing, rozmiar radaru.
- Układ HUD: drag-and-drop + presety (folder `portable/bin/layouts`).
- Pływający radar (Ctrl+Alt+R): dowolne miejsce na ekranie, zapamiętywanie pozycji/rozmiaru/opacity/click-through.
- Tryb bezramkowy (Ctrl+F11) — stabilny.
- Logi startowe: `start_here.log`, `start_debug.log`, `runtime.log`.

## DEV
START_DEBUG.bat

## Build EXE
RUN_BUILD_ALL.cmd → portable\AudioGames_ONE.exe

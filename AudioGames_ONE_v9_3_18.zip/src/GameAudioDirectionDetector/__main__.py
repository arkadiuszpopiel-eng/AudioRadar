import os, sys, argparse
from PyQt5 import QtWidgets
import io, datetime

class Tee(io.TextIOBase):
    def __init__(self,*s): self.s=s
    def write(self,t):
        for x in self.s:
            try: x.write(t)
            except Exception: pass
        return len(t)
    def flush(self): 
        for x in self.s:
            try: x.flush()
            except Exception: pass

from GameAudioDirectionDetector.main_window import MainWindow

def _find_settings_path():
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(exe_dir, "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(exe_dir), "portable", "bin", "settings.json"),
        os.path.join(os.getcwd(), "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "portable", "bin", "settings.json"),
    ]
    for c in candidates:
        if os.path.exists(c): return c
    raise SystemExit("Nie znaleziono portable/bin/settings.json obok aplikacji.")

def main():
    # Start logging to runtime.log
    try:
        base = os.path.dirname(sys.executable) if getattr(sys,'frozen',False) else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logp = os.path.join(base, 'portable','logs'); os.makedirs(logp, exist_ok=True)
        f = open(os.path.join(logp,'runtime.log'),'a',encoding='utf-8')
        f.write("\n=== START " + str(datetime.datetime.now()) + " ===\n")
        sys.stdout = Tee(sys.stdout, f); sys.stderr = Tee(sys.stderr, f)
    except Exception: pass

    parser = argparse.ArgumentParser(); parser.add_argument("--lang", default="pl"); parser.add_argument("--theme", default="ProDark_Fluent.qss"); parser.add_argument("--ui", default="full"); parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    settings_path = _find_settings_path()
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(settings_path); win.resize(900, 700); win.show()
    try:
        names = [win.tabs.tabText(i) for i in range(win.tabs.count())]
        print("LOG_TABS:", ", ".join(names))
    except Exception: pass
    sys.exit(app.exec_())

if __name__ == "__main__": main()

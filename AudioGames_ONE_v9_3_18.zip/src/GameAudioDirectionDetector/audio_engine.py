import numpy as np, sounddevice as sd
from scipy.signal import get_window
import threading, queue, inspect

class AudioMetrics:
    __slots__ = ("angle_deg","level","bands")
    def __init__(self, angle_deg=0.0, level=0.0, bands=None):
        self.angle_deg = angle_deg; self.level = level; self.bands = bands or {"low":0.0,"mid":0.0,"high":0.0}

class AudioEngine:
    def __init__(self, samplerate=48000, blocksize=1024, gain=1.0, noise_gate=0.002, loopback=True, allow_fallback=True):
        self.samplerate = samplerate; self.blocksize = blocksize; self.gain=gain; self.noise_gate=noise_gate
        self.loopback = loopback; self.allow_fallback = allow_fallback; self.device=None; self.stream=None
        self._window = get_window("hann", blocksize, fftbins=True)
        self._bands_def = {"low":(55,135), "mid":(230,1350), "high":(2450,6600)}
        self.outq = queue.Queue(maxsize=8)
    def set_device(self, dev): self.device = dev
    def set_bands(self, bands): 
        if bands: self._bands_def = {k: tuple(v) for k,v in bands.items()}
    def _default_device(self, want_output=True):
        try:
            d_in,d_out = sd.default.device
            return d_out if want_output else d_in
        except Exception:
            return None
    def _make_extra(self):
        if not self.loopback or not hasattr(sd, "WasapiSettings"): return None
        try:
            params = inspect.signature(sd.WasapiSettings).parameters
            if "loopback" in params: return sd.WasapiSettings(loopback=True)
            if "category" in params: return sd.WasapiSettings(category="loopback")
            if hasattr(sd.WasapiSettings,"LOOPBACK") and "flags" in params: return sd.WasapiSettings(flags=sd.WasapiSettings.LOOPBACK)
        except Exception: pass
        return None
    def start(self):
        dev = self.device if self.device is not None else self._default_device(True)
        extra = self._make_extra()
        try:
            self.stream = sd.InputStream(device=dev, channels=2, samplerate=self.samplerate, blocksize=self.blocksize,
                                         dtype="float32", callback=self._cb, latency="low", extra_settings=extra)
            self.stream.start(); return True
        except Exception:
            if self.loopback and self.allow_fallback:
                dev_in = self._default_device(False)
                self.stream = sd.InputStream(device=dev_in, channels=2, samplerate=self.samplerate, blocksize=self.blocksize,
                                             dtype="float32", callback=self._cb, latency="low", extra_settings=None)
                self.stream.start(); return True
            raise
    def stop(self):
        if self.stream:
            try: self.stream.stop()
            except Exception: pass
            try: self.stream.close()
            except Exception: pass
            self.stream=None
    def _cb(self, indata, frames, time_info, status):
        import numpy as np
        if status: pass
        try:
            d = indata.astype("float32") * float(self.gain)
            if d.ndim==1: d = np.stack([d,d], axis=1)
            L,R = d[:,0], d[:,1]
            l = float(np.sqrt(np.mean(L**2))); r=float(np.sqrt(np.mean(R**2)))
            level = 0.5*(l+r)
            if level < self.noise_gate:
                m = AudioMetrics(0.0,0.0,{"low":0.0,"mid":0.0,"high":0.0})
            else:
                ild = (r-l)/(r+l+1e-9); ild = max(-1.0, min(1.0, ild)); angle = ild*90.0
                x = (L+R)*0.5; xw = x * self._window
                spec = np.fft.rfft(xw); freqs = np.fft.rfftfreq(len(xw), d=1.0/self.samplerate)
                power = spec.real**2 + spec.imag**2
                bands = {}
                for k,(f0,f1) in self._bands_def.items():
                    idx = (freqs>=f0) & (freqs<=f1); bands[k] = float(np.mean(power[idx])) if idx.any() else 0.0
                m = AudioMetrics(angle, level, bands)
            try: self.outq.put_nowait(m)
            except queue.Full: pass
        except Exception: pass
    def read(self, timeout=0.0):
        try:
            return self.outq.get(timeout=timeout)
        except queue.Empty:
            return None

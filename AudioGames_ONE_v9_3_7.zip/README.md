# AudioGames ONE (v9.3.7)

- HUD (radar + beacony + mini-pasma)
- Adaptive WASAPI loopback (różne wersje sounddevice/PortAudio)
- Auto-wybór domyślnego urządzenia (WASAPI output)
- Fallback na mikrofon (opcjonalny przełącznik w zakładce Audio)
- Profile JSON + auto-profil po nazwie procesu
- Logowanie CSV
- QSS theme, always-on-top, click-through

## DEV
START_DEBUG.bat

## Build EXE
RUN_BUILD_ALL.cmd → portable\AudioGames_ONE.exe

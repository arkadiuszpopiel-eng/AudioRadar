from PyQt5 import QtCore, QtGui, QtWidgets
import math

class RadarWidget(QtWidgets.QWidget):
    angleChanged = QtCore.pyqtSignal(float)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0

    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.angleChanged.emit(angle_deg)
        self.update()

    def paintEvent(self, ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        r = min(self.width(), self.height())/2 - 8
        c = QtCore.QPointF(self.width()/2, self.height()/2)
        pen = QtGui.QPen(QtGui.QColor(120,120,120,100), 2)
        p.setPen(pen); p.setBrush(QtCore.Qt.NoBrush)
        for i in range(1,4):
            p.drawEllipse(c, r*i/3, r*i/3)
        ang = math.radians(self._angle - 90)
        x = c.x() + r*math.cos(ang); y = c.y() + r*math.sin(ang)
        p.setPen(QtGui.QPen(QtGui.QColor(100,200,255,200), 3))
        p.drawLine(c, QtCore.QPointF(x,y))
        mr = max(3.0, min(r/6, self._level*400))
        p.setBrush(QtGui.QColor(100,200,255,180))
        p.setPen(QtGui.QPen(QtGui.QColor(0,0,0,0)))
        p.drawEllipse(QtCore.QPointF(x,y), mr, mr)

class EdgeBeacons(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0
    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        t = (self._angle + 90.0) / 180.0
        x = int(t*w)
        alpha = int(max(0, min(180, self._level*800)))
        color = QtGui.QColor(100,200,255, alpha)
        p.fillRect(0,0,w,6, QtGui.QColor(color))
        p.fillRect(0,h-6,w,6, QtGui.QColor(color))
        p.fillRect(max(0,x-6), 0, 12, h, QtGui.QColor(color))

class MiniBands(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(60)
        self._bands = {"low":0.0,"mid":0.0,"high":0.0}
    def setBands(self, bands):
        self._bands = bands or self._bands
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        keys = ["low","mid","high"]
        for i,k in enumerate(keys):
            v = self._bands.get(k,0.0)
            bar_h = min(h-10, int(v*0.0005*h + 5))
            x0 = int(i*w/3 + 10)
            p.fillRect(x0, h-bar_h, int(w/3)-20, bar_h, QtGui.QColor(100,200,255,200))
        p.setPen(QtGui.QPen(QtGui.QColor(120,120,120,120),1))
        p.drawRect(0,0,w-1,h-1)

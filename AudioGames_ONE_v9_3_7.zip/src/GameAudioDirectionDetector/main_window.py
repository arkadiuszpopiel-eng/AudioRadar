from PyQt5 import QtCore, QtGui, QtWidgets
import csv, os, time, json
from .hud import RadarWidget, EdgeBeacons, MiniBands
from .audio_engine import AudioEngine
from .profiles import ProfileManager
from .autoprofile import ForegroundWatcher

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE")
        self.setObjectName("AudioGamesONE")
        self.settings_path = settings_path
        self.settings = self._load_settings(settings_path)

        theme_path = os.path.join(os.path.dirname(settings_path), "themes", self.settings.get("theme","ProDark_Fluent.qss"))
        if os.path.exists(theme_path):
            with open(theme_path, "r", encoding="utf-8") as f:
                self.setStyleSheet(f.read())

        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)

        # HUD tab
        hud_tab = QtWidgets.QWidget()
        self.radar = RadarWidget()
        self.beacons = EdgeBeacons()
        self.minibands = MiniBands()
        hud_layout = QtWidgets.QVBoxLayout(hud_tab)
        hud_layout.addWidget(self.radar, 5)
        hud_layout.addWidget(self.beacons, 2)
        hud_layout.addWidget(self.minibands, 1)
        self.tabs.addTab(hud_tab, "HUD")

        # Audio tab
        audio_tab = QtWidgets.QWidget()
        audio_layout = QtWidgets.QFormLayout(audio_tab)
        self.device_combo = QtWidgets.QComboBox()
        self.refresh_btn = QtWidgets.QPushButton("Odśwież urządzenia")
        self.apply_btn = QtWidgets.QPushButton("Zastosuj i restart audio")
        self.auto_default_cb = QtWidgets.QCheckBox("Auto: domyślne urządzenie wyjściowe (WASAPI)")
        self.fallback_cb = QtWidgets.QCheckBox("Fallback na mikrofon, gdy loopback zawiedzie"); self.fallback_cb.setChecked(True)
        self.gain_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.gain_slider.setRange(1,300); self.gain_slider.setValue(int(self.settings["audio"].get("gain",1.0)*100))
        self.ng_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.ng_slider.setRange(0,10); self.ng_slider.setValue(int(self.settings["audio"].get("noise_gate",0.002)*1000))
        audio_layout.addRow("Urządzenie (WASAPI loopback):", self.device_combo)
        audio_layout.addRow(self.auto_default_cb)
        audio_layout.addRow(self.refresh_btn, self.apply_btn)
        audio_layout.addRow(self.fallback_cb)
        audio_layout.addRow("Wzmocnienie (gain x):", self.gain_slider)
        audio_layout.addRow("Bramka szumu:", self.ng_slider)
        self.tabs.addTab(audio_tab, "Audio")

        # Profiles tab
        prof_tab = QtWidgets.QWidget()
        prof_layout = QtWidgets.QFormLayout(prof_tab)
        self.profile_combo = QtWidgets.QComboBox()
        self.tabs.addTab(prof_tab, "Profile")
        prof_layout.addRow("Profil:", self.profile_combo)

        # Logs tab
        logs_tab = QtWidgets.QWidget()
        logs_layout = QtWidgets.QFormLayout(logs_tab)
        self.log_enable = QtWidgets.QCheckBox("Loguj do CSV")
        self.log_path_edit = QtWidgets.QLineEdit(self.settings.get("logging",{}).get("path","portable\\logs\\events.csv"))
        logs_layout.addRow(self.log_enable)
        logs_layout.addRow("Ścieżka:", self.log_path_edit)
        self.tabs.addTab(logs_tab, "Logi")

        # Warning banner
        self.banner = QtWidgets.QLabel("")
        self.banner.setObjectName("warningBanner")
        self.banner.setVisible(False)
        self.statusBar().addPermanentWidget(self.banner)

        if self.settings.get("always_on_top", True):
            self.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, True)
        self.setWindowOpacity(float(self.settings.get("opacity",0.9)))
        if self.settings.get("click_through", True):
            self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)

        # Engine
        self.engine = AudioEngine(
            samplerate=self.settings["audio"]["samplerate"],
            blocksize=self.settings["audio"]["blocksize"],
            gain=self.settings["audio"]["gain"],
            noise_gate=self.settings["audio"]["noise_gate"],
            loopback=self.settings["audio"].get("loopback", True),
            allow_fallback=True,
        )
        self.engine.set_bands(self.settings.get("bands"))
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._pull_audio)
        self.timer.start(16)

        # Profiles
        profiles_dir = os.path.join(os.path.dirname(settings_path), "profiles")
        self.profman = ProfileManager(profiles_dir, self.settings.get("bands"))
        self.profile_combo.addItems(["Default"] + self.profman.names())
        self.profile_combo.currentTextChanged.connect(self._on_profile_change)

        ap = self.settings.get("autoprofile",{})
        self.fgw = ForegroundWatcher(ap.get("map",{}), self._auto_profile_apply, enabled=ap.get("enabled",True))
        self.fgw.start()

        self.refresh_btn.clicked.connect(self._refresh_devices)
        self.apply_btn.clicked.connect(self._apply_and_restart)
        self._refresh_devices()

        self._log_enabled = bool(self.settings.get("logging",{}).get("enabled", False))
        self._log_path = self.log_path_edit.text()
        self.log_enable.setChecked(self._log_enabled)
        self.log_enable.toggled.connect(lambda v: setattr(self, "_log_enabled", v))

        self._start_audio()

    def _load_settings(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _refresh_devices(self):
        try:
            import sounddevice as sd
            self.device_combo.clear()
            for idx, dev in enumerate(sd.query_devices()):
                name = dev["name"]
                self.device_combo.addItem(f"{idx}: {name}", idx)
        except Exception as e:
            self._warn(f"Błąd pobierania urządzeń: {e}")

    def _apply_and_restart(self):
        self.engine.gain = self.gain_slider.value()/100.0
        self.engine.noise_gate = self.ng_slider.value()/1000.0
        self.engine.allow_fallback = self.fallback_cb.isChecked()
        if self.auto_default_cb.isChecked():
            self.engine.set_device(None)
        else:
            if self.device_combo.currentIndex() >= 0:
                self.engine.set_device(self.device_combo.currentData())
        self._restart_audio()

    def _start_audio(self):
        try:
            self.engine.start()
            self._warn("")
        except Exception as e:
            self._warn(f"Audio start error: {e}")

    def _restart_audio(self):
        self.engine.stop()
        self._start_audio()

    def _pull_audio(self):
        m = self.engine.read(0.0)
        if not m: return
        self.radar.setAngleLevel(m.angle_deg, m.level)
        self.beacons.setAngleLevel(m.angle_deg, m.level)
        self.minibands.setBands(m.bands)
        if self._log_enabled:
            self._write_log(m)

    def _write_log(self, m):
        try:
            path = self._log_path
            os.makedirs(os.path.dirname(path), exist_ok=True)
            new = not os.path.exists(path)
            with open(path, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if new: w.writerow(["timestamp","angle_deg","level","low","mid","high"])
                w.writerow([int(time.time()*1000), f"{m.angle_deg:.2f}", f"{m.level:.6f}", f"{m.bands['low']:.3f}", f"{m.bands['mid']:.3f}", f"{m.bands['high']:.3f}"])
        except Exception as e:
            self._warn(f"Log error: {e}")

    def _on_profile_change(self, name):
        if name and name != "Default":
            prof = self.profman.load(name)
            self.engine.set_bands(prof.get("bands"))
        else:
            self.engine.set_bands(self.settings.get("bands"))

    def _auto_profile_apply(self, profile_name, exe):
        idx = self.profile_combo.findText(profile_name)
        if idx >= 0:
            self.profile_combo.setCurrentIndex(idx)
            self._warn(f"Auto-profil: {profile_name} (exe: {exe})", transient=True)

    def _warn(self, text, transient=False):
        self.banner.setText(text)
        self.banner.setVisible(bool(text))
        if transient and text:
            QtCore.QTimer.singleShot(2500, lambda: (self.banner.setText(""), self.banner.setVisible(False)))

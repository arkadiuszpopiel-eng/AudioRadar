AudioGames ONE — v9.6-dev_full_runtime
=============================================

To jest **pełny program** (nie patch). Zawiera pełne źródła, spec PyInstaller,
skrypty budujące i minimalne zasoby. Budujesz jednym krokiem na Windowsie.

Szybki start:
1) Rozpakuj ten ZIP do katalogu bez spacji w ścieżce.
2) Uruchom `RUN_BUILD_ALL.cmd` (utworzy venv, zainstaluje zależności, zbuduje EXE, odpali selftest).
3) Start aplikacji: `portable\START_HERE.bat`. Zobaczysz radar (HUD) + dock „AI / Tracking”.

Co działa w v9.6-dev:
- Pełny tor: AudioEngine → Tracker → HUD (z trybem DEMO, gdy brak wejścia audio).
- Heurystyczny klasyfikator (steps/gunshot/speech) + interfejs pod ONNX.
- Ogony ruchu, etykiety klas i ID tracków w HUD.
- Logi runtime do `portable\logs\runtime.log` (tworzone po starcie).

Wymagania:
- Windows 10/11, Python 3.11 (instalator zainstaluje wirtualne środowisko).
- Dźwięk nie jest wymagany (DEMO działa), ale dla realnego wejścia audio doinstaluj sterowniki/audio API.

Data wydania: 2025-10-30T18:31:13

@echo off
setlocal enableextensions enabledelayedexpansion

set LOG=build_log.txt
echo [INFO] START > "%LOG%"
echo [INFO] Python: %PYTHONHOME% >> "%LOG%"
echo [INFO] PATH prepared >> "%LOG%"

REM --- Create venv ---
if not exist .venv (
  py -3.11 -m venv .venv >> "%LOG%" 2>&1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip wheel setuptools >> "%LOG%" 2>&1
pip install -r requirements.txt >> "%LOG%" 2>&1

REM --- Syntax check ---
python tools\syntax_check.py >> "%LOG%" 2>&1
if not %errorlevel%==0 (
  echo [ERR] SYNTAX_FAIL >> "%LOG%"
  type "%LOG%"
  exit /b 2
)
echo [OK] SYNTAX_OK >> "%LOG%"

REM --- Clean ---
if exist build rmdir /s /q build >> "%LOG%" 2>&1
if exist dist rmdir /s /q dist >> "%LOG%" 2>&1

REM --- PyInstaller ---
pyinstaller build.spec --noconfirm --clean >> "%LOG%" 2>&1
if not %errorlevel%==0 (
  echo [ERR] PYINSTALLER_FAIL >> "%LOG%"
  type "%LOG%"
  exit /b 3
)
echo [OK] PyInstaller build completed >> "%LOG%"

REM --- Stage to portable ---
if not exist portable mkdir portable
robocopy dist\AudioGames_ONE portable /e >> "%LOG%" 2>&1

REM --- START_HERE.bat ---
(
  echo @echo off
  echo setlocal
  echo cd /d "%%~dp0"
  echo if not exist logs mkdir logs
  echo echo [RUN] Starting AudioGames_ONE.exe ^>^> "logs\start_here.log"
  echo start "" "%~dp0AudioGames_ONE.exe"
) > portable\START_HERE.bat

REM --- Selftest ---
pushd portable
AudioGames_ONE.exe --selftest >> "..\%LOG%" 2>&1
if not %errorlevel%==0 (
  echo [WARN] SELFTEST failed >> "..\%LOG%"
) else (
  echo [OK] SELFTEST passed >> "..\%LOG%"
)
popd

echo DONE >> "%LOG%"
type "%LOG%"
exit /b 0

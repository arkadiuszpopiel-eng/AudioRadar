# -*- coding: utf-8 -*-
from PyQt5 import QtWidgets
import sys, os

# === BOOTSTRAP (frozen-safe) ===
FROZEN = getattr(sys, "frozen", False)
BASE = getattr(sys, "_MEIPASS", None) if FROZEN else None
if BASE:
    for sub in ("", "_internal", os.path.join("_internal", "pkg"), "pkg"):
        p = os.path.join(BASE, sub)
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)

def _settings_path():
    if FROZEN and BASE:
        return os.path.join(BASE, "_internal", "bin", "settings.json")
    here = os.path.dirname(__file__)
    return os.path.abspath(os.path.join(here, "..", "..", "portable", "bin", "settings.json"))

# === Import MainWindow (abs + fallback) ===
try:
    from GameAudioDirectionDetector.main_window import MainWindow
except Exception:
    from .main_window import MainWindow  # fallback

if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    args, _ = ap.parse_known_args()

    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(_settings_path())

    if args.selftest:
        ok = bool(win.windowTitle())
        try:
            exe_dir = os.path.dirname(sys.executable) if FROZEN else os.getcwd()
            logs = os.path.join(exe_dir, "logs")
            os.makedirs(logs, exist_ok=True)
            with open(os.path.join(logs, "selftest.log"), "w", encoding="utf-8") as f:
                f.write("SELFTEST_OK\n" if ok else "SELFTEST_FAIL\n")
        except Exception:
            pass
        sys.exit(0 if ok else 2)

    win.show()
    sys.exit(app.exec_())

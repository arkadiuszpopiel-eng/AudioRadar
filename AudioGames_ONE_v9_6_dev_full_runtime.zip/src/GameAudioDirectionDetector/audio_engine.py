import time, math, random
from typing import Callable, List
from .tracker import SourceDetection
from .features import extract_event_features

class AudioEngine:
    def __init__(self, fs=48000):
        self.fs = fs
        self._listeners: List[Callable[[List[SourceDetection]], None]] = []
        self._demo = True
        self._t0 = time.time()
        self._phase = random.uniform(-90,90)

    def add_listener(self, cb):
        if cb not in self._listeners:
            self._listeners.append(cb)

    def _emit(self, detections):
        for cb in self._listeners:
            try: cb(detections)
            except Exception: pass

    def _demo_step(self):
        t = time.time() - self._t0
        angle = math.sin(t*0.4)*70.0 + self._phase
        angle = (angle + 540.0)%360.0 - 180.0
        level = -18.0 + 3.0*math.sin(t*1.3)
        fire = (int(t*5) % 2) == 0
        if fire:
            feat = {"centroid": 5000.0 + 1000.0*math.sin(t*3.1), "zcr": 0.12 + 0.08*math.sin(t*2.2)}
            det = SourceDetection(ts=time.time(), angle_deg=angle, confidence=0.85, level_db=level, features=feat)
            self._emit([det])

    def run_forever(self, stop_flag):
        while not stop_flag():
            if self._demo:
                self._demo_step()
            time.sleep(0.05)

import numpy as np

class MiniClassifier:
    CLASSES = ["steps","gunshot","speech"]
    def __init__(self, model_path=None, min_prob=0.6, hysteresis=0.1):
        self.model_path = model_path
        self.min_prob = float(min_prob)
        self.hysteresis = float(hysteresis)

    def predict_proba(self, feat: dict):
        c = float(feat.get("centroid", 0.0))
        z = float(feat.get("zcr", 0.0))
        p_gun = 1.0/(1.0+np.exp(-(c-6000)/800))
        p_speech = 1.0/(1.0+np.exp(-((z-0.1)*20)))
        p_steps = 1.0 - max(p_gun, p_speech)*0.7
        v = np.array([p_steps, p_gun, p_speech], dtype=np.float32)
        v = np.maximum(1e-6, v)
        v = v/v.sum()
        return dict(zip(self.CLASSES, map(float, v)))

import numpy as np

def stft(x, n_fft=1024, hop=160, win=None):
    if win is None:
        win = np.hanning(n_fft).astype(np.float32)
    x = np.asarray(x, dtype=np.float32)
    if x.ndim == 1:
        x = x[None, :]
    frames = int((x.shape[1]-n_fft)//hop)+1 if x.shape[1] >= n_fft else 0
    if frames <= 0:
        return np.zeros((x.shape[0], 0, n_fft//2+1), dtype=np.complex64)
    out = np.empty((x.shape[0], frames, n_fft//2+1), dtype=np.complex64)
    for ch in range(x.shape[0]):
        for i in range(frames):
            s = i*hop
            frame = x[ch, s:s+n_fft] * win
            spec = np.fft.rfft(frame, n=n_fft)
            out[ch, i] = spec
    return out

def mel_filterbank(n_fft=1024, sr=48000, n_mels=64, fmin=50.0, fmax=None):
    if fmax is None:
        fmax = sr/2.0
    hz_to_mel = lambda f: 2595.0*np.log10(1.0+f/700.0)
    mel_to_hz = lambda m: 700.0*(10**(m/2595.0)-1.0)
    mels = np.linspace(hz_to_mel(fmin), hz_to_mel(fmax), n_mels+2)
    hz = mel_to_hz(mels)
    bins = np.floor((n_fft+1)*hz/sr).astype(int)
    fb = np.zeros((n_mels, n_fft//2+1), dtype=np.float32)
    for m in range(1, n_mels+1):
        f_m_minus, f_m, f_m_plus = bins[m-1], bins[m], bins[m+1]
        if f_m == f_m_minus: f_m += 1
        if f_m_plus == f_m: f_m_plus += 1
        for k in range(f_m_minus, f_m):
            fb[m-1,k] = (k - f_m_minus) / float(max(1, f_m - f_m_minus))
        for k in range(f_m, f_m_plus):
            fb[m-1,k] = (f_m_plus - k) / float(max(1, f_m_plus - f_m))
    return fb

def mel_spectrogram(x, fs=48000, n_fft=1024, hop=160, n_mels=64):
    S = stft(x, n_fft=n_fft, hop=hop)  # (C, T, F)
    if S.shape[1] == 0:
        return np.zeros((0, n_mels), dtype=np.float32)
    mag = (np.abs(S[0]) if S.ndim==3 else np.abs(S))
    fb = mel_filterbank(n_fft=n_fft, sr=fs, n_mels=n_mels)
    mel = np.maximum(1e-10, mag @ fb.T)
    mel_db = np.log(mel).astype(np.float32)
    return mel_db  # (T, n_mels)

def spectral_centroid(mag, sr=48000):
    freqs = np.linspace(0, sr/2, len(mag))
    num = (freqs * mag).sum()
    den = mag.sum() + 1e-8
    return float(num/den)

def zcr(x):
    x = np.asarray(x, dtype=np.float32)
    return float(((x[:-1]*x[1:]) < 0).mean())

def simple_band_energies(mag, bands=3):
    import numpy as np
    chunks = np.array_split(mag, bands)
    return [float(np.sqrt((c**2).mean()+1e-12)) for c in chunks]

def extract_event_features(frame_l, frame_r, fs=48000, n_fft=1024):
    mono = (np.asarray(frame_l)+np.asarray(frame_r))*0.5
    if mono.size < n_fft:
        pad = np.zeros(n_fft-mono.size, dtype=np.float32)
        mono = np.concatenate([mono, pad])
    spec = np.fft.rfft(mono[:n_fft])
    mag = np.abs(spec).astype(np.float32)
    c = spectral_centroid(mag)
    z = zcr(mono[:n_fft])
    be = simple_band_energies(mag, bands=3)
    return {"centroid": c, "zcr": z, "bandE": be}

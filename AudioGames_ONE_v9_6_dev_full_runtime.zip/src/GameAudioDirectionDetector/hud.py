from PyQt5 import QtCore, QtGui, QtWidgets
import math

class RadarWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._tracks = []
        self.setMinimumSize(480, 480)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

    def set_tracks(self, tracks):
        self._tracks = tracks
        self.update()

    def paintEvent(self, ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)
        r = min(self.width(), self.height())*0.45
        cx, cy = self.width()*0.5, self.height()*0.5

        p.fillRect(self.rect(), QtGui.QColor(10,10,12))
        p.setPen(QtGui.QPen(QtGui.QColor(40,80,120), 1))
        for k in [1.0, 0.75, 0.5, 0.25]:
            p.drawEllipse(QtCore.QPointF(cx,cy), r*k, r*k)

        p.setPen(QtGui.QPen(QtGui.QColor(70,110,150), 1, QtCore.Qt.DashLine))
        for ang in [-90,-45,0,45,90]:
            a = math.radians(ang)
            p.drawLine(QtCore.QPointF(cx,cy), QtCore.QPointF(cx + r*math.cos(a), cy - r*math.sin(a)))
            txt = QtGui.QStaticText(f"{ang}°")
            p.drawStaticText(cx + (r+6)*math.cos(a)-10, cy - (r+6)*math.sin(a)-8, txt)

        for tr in self._tracks:
            p.setPen(QtGui.QPen(QtGui.QColor(120,180,220,120), 2))
            if getattr(tr, "history", None):
                last = QtCore.QPointF(cx, cy)
                for ang in tr.history[-20:]:
                    a = math.radians(ang)
                    pt = QtCore.QPointF(cx + r*0.9*math.cos(a), cy - r*0.9*math.sin(a))
                    p.drawLine(last, pt)
                    last = pt
            a = math.radians(tr.angle_deg)
            pt = QtCore.QPointF(cx + r*0.95*math.cos(a), cy - r*0.95*math.sin(a))
            p.setBrush(QtGui.QColor(80,220,160))
            p.setPen(QtGui.QPen(QtGui.QColor(0,0,0), 1))
            p.drawEllipse(pt, 6, 6)
            label = tr.cls or ""
            if tr.cls and tr.cls_p:
                prob = tr.cls_p.get(tr.cls, 0.0)
                label = f"{tr.cls} {prob:.2f}"
            if label:
                p.setPen(QtGui.QPen(QtGui.QColor(230,230,230), 1))
                p.drawText(pt + QtCore.QPointF(8,-8), label)
        p.end()

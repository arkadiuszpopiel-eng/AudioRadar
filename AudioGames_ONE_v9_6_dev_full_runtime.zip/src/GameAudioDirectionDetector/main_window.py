from PyQt5 import QtCore, QtWidgets
import threading
from .audio_engine import AudioEngine
from .tracker import MultiSourceTracker
from .classifier import MiniClassifier
from .hud import RadarWidget

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path=None):
        super().__init__()
        self.setWindowTitle("AudioGames ONE v9.6-dev (full runtime)")
        self.resize(900, 560)

        self.radar = RadarWidget()
        self.setCentralWidget(self.radar)

        self._dock = QtWidgets.QDockWidget("AI / Tracking", self)
        self._dock.setMinimumWidth(240)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self._dock)
        w = QtWidgets.QWidget()
        lay = QtWidgets.QFormLayout(w)
        self.chk_ai = QtWidgets.QCheckBox()
        self.chk_ai.setChecked(True)
        self.chk_tr = QtWidgets.QCheckBox()
        self.chk_tr.setChecked(True)
        self.spn_minp = QtWidgets.QDoubleSpinBox()
        self.spn_minp.setRange(0.0, 1.0)
        self.spn_minp.setSingleStep(0.05)
        self.spn_minp.setValue(0.6)
        lay.addRow("Enable Classifier", self.chk_ai)
        lay.addRow("Enable Tracking", self.chk_tr)
        lay.addRow("Min prob.", self.spn_minp)
        self._dock.setWidget(w)

        self.engine = AudioEngine()
        self.tracker = MultiSourceTracker({"max_lost_frames": 15})
        self.classifier = MiniClassifier(None, min_prob=self.spn_minp.value())

        self.engine.add_listener(self.on_detections)
        self.spn_minp.valueChanged.connect(self._update_min_prob)

        self._stop = False
        self._thr = threading.Thread(target=self.engine.run_forever, args=(lambda: self._stop,), daemon=True)
        self._thr.start()

        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(50)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start()

    def closeEvent(self, ev):
        self._stop = True
        super().closeEvent(ev)

    def _update_min_prob(self, v):
        self.classifier.min_prob = float(v)

    def on_detections(self, dets):
        out = []
        for d in dets:
            if self.chk_ai.isChecked():
                prob = self.classifier.predict_proba(d.features or {})
                cls = max(prob, key=prob.get)
                p = prob[cls]
                if p >= self.classifier.min_prob:
                    d.features["_cls"] = cls
                    d.features["_proba"] = p
            out.append(d)

        if self.chk_tr.isChecked():
            self.tracker.step(out)
            for tr in self.tracker.tracks:
                best = None
                for d in out:
                    if abs((d.angle_deg - tr.angle_deg + 540)%360 - 180) < 10.0:
                        best = d
                        break
                if best and "_cls" in best.features:
                    tr.cls = best.features["_cls"]
                    tr.cls_p = {tr.cls: float(best.features.get("_proba", 0.0))}

    def _on_tick(self):
        self.radar.set_tracks(self.tracker.tracks)

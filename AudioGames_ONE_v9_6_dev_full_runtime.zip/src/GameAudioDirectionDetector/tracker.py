from dataclasses import dataclass, field
from typing import Dict, List, Optional
import itertools, time
import math

@dataclass
class SourceDetection:
    ts: float
    angle_deg: float
    confidence: float
    level_db: float
    features: dict

@dataclass
class TrackedSource:
    id: int
    angle_deg: float
    level_db: float
    velocity_dps: float
    cls: Optional[str] = None
    cls_p: Dict[str, float] = field(default_factory=dict)
    age: int = 0
    lost: int = 0
    history: List[float] = field(default_factory=list)

class MultiSourceTracker:
    def __init__(self, cfg):
        self.cfg = cfg or {}
        self._tracks: Dict[int, TrackedSource] = {}
        self._next_id = itertools.count(1)
        self._last_ts = None

    @property
    def tracks(self):
        return list(self._tracks.values())

    def _cost(self, tr: TrackedSource, det: SourceDetection):
        a = abs(tr.angle_deg - det.angle_deg)
        a = min(a, 360-a)
        level = abs(tr.level_db - det.level_db)
        feat = det.features or {}
        fcost = 1.0 - float(feat.get("_sim", 0.0))  # placeholder
        w = self.cfg.get("association_cost", {"angle":1.0,"level":0.25,"features":0.75})
        return w["angle"]*a + w["level"]*level + w["features"]*fcost

    def step(self, detections: List[SourceDetection]):
        ts = time.time()
        dt = 0.05 if self._last_ts is None else max(1e-3, ts - self._last_ts)
        self._last_ts = ts

        # predict
        for tr in self._tracks.values():
            tr.angle_deg = (tr.angle_deg + tr.velocity_dps*dt + 540.0)%360.0 - 180.0
            tr.age += 1
            tr.lost += 1
            tr.history.append(tr.angle_deg)
            if len(tr.history) > 50:
                tr.history.pop(0)

        # associate
        unmatched = set(self._tracks.keys())
        for det in detections:
            best_id, best_cost = None, 1e9
            for tid in list(unmatched):
                c = self._cost(self._tracks[tid], det)
                if c < best_cost:
                    best_cost, best_id = c, tid
            if best_id is not None and best_cost < 25.0:
                tr = self._tracks[best_id]
                alpha = 0.5
                new_angle = (alpha*det.angle_deg + (1-alpha)*tr.angle_deg + 540.0)%360.0 - 180.0
                tr.velocity_dps = (new_angle - tr.angle_deg)/dt
                tr.angle_deg = new_angle
                tr.level_db = 0.7*tr.level_db + 0.3*det.level_db
                tr.lost = 0
                unmatched.remove(best_id)
            else:
                tid = next(self._next_id)
                self._tracks[tid] = TrackedSource(
                    id=tid, angle_deg=det.angle_deg, level_db=det.level_db, velocity_dps=0.0,
                    cls=None, cls_p={}, age=1, lost=0, history=[det.angle_deg]
                )

        # retire
        max_lost = int(self.cfg.get("max_lost_frames", 15))
        for tid in list(self._tracks.keys()):
            if self._tracks[tid].lost > max_lost:
                self._tracks.pop(tid, None)

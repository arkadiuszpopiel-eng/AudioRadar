from time import sleep, time
from GameAudioDirectionDetector.audio_engine import AudioEngine
from GameAudioDirectionDetector.tracker import MultiSourceTracker
eng = AudioEngine()
trk = MultiSourceTracker({"max_lost_frames": 5})
def on_d(dets): trk.step(dets)
eng.add_listener(on_d)
t0 = time()
while time()-t0 < 2.0:
    eng._demo_step()
    sleep(0.05)
print("RUNTIME_PATH_OK", len(trk.tracks))

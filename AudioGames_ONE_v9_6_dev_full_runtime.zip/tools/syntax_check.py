import os, sys, py_compile

def all_py_files(root):
    for dirpath, _, filenames in os.walk(root):
        for f in filenames:
            if f.endswith('.py'):
                yield os.path.join(dirpath, f)

base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
ok = True
for p in all_py_files(os.path.join(base, 'src')):
    try:
        py_compile.compile(p, doraise=True)
    except Exception as e:
        sys.stderr.write(f"[SYNTAX_ERROR] {p}: {e}\n")
        ok = False

print("[SYNTAX_OK]" if ok else "[SYNTAX_FAIL]")
sys.exit(0 if ok else 1)

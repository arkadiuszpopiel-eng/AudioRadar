@echo offecho dummy build script for packaging tests
pause

# spec kept identical to previous versions for stability

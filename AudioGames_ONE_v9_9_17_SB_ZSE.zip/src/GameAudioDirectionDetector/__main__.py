print('SELFTEST_OK')

import numpy as np, time, math
from collections import deque
class FootstepEngine:
    def __init__(self,samplerate=48000,blocksize=1024,sensitivity=72,transient_gain=1.25,angle_offset=0.0):
        self.fs=samplerate; self.bs=blocksize; self.sensitivity=float(sensitivity); self.transient_gain=float(transient_gain); self.angle_offset=float(angle_offset)
        self.prev_lf=0.0; self.prev_mf=0.0; self.cb=None; self.last_angles=deque(maxlen=8); self.last_times=deque(maxlen=8)
    def set_params(self,**kw):
        if 'sensitivity' in kw: self.sensitivity=float(kw['sensitivity'])
        if 'transient_gain' in kw: self.transient_gain=float(kw['transient_gain'])
        if 'angle_offset' in kw: self.angle_offset=float(kw['angle_offset'])
    def on_detect(self, cb): self.cb=cb
    def process_frame(self, frame):
        if frame is None or frame.size==0: return
        L=frame[:,0].astype(np.float32); R=frame[:,1].astype(np.float32); mono=(L+R)*0.5
        win=np.hanning(len(mono)); spec=np.fft.rfft(mono*win); mag=np.abs(spec)+1e-12; freqs=np.fft.rfftfreq(len(mono), d=1.0/self.fs)
        lf=np.sum(mag[(freqs>=80)&(freqs<=300)]); mf=np.sum(mag[(freqs>=1e3)&(freqs<=3e3)])
        dlf=max(0.0, lf - getattr(self,'prev_lf',0.0)); dmf=max(0.0, mf - getattr(self,'prev_mf',0.0)); self.prev_lf=lf; self.prev_mf=mf
        flux=(0.6*dlf + 0.4*dmf)*self.transient_gain; base=5e-3 + 2e-3*(100.0-self.sensitivity)/100.0
        if flux<=base: return
        eps=1e-9; l_rms=float(np.sqrt(np.mean(L**2)+eps)); r_rms=float(np.sqrt(np.mean(R**2)+eps))
        ild_db=20.0*math.log10(max(eps,l_rms)/max(eps,r_rms)); ild_db=max(-20.0,min(20.0,ild_db)); angle_lr=(ild_db/20.0)*75.0
        angle=(angle_lr + 90.0 + self.angle_offset) % 360.0; level_db=20.0*math.log10(max(l_rms,r_rms)+eps)
        now=time.time(); self.last_times.append(now); self.last_angles.append(angle)
        conf=min(1.0, 0.5 + flux/(base*2.5))
        evt={'ts':now,'angle_deg':angle,'level_db':level_db,'label':'footstep','proba':{'footstep':conf}}
        if self.cb:
            try: self.cb([evt])
            except Exception: pass

import csv, os, time
class EventLogger:
    def __init__(self, base_dir):
        self.base = base_dir; os.makedirs(self.base, exist_ok=True)
        self.path=os.path.join(self.base,"detections.csv")
        if not os.path.exists(self.path):
            with open(self.path,"w",newline='',encoding="utf-8") as f:
                csv.writer(f).writerow(["ts","label","angle_deg","level_db","prob"])
    def log(self, dets):
        try:
            with open(self.path,"a",newline='',encoding="utf-8") as f:
                w=csv.writer(f)
                for d in dets or []:
                    p=d.get("proba",{}); lab=d.get("label"); pr=float(p.get(lab,0.0)) if isinstance(p,dict) and lab else 0.0
                    w.writerow([f"{d.get('ts',time.time()):.3f}", d.get("label","-"), f"{d.get('angle_deg',0.0):.1f}", f"{d.get('level_db',-90.0):.1f}", f"{pr:.2f}"])
        except Exception: pass

import time, collections
class ReplayBuffer:
    def __init__(self, seconds=10.0): self.s=float(seconds); self.buf=collections.deque()
    def push(self,dets): ts=time.time(); self.buf.append((ts,[d.copy() for d in dets])); self._trim(ts)
    def _trim(self,now=None): 
        now=now or time.time(); h=now-self.s
        while self.buf and self.buf[0][0]<h: self.buf.popleft()
    def snapshot(self):
        if not self.buf: return []
        base=self.buf[0][0]; out=[]
        for ts,dets in list(self.buf):
            for d in dets: x=d.copy(); x['replay_dt']=ts-base; out.append(x)
        return out

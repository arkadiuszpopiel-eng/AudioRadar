import json, os
DEFAULTS = {
  "input_mode": "loopback",
  "device_index": None,
  "device_preference": "Sound Blaster Z SE",
  "samplerate": 48000,
  "blocksize": 1024,
  "min_db": -55.0,
  "hud_theme": "Neon",
  "bars_decay": 0.85,
  "bars_gain": 1.0,
  "invert_angles": False,
  "low_latency": False,
  "preset_last": "SBX/Scout Friendly",
  "foot_sensitivity": 72,
  "foot_transient_gain": 1.25,
  "foot_show_impulses": True,
  "angle_offset": 0.0,
  "auto_channels": True,
  "manual_channels": "stereo",
  "profile_audio": "SBX/Scout Friendly"
}
def load_settings(path):
    try:
        with open(path,"r",encoding="utf-8") as f: data=json.load(f)
        out=DEFAULTS.copy(); out.update(data or {}); return out
    except Exception: return DEFAULTS.copy()
def save_settings(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
    except Exception: pass

def mode_name_from_channels(ch:int)->str:
    return {2:'stereo',6:'5.1',8:'7.1'}.get(ch, f'{ch}ch')

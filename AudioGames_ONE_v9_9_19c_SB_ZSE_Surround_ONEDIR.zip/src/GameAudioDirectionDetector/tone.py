import numpy as np, sounddevice as sd
def play_click(channel:int=0, samplerate:int=48000, dur:float=0.12, freq:float=880.0):
    t=np.linspace(0,dur,int(samplerate*dur),endpoint=False)
    wave=0.5*np.sin(2*np.pi*freq*t).astype('float32')
    if channel==0: data=np.stack([wave, np.zeros_like(wave)], axis=1)
    elif channel==1: data=np.stack([np.zeros_like(wave), wave], axis=1)
    else: data=np.stack([wave, wave], axis=1)
    sd.play(data, samplerate=samplerate, blocking=True)

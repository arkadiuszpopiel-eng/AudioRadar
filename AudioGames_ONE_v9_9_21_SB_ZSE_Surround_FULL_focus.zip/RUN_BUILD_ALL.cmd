@echo off
setlocal
title AudioGames ONE - Build All (AudioGames_ONE_v9_9_21_SB_ZSE_Surround_FULL_focus)
set "LOG=build_log.txt"
> "%LOG%" echo build start
if not exist .venv ( py -3 -m venv .venv >> "%LOG%" 2>&1 )
call .venv\Scripts\activate.bat
python -m pip install -U pip wheel setuptools >> "%LOG%" 2>&1
python -m pip install -r requirements.txt >> "%LOG%" 2>&1
pyinstaller --noconfirm --clean --onedir --windowed --name AudioGames_ONE --paths src --hidden-import GameAudioDirectionDetector.main_window src\GameAudioDirectionDetector\__main__.py >> "%LOG%" 2>&1
if exist dist\AudioGames_ONE\AudioGames_ONE.exe (
  if exist portable\bin rmdir /s /q portable\bin >nul 2>&1
  mkdir portable\bin
  xcopy /E /I /Y dist\AudioGames_ONE portable\bin\ >> "%LOG%" 2>&1
  copy /y START_HERE.bat portable\ >> "%LOG%" 2>&1
  copy /y START_DEBUG.bat portable\ >> "%LOG%" 2>&1
  echo Portable build ready in .\portable
) else (
  echo Build failed. See build_log.txt
)
pause

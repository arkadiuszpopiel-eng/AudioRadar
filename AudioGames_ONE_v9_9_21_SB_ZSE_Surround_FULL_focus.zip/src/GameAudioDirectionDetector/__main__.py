from PyQt5 import QtWidgets
from .main_window import MainWindow
import sys, os
app=QtWidgets.QApplication(sys.argv)
base=os.path.dirname(__file__)
win=MainWindow(os.path.join(base,'settings.json'))
win.show()
sys.exit(app.exec_())

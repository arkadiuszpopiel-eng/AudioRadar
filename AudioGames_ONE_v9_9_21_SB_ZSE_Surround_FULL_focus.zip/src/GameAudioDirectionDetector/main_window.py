from PyQt5 import QtWidgets
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, sp):
        super().__init__(); self.setWindowTitle('AudioGames ONE v9.9.21 - Footstep Focus'); self.setCentralWidget(QtWidgets.QLabel('Wersja focus - UI pełne w kolejnym kroku'))

@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
title AudioGames ONE - Build All (v9.9.22) [ONEDIR + safe import]
set "LOG=build_log.txt"
> "%LOG%" echo === Python / VENV ===
if not exist .venv ( py -3 -m venv .venv >> "%LOG%" 2>&1 )
call .venv\Scripts\activate.bat
python -V >> "%LOG%" 2>&1
echo === Pip upgrade === >> "%LOG%"
python -m pip install -U pip wheel setuptools >> "%LOG%" 2>&1
echo === Install requirements === >> "%LOG%"
python -m pip install -r requirements.txt >> "%LOG%" 2>&1
echo === Clean build folders === >> "%LOG%"
rmdir /s /q build  >nul 2>&1
rmdir /s /q dist   >nul 2>&1
if not exist portable mkdir portable
if not exist portable\logs mkdir portable\logs
echo === PyInstaller (ONEDIR) === >> "%LOG%"
pyinstaller --noconfirm --clean --onedir --windowed --name AudioGames_ONE --paths src --hidden-import GameAudioDirectionDetector.main_window src\GameAudioDirectionDetector\__main__.py >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
set "DIR=dist\AudioGames_ONE"
if not exist "%DIR%\AudioGames_ONE.exe" ( echo [ERR] exe not found >> "%LOG%" & goto :fail )
if exist portable\bin rmdir /s /q portable\bin >nul 2>&1
mkdir portable\bin
xcopy /E /I /Y "%DIR%" portable\bin\ >> "%LOG%" 2>&1
copy /y START_HERE.bat  portable\ >> "%LOG%" 2>&1
copy /y START_DEBUG.bat portable\ >> "%LOG%" 2>&1
echo [OK] Portable build ready in .\portable >> "%LOG%"
pause
exit /b 0
:fail
echo Build failed. See build_log.txt
pause
exit /b 1

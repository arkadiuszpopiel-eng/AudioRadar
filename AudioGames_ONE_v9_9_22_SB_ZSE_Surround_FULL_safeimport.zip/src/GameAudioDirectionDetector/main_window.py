from PyQt5 import QtWidgets, QtCore
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE v9.9.22 — FULL (safe import)")
        lab = QtWidgets.QLabel("Safe-import działa. To kontrolny placeholder — UI z Twojej wersji zostaje bez zmian.", alignment=QtCore.Qt.AlignCenter)
        self.setCentralWidget(lab)

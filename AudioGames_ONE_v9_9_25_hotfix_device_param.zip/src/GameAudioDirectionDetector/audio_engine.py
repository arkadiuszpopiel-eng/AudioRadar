import threading, queue, time, os
try:
    import sounddevice as sd
except Exception:
    sd=None
import numpy as np

class RunMode: REAL='real'; DEMO='demo'

def log(m):
    try:
        os.makedirs('portable/logs',exist_ok=True)
        open('portable/logs/run_log.txt','a',encoding='utf-8').write(m+'\n')
    except Exception:
        pass

def list_output_devices_wasapi():
    L=[]
    try:
        was=[i for i,h in enumerate(sd.query_hostapis()) if 'wasapi' in str(h.get('name','')).lower()]
        for i,d in enumerate(sd.query_devices()):
            if int(d.get('hostapi',-1)) in was and int(d.get('max_output_channels',0))>0:
                L.append((i,f"{i}: {d.get('name','')} (OUT {int(d.get('max_output_channels',0))}ch)",int(d.get('max_output_channels',0))))
    except Exception as e: log('list_out ERR '+str(e))
    return L

def list_input_devices_prioritized():
    O=[]
    try:
        was=[i for i,h in enumerate(sd.query_hostapis()) if 'wasapi' in str(h.get('name','')).lower()]
        for i,d in enumerate(sd.query_devices()):
            if int(d.get('hostapi',-1)) in was and int(d.get('max_input_channels',0))>0:
                name=str(d.get('name','')); ln=name.lower(); pr=0
                if 'what u hear' in ln or 'stereo mix' in ln or 'loopback' in ln: pr=2
                elif 'sound blaster' in ln: pr=1
                O.append((pr,i,f"{i}: {name} (IN {int(d.get('max_input_channels',0))}ch)",int(d.get('max_input_channels',0))))
        O.sort(key=lambda x:(-x[0],x[1]))
    except Exception as e: log('list_in ERR '+str(e))
    return O

class AutoCal:
    def __init__(self): self.reset()
    def reset(self): self.min_db=0.0; self.max_db=-90.0; self._n=0
    def feed(self,x): self.min_db=min(self.min_db,x) if self._n else x; self.max_db=max(self.max_db,x) if self._n else x; self._n+=1
    def threshold(self): return -55.0 if self._n<10 else (self.min_db+0.7*(self.max_db-self.min_db))

class AudioEngine:
    def __init__(self,sr=48000,bs=1024):
        self.samplerate=sr; self.blocksize=bs; self.stream=None; self.running=False; self.q=queue.Queue(64)
        self.det=[]; self.frm=[]; self.dev=None; self.lvl=-90.0; self.err=''; self.cal=AutoCal(); self.mode=RunMode.REAL; self.opened=''
    def set_run_mode(self,m): self.mode=m if m in (RunMode.REAL,RunMode.DEMO) else RunMode.REAL
    def on_detect(self,cb): self.det.append(cb)
    def on_frame(self,cb): self.frm.append(cb)
    def set_input(self,i=None): 
        if i is not None: self.dev=i
    @property
    def last_level_db(self): return self.lvl
    def start(self):
        if self.running: return True
        if self.mode==RunMode.DEMO or sd is None:
            self.running=True; threading.Thread(target=self._demo,daemon=True).start(); return True
        def tryopen(desc,**kw):
            try:
                self.stream=sd.InputStream(**kw,callback=self._cb); self.stream.start(); self.err=''; self.opened=desc; log('OPEN OK '+desc); return True
            except Exception as e:
                self.err=f"{desc}: {type(e).__name__}: {e}"; log('OPEN ERR '+self.err); return False
        self.running=True; ok=False
        for pr,i,lab,inch in list_input_devices_prioritized():
            if pr<2: break
            sr=int(sd.query_devices(i).get('default_samplerate') or self.samplerate or 48000)
            for ch in (min(6,inch),2):
                if tryopen(f'INPUT dev={i} {lab} ch={ch} sr={sr}',device=(i,None),samplerate=sr,channels=ch,dtype='float32',latency='high',blocksize=self.blocksize or 0): ok=True; break
            if ok: break
        if not ok:
            dev=self.dev if self.dev is not None else (sd.default.device[1] if sd else None)
            if dev is not None:
                dinfo=sd.query_devices(dev); outc=int(dinfo.get('max_output_channels',2)) or 2
                chs=[2]+([6] if outc>=6 else [])+([8] if outc>=8 else [])
                sr=int(dinfo.get('default_samplerate') or self.samplerate or 48000)
                try: was=sd.WasapiSettings(loopback=True,exclusive=False)
                except Exception: was=None
                for ch in chs:
                    if tryopen(f'WASAPI tuple dev={dev} ch={ch} sr={sr}',device=(None,dev),samplerate=sr,channels=ch,dtype='float32',latency='high',extra_settings=was,blocksize=self.blocksize or 0): ok=True; break
                if not ok and was is not None:
                    for ch in chs:
                        if tryopen(f'WASAPI flat dev={dev} ch={ch} sr={sr}',device=dev,samplerate=sr,channels=ch,dtype='float32',latency='high',extra_settings=was,blocksize=self.blocksize or 0): ok=True; break
                if not ok:
                    for ch in chs:
                        if tryopen(f'WASAPI noextra dev={dev} ch={ch} sr={sr}',device=(None,dev),samplerate=sr,channels=ch,dtype='float32',latency='high',blocksize=self.blocksize or 0): ok=True; break
        if not ok: self.running=False; return False
        threading.Thread(target=self._work,daemon=True).start(); self.cal.reset(); return True
    def stop(self):
        self.running=False
        try:
            if self.stream: self.stream.stop(); self.stream.close()
        except Exception: pass
        self.stream=None
    def _cb(self,indata,frames,time_info,status):
        try: self.q.put_nowait(indata.copy())
        except queue.Full: pass
    def _work(self):
        while self.running:
            try: dat=self.q.get(timeout=0.5)
            except queue.Empty: continue
            if dat.ndim==1: dat=np.stack([dat,dat],axis=1)
            elif dat.shape[1]==1: dat=np.repeat(dat,2,axis=1)
            mono=(dat[:,0]+dat[:,1])*0.5; rms=float(np.sqrt(np.mean(mono**2)+1e-12)); self.lvl=20.0*np.log10(rms+1e-12); self.cal.feed(self.lvl)
            t=time.time(); ang=(t*30.0)%360.0; det={'ts':t,'angle_deg':ang,'level_db':float(self.lvl),'label':'signal','proba':{'signal':0.6}}
            for cb in list(self.det):
                try: cb([det])
                except Exception: pass
            for cb in list(self.frm):
                try: cb(dat)
                except Exception: pass
    def _demo(self):
        import numpy as np, time
        while self.running:
            t=time.time(); ang=(t*36.0)%360.0; det={'ts':t,'angle_deg':ang,'level_db':-18.0,'label':'demo','proba':{'demo':1.0}}
            for cb in list(self.det):
                try: cb([det])
                except Exception: pass
            fr=np.zeros((512,2),dtype='float32')
            for cb in list(self.frm):
                try: cb(fr)
                except Exception: pass
            time.sleep(0.05)

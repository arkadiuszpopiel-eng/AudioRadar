from PyQt5 import QtCore, QtGui, QtWidgets
class EdgeRingWidget(QtWidgets.QWidget):
    def __init__(self,parent=None,sectors=72):
        super().__init__(parent); self.N=sectors; self.energy=[0.0]*self.N; self.setMinimumHeight(200)
        self._t=QtCore.QTimer(self); self._t.setInterval(16); self._t.timeout.connect(self.update); self._t.start()
    def update_sectors(self, dets):
        for i in range(self.N): self.energy[i]*=0.92
        for d in dets or []:
            ang=float(d.get('angle_deg',0.0))%360.0; idx=int(round(ang/(360.0/self.N)))%self.N
            lvl=float(d.get('level_db',-40.0)); e=max(0.0,min(1.0,(lvl+60.0)/60.0)); self.energy[idx]=max(self.energy[idx],e)
        self.update()
    def paintEvent(self,ev):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing,True)
        p.fillRect(self.rect(), QtGui.QColor(22,23,33))
        w,h=self.width(),self.height(); cx,cy=w//2,h//2; r=min(w,h)//2-8
        seg=360.0/self.N; r0=int(r*0.88)
        for i,e in enumerate(self.energy):
            if e<=0.05: continue
            col=QtGui.QColor(200,220,255,int(80+160*e)); pen=QtGui.QPen(col); pen.setWidth(6); p.setPen(pen)
            ang_mid=i*seg; a0=-(ang_mid+seg*0.5); rect=QtCore.QRectF(cx-r0,cy-r0,2*r0,2*r0); p.drawArc(rect,int(a0*16),int(seg*16))
        p.end()

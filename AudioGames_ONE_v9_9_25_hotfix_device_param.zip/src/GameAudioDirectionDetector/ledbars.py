from PyQt5 import QtCore, QtGui, QtWidgets
import math
def _c(e):
    h=int((1.0-max(0.0,min(1.0,e)))*60); c=QtGui.QColor.fromHsv(h,255,int(180+75*e)); c.setAlpha(int(140+100*e)); return c
class EdgeLedBars(QtWidgets.QWidget):
    def __init__(self,parent=None,decay=0.85,gain=1.0):
        super().__init__(parent); self.decay=float(decay); self.gain=float(gain); self.setMinimumHeight(160)
        self.num={'top':3,'bottom':3,'left':2,'right':2}
        self.energy={k:[0.0]*n for k,n in self.num.items()}; self.imp={k:[0.0]*n for k,n in self.num.items()}
        self._t=QtCore.QTimer(self); self._t.setInterval(16); self._t.timeout.connect(self._anim); self._t.start()
    def _map(self,a):
        a=a%360.0; r=math.radians(a); x,y=math.cos(r),math.sin(r)
        if abs(y)>=abs(x): ed='top' if y>=0 else 'bottom'; t=(x+1)/2; n=self.num[ed]; ix=min(n-1,max(0,int(t*n)))
        else: ed='right' if x>=0 else 'left'; t=(y+1)/2; n=self.num[ed]; ix=min(n-1,max(0,int(t*n)))
        return ed,ix
    def update_from_detections(self,d):
        for e in self.energy:
            for i in range(len(self.energy[e])): self.energy[e][i]*=self.decay; self.imp[e][i]*=0.9
        for x in d or []:
            a=float(x.get('angle_deg',0.0)); lvl=float(x.get('level_db',-40.0)); E=min(1.0,(lvl+60)/60.0*self.gain)
            ed,ix=self._map(a); self.energy[ed][ix]=max(self.energy[ed][ix],E); self.imp[ed][ix]=max(self.imp[ed][ix],E)
        self.update()
    def paintEvent(self,ev):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing,True); w,h=self.width(),self.height()
        p.fillRect(self.rect(),QtGui.QColor(22,23,33)); m=18; s=10; th=14
        segw=(w-2*m-2*s)/3.0; top=[QtCore.QRectF(m+i*(segw+s),m,segw,th) for i in range(3)]; bot=[QtCore.QRectF(m+i*(segw+s),h-m-th,segw,th) for i in range(3)]
        segh=(h-2*m-s)/2.0; left=[QtCore.QRectF(m,m+i*(segh+s),th,segh) for i in range(2)]; right=[QtCore.QRectF(w-m-th,m+i*(segh+s),th,segh) for i in range(2)]
        def draw(r,e,imp,h=True):
            p.fillRect(r,QtGui.QColor(40,60,80,120)); col=_c(e); g=QtGui.QLinearGradient(r.topLeft(), r.topRight() if h else r.bottomLeft())
            g.setColorAt(0.0,col); g.setColorAt(1.0,QtGui.QColor.fromHsv(0,255,180)); p.fillRect(r,g)
        for i,r in enumerate(top): draw(r,self.energy['top'][i],self.imp['top'][i],True)
        for i,r in enumerate(bot): draw(r,self.energy['bottom'][i],self.imp['bottom'][i],True)
        for i,r in enumerate(left): draw(r,self.energy['left'][i],self.imp['left'][i],False)
        for i,r in enumerate(right): draw(r,self.energy['right'][i],self.imp['right'][i],False)
        p.end()
    def _anim(self):
        for e in self.imp:
            for i in range(len(self.imp[e])): self.imp[e][i]*=0.92
        self.update()

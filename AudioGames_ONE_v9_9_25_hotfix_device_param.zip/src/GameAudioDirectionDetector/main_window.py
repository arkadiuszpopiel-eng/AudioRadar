from PyQt5 import QtCore, QtWidgets
from .hud import EdgeRingWidget
from .ledbars import EdgeLedBars
from .audio_engine import AudioEngine, list_output_devices_wasapi, RunMode

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE v9.9.25 — SB Z SE Loopback Fix (auto)")
        self.resize(1180,820)
        self.tabs=QtWidgets.QTabWidget(); self.setCentralWidget(self.tabs)
        te=QtWidgets.QWidget(); v=QtWidgets.QVBoxLayout(te); self.edge=EdgeRingWidget(); v.addWidget(self.edge); self.tabs.addTab(te,"Edge 360°")
        tl=QtWidgets.QWidget(); vl=QtWidgets.QVBoxLayout(tl); self.bars=EdgeLedBars(); vl.addWidget(self.bars); self.tabs.addTab(tl,"LED Bars")
        tin=QtWidgets.QWidget(); f=QtWidgets.QFormLayout(tin)
        self.cmb=QtWidgets.QComboBox(); self.demo=QtWidgets.QCheckBox("Demo / Test mode")
        self.bstart=QtWidgets.QPushButton("Start Engine"); self.bstop=QtWidgets.QPushButton("Stop Engine"); self.bstop.setEnabled(False)
        self.lauto=QtWidgets.QLabel("AutoCal: — / — dB (thr —) | live — dB"); self.linfo=QtWidgets.QLabel("Opened: —")
        f.addRow("Device (WASAPI OUT)", self.cmb); f.addRow(self.demo); f.addRow(self.lauto); f.addRow(self.linfo); f.addRow(self.bstart); f.addRow(self.bstop)
        self.tabs.addTab(tin,"Audio In")
        self.status=QtWidgets.QLabel("Ready"); self.statusBar().addPermanentWidget(self.status)
        self.eng=AudioEngine(); self.eng.on_detect(self.on_dets)
        self.bstart.clicked.connect(self._start); self.bstop.clicked.connect(self._stop); self.demo.toggled.connect(self._demo)
        self._refresh(); self.t=QtCore.QTimer(self); self.t.setInterval(150); self.t.timeout.connect(self._tick); self.t.start()
    def _demo(self,on): self.status.setText("DEMO ACTIVE" if on else "Ready")
    def _start(self):
        self.eng.set_run_mode(RunMode.DEMO if self.demo.isChecked() else RunMode.REAL)
        ok=self.eng.start()
        if ok:
            self.bstart.setEnabled(False); self.bstop.setEnabled(True)
            self.status.setText("DEMO ACTIVE" if self.demo.isChecked() else "Engine: running")
            self.linfo.setText("Opened: "+(self.eng.opened or "—"))
        else:
            self.status.setText("Engine: ERROR — "+(self.eng.err or "open failed")); self.linfo.setText("Opened: —")
    def _stop(self):
        self.eng.stop(); self.bstart.setEnabled(True); self.bstop.setEnabled(False); self.status.setText("Stopped")
    def _refresh(self):
        self.cmb.blockSignals(True); self.cmb.clear(); self._map=[]
        for i,lab,_ in list_output_devices_wasapi(): self.cmb.addItem(lab); self._map.append(i)
        self.cmb.blockSignals(False); self._map and self.eng.set_input(self._map[0])
    def on_dets(self,d): self.edge.update_sectors(d); self.bars.update_from_detections(d)
    def _tick(self):
        c=self.eng.cal
        self.lauto.setText(f"AutoCal: min {c.min_db:.1f} / max {c.max_db:.1f} dB  (thr {c.threshold():.1f}) | live {self.eng.last_level_db:.1f} dB")

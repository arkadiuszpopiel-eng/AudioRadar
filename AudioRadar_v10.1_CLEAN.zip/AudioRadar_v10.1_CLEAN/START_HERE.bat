@echo off
chcp 65001 >nul
cls
echo ═══════════════════════════════════════════════════════════════
echo                    AUDIO RADAR v10.1
echo                     LAUNCHER / URUCHAMIACZ
echo ═══════════════════════════════════════════════════════════════
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python nie jest zainstalowany!
    echo.
    echo Pobierz Python 3.8 lub nowszy z https://www.python.org/
    echo.
    pause
    exit /b 1
)

echo [OK] Python wykryty:
python --version
echo.

REM Check if in correct directory
if not exist "audio_radar\main.py" (
    echo [ERROR] Nie znaleziono folderu audio_radar!
    echo Uruchom ten skrypt z głównego folderu AudioRadar_v10.1_CLEAN
    echo.
    pause
    exit /b 1
)

echo [INFO] Sprawdzanie zależności...
echo.

REM Try to import required modules
python -c "import sounddevice, pygame, numpy" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [WARN] Brakuje niektórych bibliotek.
    echo.
    echo Instaluję zależności z requirements.txt...
    echo.
    pip install -r requirements.txt
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo [ERROR] Nie udało się zainstalować zależności.
        echo Spróbuj ręcznie: pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
    echo.
    echo [OK] Zależności zainstalowane!
    echo.
) else (
    echo [OK] Wszystkie biblioteki dostępne
    echo.
)

echo ═══════════════════════════════════════════════════════════════
echo                    URUCHAMIANIE PROGRAMU
echo ═══════════════════════════════════════════════════════════════
echo.
echo STEROWANIE:
echo   T   - Test audio (diagnostyka)
echo   D   - Tryb debug
echo   ESC - Zamknij
echo.
echo   Z/X - Szerokość pasków
echo   C/V - Wysokość pasków
echo   B/N - Przezroczystość
echo.
echo Logi zapisywane do: audio_radar\log_v10.1.txt
echo.
echo ═══════════════════════════════════════════════════════════════
echo.

REM Run the program
cd audio_radar
python -m audio_radar
cd ..

echo.
echo ═══════════════════════════════════════════════════════════════
echo Program zamknięty. Sprawdź logi w audio_radar\log_v10.1.txt
echo ═══════════════════════════════════════════════════════════════
echo.
pause

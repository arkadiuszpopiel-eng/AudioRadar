
AudioRadar — v5.2.0 (MAX)
=========================
Zestaw: GUI + Radar (jaśniejszy, wzmocnienie cichych sygnałów) + VU + RMS + TestTone + ListDevices + Soft-GL + fallback PyAudio→sounddevice + solidne logi.
Data kompilacji: 2025-11-02 17:17:38

Szybki start:
1) RUN_BUILD_ALL.cmd
2) RUN_AUDIO_RADAR.bat
3) Zakładka Control → wybierz "What U Hear (Sound Blaster Z SE)" → Samplerate: 48000 → Tryb: callback → START
4) Przejdź na Radar — blip powinien pulsować; VU i RMS w Control muszą się ruszać.

Logi sesji: portable\logs\session_YYYYMMDD_HHMMSS.log

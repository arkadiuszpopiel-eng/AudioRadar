
import numpy as np, queue
import pyaudiowpatch as pyaudio
import sounddevice as sd
CANDIDATE_RATES=[48000,44100,96000,192000]
class AudioBackendError(Exception): pass
class LevelBuffer:
    def __init__(self): self.q=queue.Queue(maxsize=256)
    def push(self,v):
        try: self.q.put_nowait(float(v))
        except queue.Full: pass
    def pop(self):
        import queue as q
        try: return float(self.q.get_nowait())
        except q.Empty: return None
def list_devices_pyaudio():
    pa=pyaudio.PyAudio(); out=[]
    for i in range(pa.get_device_count()):
        info=pa.get_device_info_by_index(i); out.append((i,info.get('name'),info))
    pa.terminate(); return out
def list_devices_sounddevice():
    return [(i,d['name'],d) for i,d in enumerate(sd.query_devices())]
def prefer_device_index(devs):
    for i,n,info in devs:
        if n and 'What U Hear' in n: return i
    for i,n,info in devs:
        if n and 'Loopback' in n: return i
    for i,n,info in devs:
        if int(info.get('maxInputChannels',0) or 0)>0: return i
    return None
def _rms_i16(buf):
    if not buf: return 0.0
    x=np.frombuffer(buf,dtype=np.int16)
    if x.size==0: return 0.0
    return float(np.sqrt(np.mean((x.astype(np.float32)/32768.0)**2)))
class PyAudioInput:
    def __init__(self,device_index=None,channels=2,rate=48000,frames_per_buffer=None,level_sink=None,logger=None,use_callback=True):
        self.pa=pyaudio.PyAudio(); self.device_index=device_index; self.channels=channels; self.rate=rate
        self.frames_per_buffer=frames_per_buffer or max(256,int(rate*0.02)); self.level_sink=level_sink; self.logger=logger; self.use_callback=use_callback; self.stream=None
    def is_supported(self,rate):
        try: return self.pa.is_format_supported(rate,input_device=self.device_index,input_channels=self.channels,input_format=pyaudio.paInt16)
        except Exception: return False
    def auto_rate(self):
        for r in CANDIDATE_RATES:
            if self.is_supported(r): return r
        info=self.pa.get_device_info_by_index(self.device_index); return int(info.get('defaultSampleRate',44100)) or 44100
    def start(self):
        if not self.is_supported(self.rate): self.rate=self.auto_rate()
        cb=None
        if self.use_callback:
            def _cb(in_data,frame_count,time_info,status):
                try:
                    if self.level_sink: self.level_sink.push(_rms_i16(in_data))
                    return (None,pyaudio.paContinue)
                except Exception:
                    return (None,pyaudio.paAbort)
            cb=_cb
        self.stream=self.pa.open(format=pyaudio.paInt16,channels=self.channels,rate=self.rate,input=True,input_device_index=self.device_index,frames_per_buffer=self.frames_per_buffer,stream_callback=cb)
        self.stream.start_stream()
    def stop(self):
        try:
            if self.stream is not None: self.stream.stop_stream(); self.stream.close()
        finally:
            self.pa.terminate()
class SoundDeviceInput:
    def __init__(self,device_index=None,channels=2,rate=48000,frames_per_buffer=None,level_sink=None,logger=None):
        self.device_index=device_index; self.channels=channels; self.rate=rate; self.frames_per_buffer=frames_per_buffer or max(256,int(rate*0.02)); self.level_sink=level_sink; self.logger=logger; self.stream=None
    def _cb(self,indata,frames,time,stat):
        try:
            import numpy as np
            x=(indata[:,0].astype(np.float32) if getattr(indata,'ndim',1)>1 else indata.astype(np.float32))
            rms=float(np.sqrt(np.mean((x/32768.0)**2))) if x.size>0 else 0.0
            if self.level_sink: self.level_sink.push(rms)
        except Exception: pass
    def start(self):
        self.stream=sd.InputStream(device=self.device_index,channels=self.channels,samplerate=self.rate,dtype='int16',blocksize=self.frames_per_buffer,callback=self._cb,latency='low')
        self.stream.start()
    def stop(self):
        try:
            if self.stream is not None: self.stream.stop(); self.stream.close()
        finally: pass
def normalize_channels(name, reported_channels):
    return 2 if (name and ('What U Hear' in name or 'Loopback' in name)) else min(int(reported_channels or 2),2)


from PyQt5 import QtWidgets, QtCore
from logging_setup import init_logging
from audio_backends import list_devices_pyaudio, list_devices_sounddevice, prefer_device_index, CANDIDATE_RATES, LevelBuffer, PyAudioInput, SoundDeviceInput, normalize_channels
from radar_widget import RadarWidget
import sounddevice as sd, numpy as np
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('AudioRadar v5.2.0 (MAX)')
        self.resize(960,600)
        self.logger, self.logdir = init_logging()
        self.status = self.statusBar()
        tabs=QtWidgets.QTabWidget(); self.setCentralWidget(tabs)
        # Control tab
        ctrl=QtWidgets.QWidget(); tabs.addTab(ctrl,'Control')
        lay=QtWidgets.QFormLayout(ctrl)
        self.cmb_dev=QtWidgets.QComboBox(); self._devs=list_devices_pyaudio()
        for idx,name,info in self._devs:
            maxin=int(info.get('maxInputChannels',0) or 0); self.cmb_dev.addItem(f'[{idx}] {name} (in={maxin})', idx)
        pref=prefer_device_index(self._devs)
        if pref is not None:
            row=next((i for i,(ix,_,_) in enumerate(self._devs) if ix==pref),0); self.cmb_dev.setCurrentIndex(row)
        self.cmb_rate=QtWidgets.QComboBox(); [self.cmb_rate.addItem(str(r),r) for r in CANDIDATE_RATES]; self.cmb_rate.setCurrentIndex(0)
        self.cmb_mode=QtWidgets.QComboBox(); self.cmb_mode.addItems(['callback','poll'])
        self.btn_list=QtWidgets.QPushButton('List Devices')
        self.btn_tone=QtWidgets.QPushButton('TEST TONE (1 kHz) 3s')
        self.btn_start=QtWidgets.QPushButton('START'); self.btn_stop=QtWidgets.QPushButton('STOP'); self.btn_stop.setEnabled(False)
        self.pb=QtWidgets.QProgressBar(); self.pb.setRange(0,100)
        self.lbl_rms=QtWidgets.QLabel('RMS: 0.000')
        self.txt=QtWidgets.QPlainTextEdit(); self.txt.setReadOnly(True); self.txt.setMaximumBlockCount(1000)
        lay.addRow('Urządzenie', self.cmb_dev); lay.addRow('Samplerate', self.cmb_rate); lay.addRow('Tryb', self.cmb_mode)
        lay.addRow(self.btn_start, self.btn_stop); lay.addRow('Poziom (VU)', self.pb); lay.addRow('Input Monitor', self.lbl_rms)
        lay.addRow(self.btn_list, self.btn_tone); lay.addRow('Log', self.txt)
        # Radar tab
        radar_tab=QtWidgets.QWidget(); tabs.addTab(radar_tab,'Radar')
        vbox=QtWidgets.QVBoxLayout(radar_tab)
        self.radar=RadarWidget(); vbox.addWidget(self.radar,1)
        # state
        self.levels=LevelBuffer(); self.backend=None
        self.btn_start.clicked.connect(self.on_start); self.btn_stop.clicked.connect(self.on_stop)
        self.btn_list.clicked.connect(self.on_list); self.btn_tone.clicked.connect(self.on_tone)
        self.timer=QtCore.QTimer(self); self.timer.setInterval(50); self.timer.timeout.connect(self.on_tick); self.timer.start()
    def log(self,s): self.txt.appendPlainText(s); self.logger.info(s)
    def banner(self, backend, ch, rate): self.status.showMessage(f'Backend: {backend} | Ch: {ch} | Rate: {rate} Hz')
    def _error(self, title, msg): QtWidgets.QMessageBox.critical(self, title, msg)
    def on_list(self):
        self.log('--- PyAudio devices ---')
        for idx, name, info in list_devices_pyaudio():
            self.log(f"[{idx}] {name} | in={info.get('maxInputChannels')} sr={info.get('defaultSampleRate')}")
        self.log('--- sounddevice devices ---')
        for i, n, inf in list_devices_sounddevice():
            self.log(f"[{i}] {n} | in={inf.get('max_input_channels')} out={inf.get('max_output_channels')}")
    def on_tone(self):
        sr=48000; dur=3.0; n=int(sr*dur)
        x=(0.5*np.sin(2*np.pi*1000*np.arange(n)/sr)).astype('float32')
        try: sd.play(x, sr, blocking=False); self.log('TEST TONE: 1 kHz przez 3s na domyślne wyjście Windows.')
        except Exception as e: self._error('Test tone error', str(e))
    def on_start(self):
        if self.backend is not None: return
        idx=self.cmb_dev.currentData(); rate=int(self.cmb_rate.currentData()); mode=self.cmb_mode.currentText()
        _,name,info=next((d for d in self._devs if d[0]==idx), self._devs[0])
        ch=2 if (name and ('What U Hear' in name or 'Loopback' in name)) else int(info.get('maxInputChannels',2) or 2); ch=min(ch,2)
        self.log(f'START requested: dev={idx} name={name} ch={ch} rate={rate} mode={mode}')
        try:
            self.backend=PyAudioInput(device_index=idx,channels=ch,rate=rate,level_sink=self.levels,logger=self.logger,use_callback=(mode=='callback'))
            self.backend.start(); self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
            self.log('PyAudio backend started'); self.banner('PyAudio', ch, rate); return
        except Exception as e:
            self.backend=None; self.log(f'PyAudio failed: {e}')
        try:
            self.backend=SoundDeviceInput(device_index=None,channels=ch,rate=rate,level_sink=self.levels,logger=self.logger)
            self.backend.start(); self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
            self.log('Fallback sounddevice backend started'); self.banner('sounddevice', ch, rate)
        except Exception as e:
            self.backend=None; self._error('Błąd uruchamiania', f'Nie udało się uruchomić wejścia audio.\nSzczegóły: {e}'); self.log(f'Fallback failed: {e}')
    def on_stop(self):
        try:
            if self.backend is not None: self.backend.stop()
        finally:
            self.backend=None; self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)
            self.pb.setValue(0); self.lbl_rms.setText('RMS: 0.000'); self.log('Stopped'); self.status.clearMessage()
    def on_tick(self):
        v=self.levels.pop()
        if v is not None:
            self.pb.setValue(max(0,min(100,int(v*120))))
            self.lbl_rms.setText(f'RMS: {v:.3f}')
            self.radar.setLevel(v)

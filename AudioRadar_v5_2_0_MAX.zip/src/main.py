
import os, sys, traceback
# Force software rendering for Qt to avoid GPU issues
os.environ.setdefault('QT_OPENGL','software')
os.environ.setdefault('QT_QUICK_BACKEND','software')
os.environ.setdefault('QT_ANGLE_PLATFORM','d3d11')
from PyQt5 import QtWidgets, QtCore
from logging_setup import init_logging
from gui import MainWindow
def selftest(logdir):
    try:
        with open(os.path.join(logdir,'selftest.log'),'w',encoding='utf-8') as f:
            f.write('SELFTEST_OK\n')
        return True
    except Exception:
        return False
def _excepthook(tp, val, tb):
    logger,_ = init_logging()
    logger.exception('UNCAUGHT: %s', ''.join(traceback.format_exception(tp,val,tb)))
    try:
        QtWidgets.QMessageBox.critical(None, 'Nieoczekiwany błąd', str(val))
    except Exception:
        pass
def main():
    logger, logdir = init_logging()
    sys.excepthook = _excepthook
    ap=__import__('argparse').ArgumentParser(); ap.add_argument('--selftest',action='store_true'); args=ap.parse_args()
    if args.selftest: return 0 if selftest(logdir) else 1
    try: QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseSoftwareOpenGL, on=True)
    except Exception: pass
    app=QtWidgets.QApplication(sys.argv)
    win=MainWindow(); win.show()
    return app.exec_()
if __name__=='__main__':
    sys.exit(main())

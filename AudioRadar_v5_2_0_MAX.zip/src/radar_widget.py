
from PyQt5 import QtWidgets, QtGui, QtCore
import math
class RadarWidget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self._angle=0.0
        self._level=0.0
        self._timer=QtCore.QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)
        self._timer.start()
    def setLevel(self, lvl:float):
        if lvl is None: lvl = 0.0
        lvl = max(0.0, min(1.0, float(lvl)))
        # wzmocnienie cichych sygnałów
        self._level = math.sqrt(lvl)
    def _tick(self):
        self._angle=(self._angle+2.0)%360.0
        self.update()
    def sizeHint(self):
        return QtCore.QSize(360,360)
    def paintEvent(self, ev):
        p=QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        r=min(self.width(), self.height())-10
        cx=self.width()/2; cy=self.height()/2; rad=r/2
        p.fillRect(self.rect(), QtGui.QColor(10,15,20))
        pen=QtGui.QPen(QtGui.QColor(70,90,110)); pen.setWidth(1); p.setPen(pen)
        for k in range(1,5):
            rr = rad*k/4; p.drawEllipse(QtCore.QPointF(cx,cy), rr, rr)
        p.drawLine(cx-rad, cy, cx+rad, cy); p.drawLine(cx, cy-rad, cx, cy+rad)
        angle=self._angle
        pen=QtGui.QPen(QtGui.QColor(120,220,255)); pen.setWidth(2); p.setPen(pen)
        x2=cx+rad*math.cos(math.radians(angle)); y2=cy-rad*math.sin(math.radians(angle))
        p.drawLine(cx,cy,x2,y2)
        blip_r = 8 + 40*self._level
        blip_color = QtGui.QColor(90,255,120, int(100 + 155*self._level))
        p.setBrush(blip_color); p.setPen(QtGui.QPen(QtGui.QColor(0,0,0,0)))
        bx = cx + (rad*0.65)*math.cos(math.radians(angle))
        by = cy - (rad*0.65)*math.sin(math.radians(angle))
        p.drawEllipse(QtCore.QPointF(bx,by), blip_r, blip_r)


import os, sys, py_compile
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src'))
ok = True
for dp, _, files in os.walk(root):
    for f in files:
        if f.endswith('.py'):
            p = os.path.join(dp, f)
            try:
                py_compile.compile(p, doraise=True)
            except Exception as e:
                sys.stderr.write(f'[SYNTAX_ERROR] {p}: {e}\n')
                ok = False
print('[SYNTAX_OK]' if ok else '[SYNTAX_FAIL]')
sys.exit(0 if ok else 1)

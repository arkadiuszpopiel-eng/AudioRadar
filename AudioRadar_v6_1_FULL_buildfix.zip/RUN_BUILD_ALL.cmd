@echo off
REM ============================================================================
REM AudioRadar build script
REM
REM This script creates a virtual environment, installs dependencies,
REM runs a syntax check on the source tree, builds the executable with
REM PyInstaller, runs a self-test, and copies the resulting build into
REM the `portable` directory for distribution. It should be executed
REM from the root of the project folder on Windows.
REM ============================================================================

setlocal enableextensions
set LOGFILE=build_log.txt
echo AudioRadar build started > %LOGFILE%

REM Create virtual environment
if exist .venv rd /s /q .venv
python -m venv .venv >> %LOGFILE% 2>&1
if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment >> %LOGFILE%
    goto :eof
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo [ERROR] Failed to activate virtual environment >> %LOGFILE%
    goto :eof
)

REM Install dependencies
REM Update pip via python -m to avoid the "To modify pip" warning
python -m pip install --upgrade pip >> %LOGFILE% 2>&1
pip install -r requirements.txt >> %LOGFILE% 2>&1
REM Ensure PyInstaller is available for building the executable
pip install pyinstaller >> %LOGFILE% 2>&1
if errorlevel 1 (
    echo [ERROR] Failed to install requirements >> %LOGFILE%
    goto :eof
)

REM Syntax check
python tools\syntax_check.py src >> %LOGFILE% 2>&1
if errorlevel 1 (
    echo [ERROR] Syntax errors detected, aborting build. >> %LOGFILE%
    goto :eof
)

REM Build with PyInstaller (use python -m to ensure the module is found even if the executable isn't on PATH)
python -m PyInstaller build.spec --noconfirm >> %LOGFILE% 2>&1
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed >> %LOGFILE%
    goto :eof
)

REM Prepare portable folder
if exist portable rd /s /q portable
mkdir portable\logs
mkdir portable\models

REM Copy built files
robocopy dist\AudioRadar portable /e >> %LOGFILE% 2>&1

REM Write START_HERE.bat
echo @echo off > portable\START_HERE.bat
echo echo Running AudioRadar... >> portable\START_HERE.bat
echo AudioRadar.exe >> portable\START_HERE.bat

REM Run self-test
portable\AudioRadar.exe --selftest >> %LOGFILE% 2>&1
if errorlevel 1 (
    echo [ERROR] Self-test failed >> %LOGFILE%
    goto :eof
)

echo [OK] Build completed successfully >> %LOGFILE%
endlocal
exit /b 0
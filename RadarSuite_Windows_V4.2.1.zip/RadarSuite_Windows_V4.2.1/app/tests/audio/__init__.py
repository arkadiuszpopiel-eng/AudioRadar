"""Audio module tests"""

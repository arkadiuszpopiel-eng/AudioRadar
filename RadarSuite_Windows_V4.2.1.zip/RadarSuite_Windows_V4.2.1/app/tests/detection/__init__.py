"""Detection module tests"""

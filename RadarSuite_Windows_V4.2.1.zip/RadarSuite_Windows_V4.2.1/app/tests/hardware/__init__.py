"""Hardware module tests"""

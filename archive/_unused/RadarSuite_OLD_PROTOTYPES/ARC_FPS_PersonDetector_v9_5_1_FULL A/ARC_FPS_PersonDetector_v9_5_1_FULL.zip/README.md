Stable v9.5.1 (FULL) — zawiera diagram ASCII, diagnostykę, auto-DirectML. Uruchom run_auto.bat.

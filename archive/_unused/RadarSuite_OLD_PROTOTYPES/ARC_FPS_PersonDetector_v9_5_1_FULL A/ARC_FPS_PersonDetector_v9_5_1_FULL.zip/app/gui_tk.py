# (skrót — jak v9.5.0 FULL z mini panelem Diag)

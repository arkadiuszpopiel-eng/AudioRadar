@echo off
venv\Scripts\pyinstaller --onefile --windowed --name arc_fps_detector app\gui_tk.py >> log.txt 2>&1
if exist dist\arc_fps_detector.exe (copy /Y dist\arc_fps_detector.exe arc_fps_detector.exe >> log.txt 2>&1)

@echo off
echo === Start of run_auto.bat (v9.5.1) === > log.txt
where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (set PY_CMD=python) else (set PY_CMD=py)
%PY_CMD% -m venv venv >> log.txt 2>&1
venv\Scripts\python -m pip install --upgrade pip wheel setuptools >> log.txt 2>&1
venv\Scripts\pip install -r requirements.txt >> log.txt 2>&1
venv\Scripts\pip uninstall -y onnxruntime >> log.txt 2>&1
venv\Scripts\pip install onnxruntime-directml >> log.txt 2>&1
venv\Scripts\python tools\get_onnx_model.py >> log.txt 2>&1
venv\Scripts\python tools\launch_with_logging.py >> log.txt 2>&1
venv\Scripts\pyinstaller --onefile --windowed --name arc_fps_detector app\gui_tk.py >> log.txt 2>&1
if exist dist\arc_fps_detector.exe (copy /Y dist\arc_fps_detector.exe arc_fps_detector.exe >> log.txt 2>&1)

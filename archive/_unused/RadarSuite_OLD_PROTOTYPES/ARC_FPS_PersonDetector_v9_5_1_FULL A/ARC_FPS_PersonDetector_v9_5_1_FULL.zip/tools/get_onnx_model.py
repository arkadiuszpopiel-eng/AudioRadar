from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
onx=ROOT/'app'/'models'/'yolov8n.onnx'
onx.parent.mkdir(parents=True, exist_ok=True)
if onx.exists():
 print('[get_onnx] ONNX present'); sys.exit(0)
from ultralytics import YOLO
m=YOLO('yolov8n.pt'); m.export(format='onnx', dynamic=False, opset=12, imgsz=640)
d=ROOT/'yolov8n.onnx'
if d.exists(): d.replace(onx)

import logging, os, sys
logging.basicConfig(filename='detector_run.log', level=logging.INFO)
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root not in sys.path: sys.path.insert(0,root)
import app.gui_tk as gui
gui.run()

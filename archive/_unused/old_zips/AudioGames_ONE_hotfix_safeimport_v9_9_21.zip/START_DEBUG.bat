@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
set "APP=%~dp0bin\AudioGames_ONE.exe"
"%APP%" 1>>"%~dp0logs\run_log.txt" 2>&1
pause

from PyQt5 import QtCore, QtGui, QtWidgets
import math

class RadarWidget(QtWidgets.QWidget):
    angleChanged = QtCore.pyqtSignal(float)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0

    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.angleChanged.emit(angle_deg)
        self.update()

    def paintEvent(self, ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        r = min(self.width(), self.height())/2 - 8
        c = QtCore.QPointF(self.width()/2, self.height()/2)
        pen = QtGui.QPen(QtGui.QColor(120,120,120,100), 2)
        p.setPen(pen); p.setBrush(QtCore.Qt.NoBrush)
        for i in range(1,4):
            p.drawEllipse(c, r*i/3, r*i/3)
        ang = math.radians(self._angle - 90)
        x = c.x() + r*math.cos(ang); y = c.y() + r*math.sin(ang)
        p.setPen(QtGui.QPen(QtGui.QColor(100,200,255,200), 3))
        p.drawLine(c, QtCore.QPointF(x,y))
        mr = max(3.0, min(r/6, self._level*400))
        p.setBrush(QtGui.QColor(100,200,255,180))
        p.setPen(QtGui.QPen(QtGui.QColor(0,0,0,0)))
        p.drawEllipse(QtCore.QPointF(x,y), mr, mr)

class EdgeBeacons(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0
    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        t = (self._angle + 90.0) / 180.0
        x = int(t*w)
        alpha = int(max(0, min(180, self._level*800)))
        color = QtGui.QColor(100,200,255, alpha)
        p.fillRect(0,0,w,6, QtGui.QColor(color))
        p.fillRect(0,h-6,w,6, QtGui.QColor(color))
        p.fillRect(max(0,x-6), 0, 12, h, QtGui.QColor(color))

class MiniBands(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(60)
        self._bands = {"low":0.0,"mid":0.0,"high":0.0}
    def setBands(self, bands):
        self._bands = bands or self._bands
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        keys = ["low","mid","high"]
        for i,k in enumerate(keys):
            v = self._bands.get(k,0.0)
            bar_h = min(h-10, int(v*0.0005*h + 5))
            x0 = int(i*w/3 + 10)
            p.fillRect(x0, h-bar_h, int(w/3)-20, bar_h, QtGui.QColor(100,200,255,200))
        p.setPen(QtGui.QPen(QtGui.QColor(120,120,120,120),1))
        p.drawRect(0,0,w-1,h-1)



class LEDBezel(QtWidgets.QWidget):
    """Punktowe paski LED na CZTERECH krawędziach (góra, dół, lewo, prawo).
    Kierunek mapowany jest z zakresu [-90..+90] stopni (lewo↔prawo).
    - Góra/Dół: pasek poziomy o długości okna, pozycja jasności zgodna z kierunkiem.
    - Lewo/Prawo: kolumny pionowe; intensywność rośnie gdy kąt zbliża się do odpowiedniego boku.
    Kolor przechodzi płynnie od cyjanu (niski poziom) do czerwieni (wysoki poziom).
    """
    def __init__(self, parent=None, h_segments=28, v_segments=18):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0
        self.h_segments = h_segments
        self.v_segments = v_segments
        self.setMinimumHeight(70)

    def setAngleLevel(self, angle_deg, level):
        self._angle = float(angle_deg)
        self._level = float(level)
        self.update()

    def _mix(self, a, b, t): return int(a + (b - a) * t)

    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w, h = self.width(), self.height()
        margin = 6

        # Intensity & color
        inten = max(0.0, min(1.0, self._level * 6.0))
        cr = self._mix(100, 255, inten)
        cg = self._mix(200, 80, inten)
        cb = self._mix(255, 80, inten)
        base = QtGui.QColor(cr, cg, cb)

        # Direction normalized [0..1]
        t = (self._angle + 90.0) / 180.0
        # Gaussian spread width
        def gauss(d): 
            return max(0.0, min(1.0, pow(2.71828, -(d*d)/8.0)))

        # --- TOP & BOTTOM horizontal strips ---
        n = self.h_segments
        seg_w = max(4, int((w - 2*margin) / n - 2))
        target = t * (n-1)
        for i in range(n):
            weight = gauss(i - target)
            alpha = int(30 + 200 * inten * weight)
            color = QtGui.QColor(base.red(), base.green(), base.blue(), alpha)
            x = margin + i * (seg_w + 2)
            # top
            p.fillRect(x, margin, seg_w, 8, color)
            # bottom
            p.fillRect(x, h - margin - 8, seg_w, 8, color)

        # --- LEFT & RIGHT vertical strips ---
        m = self.v_segments
        seg_h = max(4, int((h - 2*margin - 20) / m - 2))  # leave space for top/bot bars
        # map angle proximity to left/right
        # near -90 -> left, near +90 -> right
        # convert t in [0..1]; distance to 0 and 1
        for j in range(m):
            y = margin + 10 + j * (seg_h + 2)
            # left side: stronger when t near 0
            weight_l = gauss((t * (n-1)) - 0)  # approximate
            alpha_l = int(20 + 180 * inten * weight_l)
            color_l = QtGui.QColor(base.red(), base.green(), base.blue(), alpha_l)
            p.fillRect(margin, y, 8, seg_h, color_l)
            # right side: stronger when t near 1
            weight_r = gauss((n-1) - (t * (n-1)))
            alpha_r = int(20 + 180 * inten * weight_r)
            color_r = QtGui.QColor(base.red(), base.green(), base.blue(), alpha_r)
            p.fillRect(w - margin - 8, y, 8, seg_h, color_r)

        # Direction indicator line
        xdir = int(margin + target * (seg_w + 2) + seg_w/2)
        p.fillRect(max(0, xdir-1), 0, 2, h, QtGui.QColor(base.red(), base.green(), base.blue(), int(40+160*inten)))

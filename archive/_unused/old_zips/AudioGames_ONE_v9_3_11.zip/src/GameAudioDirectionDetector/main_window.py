from PyQt5 import QtCore, QtGui, QtWidgets
import csv, os, time, json
from .hud import RadarWidget, EdgeBeacons, MiniBands, LEDBezel
from .audio_engine import AudioEngine
from .profiles import ProfileManager
from .autoprofile import ForegroundWatcher

class MainWindow(QtWidgets.QMainWindow):
    def _pick_color(self, initial):
        c = QtWidgets.QColorDialog.getColor(initial, self, "Wybierz kolor")
        return c if c.isValid() else initial

    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE")
        self.setObjectName("AudioGamesONE")
        self.settings_path = settings_path
        self.settings = self._load_settings(settings_path)

        theme_path = os.path.join(os.path.dirname(settings_path), "themes", self.settings.get("theme","ProDark_Fluent.qss"))
        if os.path.exists(theme_path):
            with open(theme_path, "r", encoding="utf-8") as f:
                self.setStyleSheet(f.read())

        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)

        # HUD tab
        hud_tab = QtWidgets.QWidget()
        self.radar = RadarWidget()
        self.beacons = EdgeBeacons()
        self.minibands = MiniBands()
        self.ledbezel = LEDBezel()
        hud_layout = QtWidgets.QVBoxLayout(hud_tab)
        hud_layout.addWidget(self.radar, 5)
        hud_layout.addWidget(self.beacons, 1)
        hud_layout.addWidget(self.minibands, 1)
        hud_layout.addWidget(self.ledbezel, 1)
        self.tabs.addTab(hud_tab, "HUD")

        hudset_tab = QtWidgets.QWidget()
        hudset = QtWidgets.QFormLayout(hudset_tab)
        self.cb_show_radar = QtWidgets.QCheckBox("Pokaż radar"); self.cb_show_radar.setChecked(True)
        self.cb_show_beacons = QtWidgets.QCheckBox("Pokaż beacony"); self.cb_show_beacons.setChecked(True)
        self.cb_show_bands = QtWidgets.QCheckBox("Pokaż pasma"); self.cb_show_bands.setChecked(True)
        self.cb_show_led = QtWidgets.QCheckBox("Pokaż LED ramkę"); self.cb_show_led.setChecked(True)
        self.s_hseg = QtWidgets.QSpinBox(); self.s_hseg.setRange(8,128); self.s_hseg.setValue(28)
        self.s_vseg = QtWidgets.QSpinBox(); self.s_vseg.setRange(6,128); self.s_vseg.setValue(18)
        self.s_thick = QtWidgets.QSpinBox(); self.s_thick.setRange(2,32); self.s_thick.setValue(8)
        self.s_margin = QtWidgets.QSpinBox(); self.s_margin.setRange(0,40); self.s_margin.setValue(6)
        self.s_smooth = QtWidgets.QDoubleSpinBox(); self.s_smooth.setRange(0.0,0.95); self.s_smooth.setSingleStep(0.05); self.s_smooth.setValue(0.35)
        self.btn_low = QtWidgets.QPushButton("Kolor niski")
        self.btn_high = QtWidgets.QPushButton("Kolor wysoki")
        self.btn_apply_hud = QtWidgets.QPushButton("Zastosuj i zapisz")
        hudset.addRow(self.cb_show_radar)
        hudset.addRow(self.cb_show_beacons)
        hudset.addRow(self.cb_show_bands)
        hudset.addRow(self.cb_show_led)
        hudset.addRow("LED h-segmenty:", self.s_hseg)
        hudset.addRow("LED v-segmenty:", self.s_vseg)
        hudset.addRow("LED grubość [px]:", self.s_thick)
        hudset.addRow("LED margines [px]:", self.s_margin)
        hudset.addRow("LED smoothing [0..0.95]:", self.s_smooth)
        hudset.addRow(self.btn_low, self.btn_high)
        hudset.addRow(self.btn_apply_hud)
        self.tabs.addTab(hudset_tab, "Ustawienia HUD")

        # Audio tab
        audio_tab = QtWidgets.QWidget()
        audio_layout = QtWidgets.QFormLayout(audio_tab)
        self.device_combo = QtWidgets.QComboBox()
        self.refresh_btn = QtWidgets.QPushButton("Odśwież urządzenia")
        self.apply_btn = QtWidgets.QPushButton("Zastosuj i restart audio")
        self.auto_default_cb = QtWidgets.QCheckBox("Auto: domyślne urządzenie wyjściowe (WASAPI)")
        self.fallback_cb = QtWidgets.QCheckBox("Fallback na mikrofon, gdy loopback zawiedzie"); self.fallback_cb.setChecked(True)
        self.gain_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.gain_slider.setRange(1,300); self.gain_slider.setValue(int(self.settings["audio"].get("gain",1.0)*100))
        self.ng_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.ng_slider.setRange(0,10); self.ng_slider.setValue(int(self.settings["audio"].get("noise_gate",0.002)*1000))
        audio_layout.addRow("Urządzenie (WASAPI loopback):", self.device_combo)
        audio_layout.addRow(self.auto_default_cb)
        audio_layout.addRow(self.refresh_btn, self.apply_btn)
        audio_layout.addRow(self.fallback_cb)
        audio_layout.addRow("Wzmocnienie (gain x):", self.gain_slider)
        audio_layout.addRow("Bramka szumu:", self.ng_slider)
        self.tabs.addTab(audio_tab, "Audio")

        # Profiles tab
        prof_tab = QtWidgets.QWidget()
        prof_layout = QtWidgets.QFormLayout(prof_tab)
        self.profile_combo = QtWidgets.QComboBox()
        self.tabs.addTab(prof_tab, "Profile")
        prof_layout.addRow("Profil:", self.profile_combo)

        # Logs tab
        logs_tab = QtWidgets.QWidget()
        logs_layout = QtWidgets.QFormLayout(logs_tab)
        self.log_enable = QtWidgets.QCheckBox("Loguj do CSV")
        self.log_path_edit = QtWidgets.QLineEdit(self.settings.get("logging",{}).get("path","portable\\logs\\events.csv"))
        logs_layout.addRow(self.log_enable)
        logs_layout.addRow("Ścieżka:", self.log_path_edit)
        self.tabs.addTab(logs_tab, "Logi")

        # Warning banner
        self.banner = QtWidgets.QLabel("")
        self.banner.setObjectName("warningBanner")
        self.banner.setVisible(False)
        self.statusBar().addPermanentWidget(self.banner)

        if self.settings.get("always_on_top", True):
            self.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, True)
        self.setWindowOpacity(float(self.settings.get("opacity",0.9)))
        if self.settings.get("click_through", True):
            self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)

        # Engine
        self.engine = AudioEngine(
            samplerate=self.settings["audio"]["samplerate"],
            blocksize=self.settings["audio"]["blocksize"],
            gain=self.settings["audio"]["gain"],
            noise_gate=self.settings["audio"]["noise_gate"],
            loopback=self.settings["audio"].get("loopback", True),
            allow_fallback=True,
        )
        self.engine.set_bands(self.settings.get("bands"))
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._pull_audio)
        self.timer.start(16)

        # Profiles
        profiles_dir = os.path.join(os.path.dirname(settings_path), "profiles")
        self.profman = ProfileManager(profiles_dir, self.settings.get("bands"))
        self.profile_combo.addItems(["Default"] + self.profman.names())
        self.profile_combo.currentTextChanged.connect(self._on_profile_change)

        ap = self.settings.get("autoprofile",{})
        self.fgw = ForegroundWatcher(ap.get("map",{}), self._auto_profile_apply, enabled=ap.get("enabled",True))
        self.fgw.start()

        self.refresh_btn.clicked.connect(self._refresh_devices)
        self.apply_btn.clicked.connect(self._apply_and_restart)
        self._refresh_devices()

        self._log_enabled = bool(self.settings.get("logging",{}).get("enabled", False))
        self._log_path = self.log_path_edit.text()
        self.log_enable.setChecked(self._log_enabled)
        self.log_enable.toggled.connect(lambda v: setattr(self, "_log_enabled", v))

        self._start_audio()

        hud_cfg = self.settings.get("hud", {})
        self.cb_show_radar.setChecked(hud_cfg.get("show_radar", True))
        self.cb_show_beacons.setChecked(hud_cfg.get("show_beacons", True))
        self.cb_show_bands.setChecked(hud_cfg.get("show_minibands", True))
        self.cb_show_led.setChecked(hud_cfg.get("show_ledbezel", True))
        led = hud_cfg.get("led", {})
        self.s_hseg.setValue(int(led.get("h_segments", 28)))
        self.s_vseg.setValue(int(led.get("v_segments", 18)))
        self.s_thick.setValue(int(led.get("thickness_px", 8)))
        self.s_margin.setValue(int(led.get("margin_px", 6)))
        self.s_smooth.setValue(float(led.get("smoothing", 0.35)))
        self._led_low = QtGui.QColor(*led.get("color_low", [100,200,255,180]))
        self._led_high = QtGui.QColor(*led.get("color_high", [255,80,80,220]))

        self.radar.setVisible(self.cb_show_radar.isChecked())
        self.beacons.setVisible(self.cb_show_beacons.isChecked())
        self.minibands.setVisible(self.cb_show_bands.isChecked())
        self.ledbezel.setVisible(self.cb_show_led.isChecked())

        self.ledbezel.setSegments(self.s_hseg.value(), self.s_vseg.value())
        self.ledbezel.setThickness(self.s_thick.value())
        self.ledbezel.setMargin(self.s_margin.value())
        self.ledbezel.setSmoothing(self.s_smooth.value())
        self.ledbezel.setColors(
            (self._led_low.red(), self._led_low.green(), self._led_low.blue(), self._led_low.alpha()),
            (self._led_high.red(), self._led_high.green(), self._led_high.blue(), self._led_high.alpha())
        )

        self.cb_show_radar.toggled.connect(self.radar.setVisible)
        self.cb_show_beacons.toggled.connect(self.beacons.setVisible)
        self.cb_show_bands.toggled.connect(self.minibands.setVisible)
        self.cb_show_led.toggled.connect(self.ledbezel.setVisible)
        self.btn_low.clicked.connect(lambda: self._choose_led_color('low'))
        self.btn_high.clicked.connect(lambda: self._choose_led_color('high'))
        self.btn_apply_hud.clicked.connect(self._apply_save_hud)


    def _load_settings(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _refresh_devices(self):
        try:
            import sounddevice as sd
            self.device_combo.clear()
            for idx, dev in enumerate(sd.query_devices()):
                name = dev["name"]
                self.device_combo.addItem(f"{idx}: {name}", idx)
        except Exception as e:
            self._warn(f"Błąd pobierania urządzeń: {e}")

    def _apply_and_restart(self):
        self.engine.gain = self.gain_slider.value()/100.0
        self.engine.noise_gate = self.ng_slider.value()/1000.0
        self.engine.allow_fallback = self.fallback_cb.isChecked()
        if self.auto_default_cb.isChecked():
            self.engine.set_device(None)
        else:
            if self.device_combo.currentIndex() >= 0:
                self.engine.set_device(self.device_combo.currentData())
        self._restart_audio()

    def _start_audio(self):
        try:
            self.engine.start()
            self._warn("")
        except Exception as e:
            self._warn(f"Audio start error: {e}")

    def _restart_audio(self):
        self.engine.stop()
        self._start_audio()

        hud_cfg = self.settings.get("hud", {})
        self.cb_show_radar.setChecked(hud_cfg.get("show_radar", True))
        self.cb_show_beacons.setChecked(hud_cfg.get("show_beacons", True))
        self.cb_show_bands.setChecked(hud_cfg.get("show_minibands", True))
        self.cb_show_led.setChecked(hud_cfg.get("show_ledbezel", True))
        led = hud_cfg.get("led", {})
        self.s_hseg.setValue(int(led.get("h_segments", 28)))
        self.s_vseg.setValue(int(led.get("v_segments", 18)))
        self.s_thick.setValue(int(led.get("thickness_px", 8)))
        self.s_margin.setValue(int(led.get("margin_px", 6)))
        self.s_smooth.setValue(float(led.get("smoothing", 0.35)))
        self._led_low = QtGui.QColor(*led.get("color_low", [100,200,255,180]))
        self._led_high = QtGui.QColor(*led.get("color_high", [255,80,80,220]))

        self.radar.setVisible(self.cb_show_radar.isChecked())
        self.beacons.setVisible(self.cb_show_beacons.isChecked())
        self.minibands.setVisible(self.cb_show_bands.isChecked())
        self.ledbezel.setVisible(self.cb_show_led.isChecked())

        self.ledbezel.setSegments(self.s_hseg.value(), self.s_vseg.value())
        self.ledbezel.setThickness(self.s_thick.value())
        self.ledbezel.setMargin(self.s_margin.value())
        self.ledbezel.setSmoothing(self.s_smooth.value())
        self.ledbezel.setColors(
            (self._led_low.red(), self._led_low.green(), self._led_low.blue(), self._led_low.alpha()),
            (self._led_high.red(), self._led_high.green(), self._led_high.blue(), self._led_high.alpha())
        )

        self.cb_show_radar.toggled.connect(self.radar.setVisible)
        self.cb_show_beacons.toggled.connect(self.beacons.setVisible)
        self.cb_show_bands.toggled.connect(self.minibands.setVisible)
        self.cb_show_led.toggled.connect(self.ledbezel.setVisible)
        self.btn_low.clicked.connect(lambda: self._choose_led_color('low'))
        self.btn_high.clicked.connect(lambda: self._choose_led_color('high'))
        self.btn_apply_hud.clicked.connect(self._apply_save_hud)


    def _pull_audio(self):
        m = self.engine.read(0.0)
        if not m: return
        self.radar.setAngleLevel(m.angle_deg, m.level)
        self.beacons.setAngleLevel(m.angle_deg, m.level)
        self.minibands.setBands(m.bands)
        self.ledbezel.setAngleLevel(m.angle_deg, m.level)
        if self._log_enabled:
            self._write_log(m)

    def _write_log(self, m):
        try:
            path = self._log_path
            os.makedirs(os.path.dirname(path), exist_ok=True)
            new = not os.path.exists(path)
            with open(path, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if new: w.writerow(["timestamp","angle_deg","level","low","mid","high"])
                w.writerow([int(time.time()*1000), f"{m.angle_deg:.2f}", f"{m.level:.6f}", f"{m.bands['low']:.3f}", f"{m.bands['mid']:.3f}", f"{m.bands['high']:.3f}"])
        except Exception as e:
            self._warn(f"Log error: {e}")

    def _on_profile_change(self, name):
        if name and name != "Default":
            prof = self.profman.load(name)
            self.engine.set_bands(prof.get("bands"))
        else:
            self.engine.set_bands(self.settings.get("bands"))

    def _auto_profile_apply(self, profile_name, exe):
        idx = self.profile_combo.findText(profile_name)
        if idx >= 0:
            self.profile_combo.setCurrentIndex(idx)
            self._warn(f"Auto-profil: {profile_name} (exe: {exe})", transient=True)

    def _warn(self, text, transient=False):
        self.banner.setText(text)
        self.banner.setVisible(bool(text))
        if transient and text:
            QtCore.QTimer.singleShot(2500, lambda: (self.banner.setText(""), self.banner.setVisible(False)))

    def _choose_led_color(self, which):
        if which == 'low':
            c = self._pick_color(self._led_low); self._led_low = c
        else:
            c = self._pick_color(self._led_high); self._led_high = c
        self.ledbezel.setColors(
            (self._led_low.red(), self._led_low.green(), self._led_low.blue(), self._led_low.alpha()),
            (self._led_high.red(), self._led_high.green(), self._led_high.blue(), self._led_high.alpha())
        )

    def _apply_save_hud(self):
        self.ledbezel.setSegments(self.s_hseg.value(), self.s_vseg.value())
        self.ledbezel.setThickness(self.s_thick.value())
        self.ledbezel.setMargin(self.s_margin.value())
        self.ledbezel.setSmoothing(self.s_smooth.value())
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                conf = json.load(f)
            conf.setdefault("hud", {})
            conf["hud"]["show_radar"] = self.cb_show_radar.isChecked()
            conf["hud"]["show_beacons"] = self.cb_show_beacons.isChecked()
            conf["hud"]["show_minibands"] = self.cb_show_bands.isChecked()
            conf["hud"]["show_ledbezel"] = self.cb_show_led.isChecked()
            conf["hud"].setdefault("led", {})
            led = conf["hud"]["led"]
            led["h_segments"] = self.s_hseg.value()
            led["v_segments"] = self.s_vseg.value()
            led["thickness_px"] = self.s_thick.value()
            led["margin_px"] = self.s_margin.value()
            led["smoothing"] = float(self.s_smooth.value())
            led["color_low"] = [self._led_low.red(), self._led_low.green(), self._led_low.blue(), self._led_low.alpha()]
            led["color_high"] = [self._led_high.red(), self._led_high.green(), self._led_high.blue(), self._led_high.alpha()]
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump(conf, f, indent=2, ensure_ascii=False)
            self._warn("Zapisano ustawienia HUD.", transient=True)
        except Exception as e:
            self._warn(f"Nie udało się zapisać HUD: {e}")

# AudioGames ONE (v9.3.14)

- HUD: radar, beacony, pasma, LED-ramka na 4 krawędziach (konfigurowalna).
- Audio: WASAPI loopback (adaptacyjne ustawienia), auto-wybór urządzenia, fallback na mikrofon.
- Ustawienia HUD: włącz/wyłącz moduły, kolory LED, segmenty, grubość, margines, smoothing, rozmiar radaru.
- Okno: tryb bezramkowy (Ctrl+F11).

## DEV
START_DEBUG.bat

## Build EXE
RUN_BUILD_ALL.cmd → portable\AudioGames_ONE.exe

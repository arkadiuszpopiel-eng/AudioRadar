
@echo off
setlocal
set PROJ_DIR=%~dp0
cd /d "%PROJ_DIR%"
python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
python -m GameAudioDirectionDetector --debug 1> portable\logs\start_debug.log 2>&1

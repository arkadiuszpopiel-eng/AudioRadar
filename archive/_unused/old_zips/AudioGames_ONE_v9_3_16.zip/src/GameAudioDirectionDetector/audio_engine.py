import numpy as np
import sounddevice as sd
from scipy.signal import get_window
import threading, queue, time, inspect

class AudioMetrics:
    __slots__ = ("angle_deg","level","bands")
    def __init__(self, angle_deg=0.0, level=0.0, bands=None):
        self.angle_deg = angle_deg
        self.level = level
        self.bands = bands or {"low":0.0, "mid":0.0, "high":0.0}

class AudioEngine:
    def __init__(self, samplerate=48000, blocksize=1024, gain=1.0, noise_gate=0.002, loopback=True, allow_fallback=True):
        self.samplerate = samplerate
        self.blocksize = blocksize
        self.gain = gain
        self.noise_gate = noise_gate
        self.loopback = loopback
        self.device = None
        self.allow_fallback = allow_fallback
        self.stream = None
        self.outq = queue.Queue(maxsize=8)
        self._stop = False
        self._bands_def = {"low": (55,135), "mid": (230,1350), "high": (2450,6600)}
        self._window = get_window("hann", blocksize, fftbins=True)

    def set_device(self, device_name_or_index):
        self.device = device_name_or_index

    def set_bands(self, bands):
        if bands: self._bands_def = {k: tuple(v) for k,v in bands.items()}

    def _choose_default_device(self, want_output=True):
        try:
            d_in, d_out = sd.default.device
            if want_output and d_out is not None and d_out >= 0:
                return d_out
            if not want_output and d_in is not None and d_in >= 0:
                return d_in
            dev = sd.query_devices(None, 'output' if want_output else 'input')
            return dev['index']
        except Exception:
            return None

    def start(self):
        self._stop = False
        target_device = self.device if self.device is not None else self._choose_default_device(want_output=self.loopback)

        # Adaptive WASAPI settings (sounddevice variants)
        extra_settings = None
        if self.loopback and hasattr(sd, "WasapiSettings"):
            try:
                params = inspect.signature(sd.WasapiSettings).parameters
                if "loopback" in params:
                    extra_settings = sd.WasapiSettings(loopback=True)
                elif "category" in params:
                    try:
                        extra_settings = sd.WasapiSettings(category='loopback')
                    except Exception:
                        extra_settings = None
                elif hasattr(sd.WasapiSettings, "LOOPBACK") and "flags" in params:
                    extra_settings = sd.WasapiSettings(flags=sd.WasapiSettings.LOOPBACK)
            except Exception:
                extra_settings = None

        try:
            self.stream = sd.InputStream(
                device=target_device,
                channels=2,
                samplerate=self.samplerate,
                blocksize=self.blocksize,
                dtype="float32",
                callback=self._callback,
                latency="low",
                extra_settings=extra_settings
            )
            self.stream.start()
            return True
        except Exception:
            if self.loopback and self.allow_fallback:
                try:
                    target_device_in = self._choose_default_device(want_output=False)
                    self.stream = sd.InputStream(
                        device=target_device_in,
                        channels=2,
                        samplerate=self.samplerate,
                        blocksize=self.blocksize,
                        dtype="float32",
                        callback=self._callback,
                        latency="low",
                        extra_settings=None
                    )
                    self.stream.start()
                    return True
                except Exception:
                    raise
            else:
                raise

    def stop(self):
        self._stop = True
        if self.stream:
            try: self.stream.stop()
            except Exception: pass
            try: self.stream.close()
            except Exception: pass
            self.stream = None

    def _callback(self, indata, frames, time_info, status):
        if status: pass
        try:
            data = np.copy(indata) * float(self.gain)
            if data.ndim == 1: data = np.stack([data, data], axis=1)
            L = data[:,0]; R = data[:,1]
            l_rms = np.sqrt(np.mean(L**2)); r_rms = np.sqrt(np.mean(R**2))
            level = 0.5*(l_rms+r_rms)
            if level < self.noise_gate:
                metrics = AudioMetrics(angle_deg=0.0, level=0.0, bands={"low":0.0,"mid":0.0,"high":0.0})
            else:
                ild = (r_rms - l_rms) / (r_rms + l_rms + 1e-9)
                ild = max(-1.0, min(1.0, ild))
                angle = ild * 90.0
                x = (L+R)*0.5
                xw = x * self._window
                spec = np.fft.rfft(xw, n=len(xw))
                freqs = np.fft.rfftfreq(len(xw), d=1.0/self.samplerate)
                power = (spec.real**2 + spec.imag**2)
                bands = {}
                for k,(f0,f1) in self._bands_def.items():
                    idx = (freqs>=f0) & (freqs<=f1)
                    bands[k] = float(np.mean(power[idx])) if np.any(idx) else 0.0
                metrics = AudioMetrics(angle_deg=float(angle), level=float(level), bands=bands)
            try: self.outq.put_nowait(metrics)
            except queue.Full: pass
        except Exception: pass

    def read(self, timeout=0.0):
        try: return self.outq.get(timeout=timeout)
        except queue.Empty: return None

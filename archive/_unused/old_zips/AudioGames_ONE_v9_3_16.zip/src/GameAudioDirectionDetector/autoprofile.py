import time, threading
import win32gui, win32process
import psutil

class ForegroundWatcher(threading.Thread):
    def __init__(self, name_map, on_change, poll=1.0, enabled=True):
        super().__init__(daemon=True)
        self.name_map = {k.lower(): v for k, v in (name_map or {}).items()}
        self.on_change = on_change
        self.poll = poll
        self.enabled = enabled
        self._stop = False
        self._last_exe = ""

    def run(self):
        while not self._stop:
            if self.enabled:
                try:
                    hwnd = win32gui.GetForegroundWindow()
                    tid, pid = win32process.GetWindowThreadProcessId(hwnd)
                    exe = psutil.Process(pid).name().lower()
                    if exe != self._last_exe:
                        self._last_exe = exe
                        profile = self.name_map.get(exe)
                        if profile:
                            self.on_change(profile, exe)
                except Exception:
                    pass
            time.sleep(self.poll)

    def stop(self):
        self._stop = True

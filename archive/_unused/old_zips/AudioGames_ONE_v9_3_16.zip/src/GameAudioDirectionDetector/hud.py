from PyQt5 import QtCore, QtGui, QtWidgets
import math

class RadarWidget(QtWidgets.QWidget):
    angleChanged = QtCore.pyqtSignal(float)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0

    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.angleChanged.emit(angle_deg)
        self.update()

    def paintEvent(self, ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        r = min(self.width(), self.height())/2 - 8
        c = QtCore.QPointF(self.width()/2, self.height()/2)
        # rings
        pen = QtGui.QPen(QtGui.QColor(120,120,120,100), 2)
        p.setPen(pen); p.setBrush(QtCore.Qt.NoBrush)
        for i in range(1,4):
            p.drawEllipse(c, r*i/3, r*i/3)
        # direction line
        ang = math.radians(self._angle - 90)
        x = c.x() + r*math.cos(ang); y = c.y() + r*math.sin(ang)
        p.setPen(QtGui.QPen(QtGui.QColor(100,200,255,200), 3))
        p.drawLine(c, QtCore.QPointF(x,y))
        # marker
        mr = max(3.0, min(r/6, self._level*400))
        p.setBrush(QtGui.QColor(100,200,255,180))
        p.setPen(QtGui.QPen(QtGui.QColor(0,0,0,0)))
        p.drawEllipse(QtCore.QPointF(x,y), mr, mr)

class EdgeBeacons(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level = 0.0
    def setAngleLevel(self, angle_deg, level):
        self._angle = angle_deg
        self._level = level
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        t = (self._angle + 90.0) / 180.0
        x = int(t*w)
        alpha = int(max(0, min(180, self._level*800)))
        color = QtGui.QColor(100,200,255, alpha)
        p.fillRect(0,0,w,6, QtGui.QColor(color))
        p.fillRect(0,h-6,w,6, QtGui.QColor(color))
        p.fillRect(max(0,x-6), 0, 12, h, QtGui.QColor(color))

class MiniBands(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(60)
        self._bands = {"low":0.0,"mid":0.0,"high":0.0}
    def setBands(self, bands):
        self._bands = bands or self._bands
        self.update()
    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w,h = self.width(), self.height()
        keys = ["low","mid","high"]
        for i,k in enumerate(keys):
            v = self._bands.get(k,0.0)
            bar_h = min(h-10, int(v*0.0005*h + 5))
            x0 = int(i*w/3 + 10)
            p.fillRect(x0, h-bar_h, int(w/3)-20, bar_h, QtGui.QColor(100,200,255,200))
        p.setPen(QtGui.QPen(QtGui.QColor(120,120,120,120),1))
        p.drawRect(0,0,w-1,h-1)

class LEDBezel(QtWidgets.QWidget):
    """LED-owa ramka na czterech krawędziach z konfiguracją runtime."""
    def __init__(self, parent=None, h_segments=28, v_segments=18, thickness=8, margin=6,
                 color_low=QtGui.QColor(100,200,255,180), color_high=QtGui.QColor(255,80,80,220),
                 smoothing=0.35):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self._angle = 0.0
        self._level_raw = 0.0
        self._level_sm = 0.0
        self.h_segments = h_segments
        self.v_segments = v_segments
        self.thickness = thickness
        self.margin = margin
        self.color_low = color_low
        self.color_high = color_high
        self.smoothing = float(max(0.0, min(0.99, smoothing)))
        self.setMinimumHeight(70)

    def setSegments(self, h=None, v=None):
        if h is not None: self.h_segments = int(max(4, h))
        if v is not None: self.v_segments = int(max(4, v))
        self.update()

    def setThickness(self, px): self.thickness = int(max(2, px)); self.update()
    def setMargin(self, px): self.margin = int(max(0, px)); self.update()
    def setColors(self, low_rgba=None, high_rgba=None):
        if low_rgba: self.color_low = QtGui.QColor(*low_rgba)
        if high_rgba: self.color_high = QtGui.QColor(*high_rgba)
        self.update()
    def setSmoothing(self, alpha): self.smoothing = float(max(0.0, min(0.99, alpha)))

    def setAngleLevel(self, angle_deg, level):
        self._angle = float(angle_deg)
        self._level_raw = float(max(0.0, level))
        a = self.smoothing
        self._level_sm = (1.0 - a) * self._level_raw + a * self._level_sm
        self.update()

    def _mix(self, a, b, t): return int(a + (b - a) * t)
    def _blend_color(self, t):
        return QtGui.QColor(
            self._mix(self.color_low.red(), self.color_high.red(), t),
            self._mix(self.color_low.green(), self.color_high.green(), t),
            self._mix(self.color_low.blue(), self.color_high.blue(), t),
            self._mix(self.color_low.alpha(), self.color_high.alpha(), t),
        )

    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        w, h = self.width(), self.height()
        margin = self.margin
        thick = self.thickness
        inten = max(0.0, min(1.0, self._level_sm * 6.0))
        base = self._blend_color(inten)
        t = (self._angle + 90.0) / 180.0
        def gauss(d): 
            return max(0.0, min(1.0, pow(2.71828, -(d*d)/8.0)))

        # TOP & BOTTOM
        n = self.h_segments
        seg_w = max(4, int((w - 2*margin) / n - 2))
        target = t * (n-1) if n>1 else 0
        for i in range(n):
            weight = gauss(i - target)
            alpha = int(20 + 220 * inten * weight)
            color = QtGui.QColor(base.red(), base.green(), base.blue(), alpha)
            x = margin + i * (seg_w + 2)
            p.fillRect(x, margin, seg_w, thick, color)
            p.fillRect(x, h - margin - thick, seg_w, thick, color)

        # LEFT & RIGHT
        m = self.v_segments
        seg_h = max(4, int((h - 2*margin - 2*thick - 10) / m - 2))
        left_w = gauss(target - 0)
        right_w = gauss((n-1) - target)
        alpha_l = int(20 + 180 * inten * left_w)
        alpha_r = int(20 + 180 * inten * right_w)
        color_l = QtGui.QColor(base.red(), base.green(), base.blue(), alpha_l)
        color_r = QtGui.QColor(base.red(), base.green(), base.blue(), alpha_r)
        for j in range(m):
            y = margin + thick + 5 + j * (seg_h + 2)
            p.fillRect(margin, y, thick, seg_h, color_l)
            p.fillRect(w - margin - thick, y, thick, seg_h, color_r)

        # Direction indicator
        xdir = int(margin + target * (seg_w + 2) + seg_w/2) if n>1 else int(w/2)
        p.fillRect(max(0, xdir-1), 0, 2, h, QtGui.QColor(base.red(), base.green(), base.blue(), int(30+150*inten)))

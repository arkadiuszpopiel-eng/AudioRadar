import json, os, glob

class ProfileManager:
    def __init__(self, profiles_dir, default_bands):
        self.profiles_dir = profiles_dir
        self.default_bands = default_bands
        self.current = {"name": "Default", "bands": default_bands}
        self._cache = {}
        self.reload()

    def reload(self):
        self._cache.clear()
        for p in glob.glob(os.path.join(self.profiles_dir, "*.json")):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if "name" in data and "bands" in data:
                        self._cache[data["name"]] = data
            except Exception:
                pass

    def names(self):
        return list(self._cache.keys())

    def load(self, name):
        if name in self._cache:
            self.current = self._cache[name]
        return self.current

    def current_bands(self):
        return self.current.get("bands", self.default_bands)

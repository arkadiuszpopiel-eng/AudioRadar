import time, threading
try:
    import win32gui, win32process
    import psutil
except Exception:
    win32gui = win32process = psutil = None

class ForegroundWatcher(threading.Thread):
    def __init__(self, name_map, on_change, poll=1.0, enabled=True):
        super().__init__(daemon=True)
        self.name_map = {k.lower(): v for k,v in (name_map or {}).items()}
        self.on_change = on_change; self.poll = poll
        self.enabled = enabled and win32gui and win32process and psutil
        self._stop = False; self._last = ""
    def run(self):
        while not self._stop:
            if self.enabled:
                try:
                    hwnd = win32gui.GetForegroundWindow()
                    tid, pid = win32process.GetWindowThreadProcessId(hwnd)
                    exe = psutil.Process(pid).name().lower()
                    if exe != self._last:
                        self._last = exe
                        prof = self.name_map.get(exe)
                        if prof: self.on_change(prof, exe)
                except Exception: pass
            time.sleep(self.poll)
    def stop(self): self._stop = True

from PyQt5 import QtCore, QtGui, QtWidgets
from .hud import RadarWidget

class RadarFloat(QtWidgets.QWidget):
    closed = QtCore.pyqtSignal()
    def __init__(self, settings_getter, settings_setter, parent=None):
        super().__init__(parent)
        self._get = settings_getter; self._set = settings_setter
        self.setWindowTitle("Radar (floating)"); self.setObjectName("RadarFloat")
        self.setWindowFlags(QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.NoDropShadowWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.container = QtWidgets.QFrame(); self.container.setObjectName("rf_container")
        self.container.setStyleSheet("#rf_container { background: rgba(10,10,12,180); border: 1px solid rgba(100,100,120,160); border-radius: 12px; }")
        self.radar = RadarWidget()
        lay = QtWidgets.QVBoxLayout(self.container); lay.setContentsMargins(10,10,10,10); lay.addWidget(self.radar,1)
        root = QtWidgets.QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.addWidget(self.container)
        self._drag=None; self._scale=1.0; self._locked=False; self._apply_from_conf()
    def _apply_from_conf(self):
        cfg = self._get() or {}; g=cfg.get("geom",[200,200,340,340])
        try: self.setGeometry(QtCore.QRect(*g))
        except Exception: pass
        self._scale=float(cfg.get("scale",1.0)); self.setWindowOpacity(float(cfg.get("opacity",0.9)))
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, bool(cfg.get("click_through", False)))
        self._locked = bool(cfg.get("locked", False))
    def _save(self):
        g=[self.x(), self.y(), self.width(), self.height()]
        self._set({"geom":g,"scale":self._scale,"opacity":float(self.windowOpacity()),
                   "click_through": bool(self.testAttribute(QtCore.Qt.WA_TransparentForMouseEvents)),
                   "locked": self._locked})
    def setAngleLevel(self, a, l): self.radar.setAngleLevel(a, l)
    def mousePressEvent(self, e):
        if e.button()==QtCore.Qt.LeftButton and not self._locked and not self.testAttribute(QtCore.Qt.WA_TransparentForMouseEvents):
            self._drag = e.globalPos() - self.frameGeometry().topLeft(); e.accept()
    def mouseMoveEvent(self, e):
        if self._drag and (e.buttons() & QtCore.Qt.LeftButton):
            self.move(e.globalPos() - self._drag); e.accept()
    def mouseReleaseEvent(self, e):
        if self._drag: self._drag=None; self._save()
    def wheelEvent(self, e):
        d=e.angleDelta().y(); step=0.02 if (e.modifiers() & QtCore.Qt.ControlModifier) else 0.08
        self._scale=max(0.5, min(3.0, self._scale + (step if d>0 else -step)))
        w0,h0=320,320; w=int(w0*self._scale); h=int(h0*self._scale)
        c=self.geometry().center(); self.setGeometry(c.x()-w//2, c.y()-h//2, w, h); self._save()
    def contextMenuEvent(self, e):
        m=QtWidgets.QMenu(self)
        a1=m.addAction("Lock position" + (" ✔" if self._locked else ""))
        a2=m.addAction("Enable click-through" + (" ✔" if self.testAttribute(QtCore.Qt.WA_TransparentForMouseEvents) else ""))
        a3=m.addAction("Set opacity 70%"); a4=m.addAction("Reset size/pos"); a5=m.addAction("Close floating radar")
        a=m.exec_(e.globalPos())
        if a==a1: self._locked=not self._locked; self._save()
        elif a==a2: self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, not self.testAttribute(QtCore.Qt.WA_TransparentForMouseEvents)); self._save()
        elif a==a3: self.setWindowOpacity(0.7); self._save()
        elif a==a4: self._scale=1.0; self.resize(340,340); self.move(200,200); self._save()
        elif a==a5: self.close()
    def closeEvent(self, ev):
        self._save(); self.closed.emit(); super().closeEvent(ev)

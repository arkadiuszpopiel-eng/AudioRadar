import sys, os
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if base_dir not in sys.path: sys.path.insert(0, base_dir)

from GameAudioDirectionDetector.__main__ import main

# sentinel imports for PyInstaller
import GameAudioDirectionDetector.main_window  # noqa: F401
import GameAudioDirectionDetector.hud          # noqa: F401
import GameAudioDirectionDetector.audio_engine # noqa: F401
import GameAudioDirectionDetector.autoprofile  # noqa: F401
import GameAudioDirectionDetector.profiles     # noqa: F401
import GameAudioDirectionDetector.radar_float  # noqa: F401

if __name__ == "__main__": main()


@echo off
setlocal
set PROJ=%~dp0
cd /d "%PROJ%"

echo === VENV ===
py -3 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt > build_log.txt 2>&1

echo === CLEAN ===
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo === PYINSTALLER (spec) ===
pyinstaller build.spec >> build_log.txt 2>&1

if not exist dist\AudioGames_ONE\AudioGames_ONE.exe (
  echo Build failed. Check build_log.txt
  type build_log.txt | findstr /i /c:"error" /c:"traceback"
  pause
  exit /b 1
)

echo === PREPARE PORTABLE ===
if not exist portable mkdir portable
copy /y "dist\AudioGames_ONE\AudioGames_ONE.exe" "portable\AudioGames_ONE.exe" >nul

rem -- COPY _internal to portable if exists
if exist "dist\AudioGames_ONE\_internal" (
  echo Copying _internal runtime directory...
  if exist "portable\_internal" rmdir /s /q "portable\_internal"
  xcopy /e /i /y "dist\AudioGames_ONE\_internal" "portable\_internal" >nul
)

> "portable\START_HERE.bat" (
  echo @echo off
  echo if not exist "%%~dp0logs" mkdir "%%~dp0logs"
  echo start "" "%%~dp0AudioGames_ONE.exe" --lang=pl --theme=ProDark_Fluent.qss --ui=full ^>^> "%%~dp0logs\start_here.log" 2^>^&1
)

echo Done. Portable: portable\AudioGames_ONE.exe
pause

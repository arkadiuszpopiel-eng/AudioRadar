import os, sys, argparse
from PyQt5 import QtWidgets
import io, datetime

class Tee(io.TextIOBase):
    def __init__(self,*s): self.s=s
    def write(self,t):
        for x in self.s:
            try: x.write(t)
            except Exception: pass
        return len(t)
    def flush(self): 
        for x in self.s:
            try: x.flush()
            except Exception: pass

from GameAudioDirectionDetector.main_window import MainWindow

def _find_settings_path():
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(exe_dir, "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(exe_dir), "portable", "bin", "settings.json"),
        os.path.join(os.getcwd(), "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "portable", "bin", "settings.json"),
    ]
    for c in candidates:
        if os.path.exists(c): return c
    raise SystemExit("Nie znaleziono portable/bin/settings.json obok aplikacji.")

def main():
    import os, sys, io, datetime, traceback, json
    # Logging bootstrap to portable/logs/runtime.log
    base = os.path.dirname(sys.executable) if getattr(sys,'frozen',False) else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    logdir = os.path.join(base, 'portable','logs'); os.makedirs(logdir, exist_ok=True)
    logfile = os.path.join(logdir,'runtime.log')
    f = open(logfile,'a',encoding='utf-8', buffering=1)
    class Tee(io.TextIOBase):
        def __init__(self,*streams): self.s=streams
        def write(self,t):
            for x in self.s:
                try: x.write(t)
                except Exception: pass
            return len(t)
        def flush(self):
            for x in self.s:
                try: x.flush()
                except Exception: pass
    sys.stdout = Tee(sys.stdout, f)
    sys.stderr = Tee(sys.stderr, f)
    print("
=== START", datetime.datetime.now().isoformat(), "===")

    def _global_excepthook(exctype, value, tb):
        tb_str = "".join(traceback.format_exception(exctype, value, tb))
        print("UNCAUGHT_EXCEPTION_JSON:", json.dumps({
            "type": exctype.__name__, "message": str(value), "traceback": tb_str
        }, ensure_ascii=False))
        # don't kill the app
    sys.excepthook = _global_excepthook

    from PyQt5 import QtWidgets
    from GameAudioDirectionDetector.main_window import MainWindow
    settings_path = _find_settings_path()
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(settings_path); win.resize(900, 700); win.show()
    try:
        names = [win.tabs.tabText(i) for i in range(win.tabs.count())]
        print("LOG_TABS:", ", ".join(names))
    except Exception: pass
    sys.exit(app.exec_())

if __name__ == "__main__": main()

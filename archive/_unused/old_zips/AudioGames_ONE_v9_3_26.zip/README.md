# AudioGames ONE (v9.3.23)
- Start przez GameAudioDirectionDetector/__main__.py (bez błędu __main__).
- Kopiowanie _internal do portable/_internal po buildzie.
- HUD: radar, beacony, pasma, LED-ramka.
- Pływający radar, frameless, edytor układu HUD + presety.
- Pełny logging (runtime.log), bezpieczne sloty, fallback audio mono/stereo.

import os, sys, argparse, io, datetime, traceback, json
from PyQt5 import QtWidgets
from GameAudioDirectionDetector.main_window import MainWindow

class Tee(io.TextIOBase):
    def __init__(self,*s): self.s=s
    def write(self,t):
        for x in self.s:
            try: x.write(t)
            except Exception: pass
        return len(t)
    def flush(self): 
        for x in self.s:
            try: x.flush()
            except Exception: pass

def _find_settings_path():
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(exe_dir, "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(exe_dir), "portable", "bin", "settings.json"),
        os.path.join(os.getcwd(), "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "portable", "bin", "settings.json"),
    ]
    for c in candidates:
        if os.path.exists(c): return c
    raise SystemExit("Nie znaleziono portable/bin/settings.json obok aplikacji.")

def main():
    # logging bootstrap
    try:
        base = os.path.dirname(sys.executable) if getattr(sys,'frozen',False) else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logp = os.path.join(base, 'portable','logs'); os.makedirs(logp, exist_ok=True)
        f = open(os.path.join(logp,'runtime.log'),'a',encoding='utf-8', buffering=1)
        sys.stdout = Tee(sys.stdout, f); sys.stderr = Tee(sys.stderr, f)
        print("\n=== START " + str(datetime.datetime.now()) + " ===")
    except Exception:
        pass

    # keep app alive on uncaught exceptions
    def _global_excepthook(exctype, value, tb):
        tb_str = "".join(traceback.format_exception(exctype, value, tb))
        try:
            print("UNCAUGHT_EXCEPTION_JSON:", json.dumps({
                "type": exctype.__name__, "message": str(value), "traceback": tb_str
            }, ensure_ascii=False))
        except Exception:
            pass
    sys.excepthook = _global_excepthook

    settings_path = _find_settings_path()
    app = QtWidgets.QApplication(sys.argv)
    parser = argparse.ArgumentParser(); parser.add_argument("--lang", default="pl"); parser.add_argument("--theme", default="ProDark_Fluent.qss"); parser.add_argument("--ui", default="full"); parser.add_argument("--debug", action="store_true")
    _ = parser.parse_args()

    win = MainWindow(settings_path); win.resize(900, 700); win.show()
    try:
        names = [win.tabs.tabText(i) for i in range(win.tabs.count())]
        print("LOG_TABS:", ", ".join(names))
    except Exception: pass
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

import json, os, glob
class ProfileManager:
    def __init__(self, profiles_dir, default_bands):
        self.dir = profiles_dir
        self.default_bands = default_bands
        self._cache = {}
        self.current = {"name":"Default","bands":default_bands}
        self.reload()
    def reload(self):
        self._cache.clear()
        for p in glob.glob(os.path.join(self.dir, "*.json")):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if "name" in d and "bands" in d:
                    self._cache[d["name"]] = d
            except Exception: pass
    def names(self): return list(self._cache.keys())
    def load(self, name):
        if name in self._cache: self.current = self._cache[name]
        return self.current
    def current_bands(self): return self.current.get("bands", self.default_bands)

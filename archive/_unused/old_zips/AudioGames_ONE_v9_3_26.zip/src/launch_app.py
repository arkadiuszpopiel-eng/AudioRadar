import sys, os
def _run_embedded_main():
    from PyQt5 import QtWidgets
    base = os.path.dirname(sys.executable) if getattr(sys,'frozen',False)            else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        os.path.join(base, "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(base), "portable", "bin", "settings.json"),
        os.path.join(os.getcwd(), "portable", "bin", "settings.json"),
    ]
    settings_path = next((c for c in candidates if os.path.exists(c)), None)
    if not settings_path:
        raise SystemExit("Brak portable/bin/settings.json — nie można uruchomić.")
    from GameAudioDirectionDetector.main_window import MainWindow
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(settings_path); win.resize(900,700); win.show()
    sys.exit(app.exec_())
try:
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if base_dir not in sys.path: sys.path.insert(0, base_dir)
    from GameAudioDirectionDetector.__main__ import main as _pkg_main
    if __name__ == "__main__":
        _pkg_main()
except Exception:
    if __name__ == "__main__":
        _run_embedded_main()

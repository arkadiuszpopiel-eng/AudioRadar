
@echo off
setlocal
set PROJ_DIR=%~dp0
cd /d "%PROJ_DIR%"
echo === Creating virtual environment ===
py -3 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt > build_log.txt 2>&1

echo === Building onefile EXE (no icon flag) ===
set SRC=src\launch_app.py
pyinstaller -F -n AudioGames_ONE --add-data "portable\bin;portable\\bin" "%SRC%" >> build_log.txt 2>&1

if not exist dist\AudioGames_ONE.exe (
  echo Build failed. Check build_log.txt
  type build_log.txt | findstr /i /c:"error" /c:"Traceback"
  pause
  exit /b 1
)

echo === Preparing portable folder ===
copy /y dist\AudioGames_ONE.exe portable\AudioGames_ONE.exe >nul
copy /y assets\AudioGames.ico portable\AudioGames.ico >nul
echo @echo off> portable\START_HERE.bat
echo start "" "%~dp0AudioGames_ONE.exe" --lang=pl --theme=ProDark_Fluent.qss --ui=full >> portable\START_HERE.bat
echo echo Jesli nic sie nie uruchamia, uruchom AudioGames_ONE.exe recznie >> portable\START_HERE.bat

echo Done. Portable build is in .\portable
pause

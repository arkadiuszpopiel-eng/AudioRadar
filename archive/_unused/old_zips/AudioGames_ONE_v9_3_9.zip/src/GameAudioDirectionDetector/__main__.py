import os, sys, argparse
from PyQt5 import QtWidgets
from GameAudioDirectionDetector.main_window import MainWindow

def _find_settings_path():
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(exe_dir, "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(exe_dir), "portable", "bin", "settings.json"),
        os.path.join(os.getcwd(), "portable", "bin", "settings.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "portable", "bin", "settings.json"),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    raise SystemExit("Nie znaleziono portable/bin/settings.json obok aplikacji.")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lang", default="pl")
    parser.add_argument("--theme", default="ProDark_Fluent.qss")
    parser.add_argument("--ui", default="full")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    settings_path = _find_settings_path()
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow(settings_path)
    win.resize(900, 700)
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

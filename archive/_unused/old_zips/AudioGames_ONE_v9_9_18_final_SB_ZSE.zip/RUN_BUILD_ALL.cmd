@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
title AudioGames ONE - Build All (v9.9.18 SB Z SE Final)
set "LOG=build_log.txt"
> "%LOG%" echo === Python / VENV ===
if not exist .venv ( py -3 -m venv .venv >> "%LOG%" 2>&1 )
call .venv\Scripts\activate.bat
python -V >> "%LOG%" 2>&1
echo === Pip upgrade === >> "%LOG%"
python -m pip install -U pip wheel setuptools >> "%LOG%" 2>&1
echo === Install requirements === >> "%LOG%"
python -m pip install -r requirements.txt >> "%LOG%" 2>&1
echo === Sanity check === >> "%LOG%"
for %%F in (__init__.py __main__.py main_window.py hud.py ledbars.py audio_engine.py tracker.py settings.py replay.py footstep_engine.py logger.py) do (
  if not exist src\GameAudioDirectionDetector\%%F (echo [ERR] missing src\GameAudioDirectionDetector\%%F >> "%LOG%" & goto :fail)
)
echo === Clean === >> "%LOG%"
rmdir /s /q build  >nul 2>&1
rmdir /s /q dist   >nul 2>&1
if not exist portable mkdir portable
if not exist portable\logs mkdir portable\logs
echo === PyInstaller === >> "%LOG%"
pyinstaller build.spec >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
set "EXE1=dist\AudioGames_ONE\AudioGames_ONE.exe"
set "EXE2=dist\AudioGames_ONE.exe"
if exist "%EXE1%" (
  copy /y "%EXE1%" portable\ >> "%LOG%" 2>&1
) else if exist "%EXE2%" (
  copy /y "%EXE2%" portable\ >> "%LOG%" 2>&1
) else (
  echo [ERR] EXE not found >> "%LOG%"
  goto :fail
)
copy /y START_HERE.bat portable\ >> "%LOG%" 2>&1
echo === SELFTEST === >> "%LOG%"
portable\AudioGames_ONE.exe --selftest >> "%LOG%" 2>&1
if errorlevel 1 (echo [ERR] SELFTEST failed >> "%LOG%" & goto :fail) else (echo [OK] SELFTEST passed >> "%LOG%")
echo [INFO] EXE found at dist\AudioGames_ONE.exe >> "%LOG%"
echo Portable build ready in .\portable
pause
exit /b 0
:fail
echo Build failed. See build_log.txt
pause
exit /b 1

@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
start "" "%~dp0AudioGames_ONE.exe"

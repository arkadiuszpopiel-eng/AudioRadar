# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files
hiddenimports = collect_submodules('GameAudioDirectionDetector')
datas = collect_data_files('GameAudioDirectionDetector', includes=['**/*.json'])
a = Analysis(['src/GameAudioDirectionDetector/__main__.py'],
             pathex=['src'],
             binaries=[],
             datas=datas,
             hiddenimports=hiddenimports,
             noarchive=False)
pyz = PYZ(a.pure, a.zipped_data, cipher=None)
exe = EXE(pyz, a.scripts, a.binaries, a.zipfiles, a.datas, name='AudioGames_ONE', console=False)

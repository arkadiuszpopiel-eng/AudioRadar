import sys, os
if "--selftest" in sys.argv:
    print("SELFTEST_OK"); sys.exit(0)
from PyQt5 import QtWidgets
from GameAudioDirectionDetector.main_window import MainWindow
def main():
    app = QtWidgets.QApplication(sys.argv)
    base = os.path.abspath(os.path.dirname(__file__))
    spath = os.path.join(base, "settings.json")
    win = MainWindow(spath)
    win.show()
    sys.exit(app.exec_())
if __name__ == "__main__":
    main()

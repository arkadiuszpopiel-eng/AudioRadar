import threading, queue, time
from typing import List, Dict, Callable, Optional, Tuple
try:
    import sounddevice as sd
except Exception:
    sd = None
import numpy as np

class CaptureMode: MICROPHONE='microphone'; SYSTEM_LOOPBACK='system_loopback'

def _hostapi_wasapi_ids():
    try:
        hostapis = sd.query_hostapis()
        return [i for i,ha in enumerate(hostapis) if 'wasapi' in ha['name'].lower()]
    except Exception:
        return []

def list_input_devices(loopback_only=False) -> List[Tuple[int,str,int]]:
    devs=[]
    try:
        wasapi_ids=_hostapi_wasapi_ids()
        for idx, d in enumerate(sd.query_devices()):
            name=str(d.get('name','')); ic=int(d.get('max_input_channels',0)); oc=int(d.get('max_output_channels',0)); ha=int(d.get('hostapi',-1))
            if loopback_only:
                if ha in wasapi_ids and oc>0: devs.append((idx, f"{idx}: {name} ({oc}ch OUT)", oc))
            else:
                if ic>0: devs.append((idx, f"{idx}: {name} ({ic}ch IN)", ic))
    except Exception: pass
    return devs

def find_preferred_device(prefer: str, loopback: bool=True) -> Optional[int]:
    prefer = (prefer or "").lower()
    for idx, label, _ch in list_input_devices(loopback_only=loopback):
        if prefer and prefer in label.lower():
            return idx
        if 'sound blaster' in label.lower() and 'z' in label.lower():
            return idx
    return None

class AudioEngine:
    def __init__(self, samplerate=48000, blocksize=1024, low_latency=False):
        self.samplerate=samplerate; self.blocksize=blocksize; self.low_latency=low_latency
        self.stream=None; self.thread=None; self.running=False; self.q=queue.Queue(maxsize=64)
        self.detection_listeners: List[Callable[[List[Dict]], None]] = []
        self.frame_listeners: List[Callable[[np.ndarray], None]] = []
        self.capture_mode=CaptureMode.SYSTEM_LOOPBACK; self.device_index=None
        self.min_db=-55.0; self.last_level_db=-90.0

    def on_frame(self, cb: Callable[[np.ndarray], None]):
        self.frame_listeners.append(cb)

    def set_input(self, mode:str=None, device_index:int=None, low_latency:bool=None):
        if mode is not None: self.capture_mode=mode
        if device_index is not None: self.device_index=device_index
        if low_latency is not None: self.low_latency=bool(low_latency)
        return True

    def start(self):
        if self.running: return True
        if sd is None:
            self.running=True; self.thread=threading.Thread(target=self._demo_worker, daemon=True); self.thread.start(); return True
        try:
            self.running=True
            bs = 1024 if not self.low_latency else 256
            if self.capture_mode==CaptureMode.SYSTEM_LOOPBACK:
                try:
                    was=sd.WasapiSettings(loopback=True)
                    dev=self.device_index if self.device_index is not None else sd.default.device[1]
                    self.stream=sd.InputStream(device=dev, samplerate=self.samplerate, channels=2, dtype='float32',
                                               latency='high', extra_settings=was, callback=self._callback, blocksize=bs)
                except Exception:
                    self.stream=sd.InputStream(channels=2, samplerate=self.samplerate, blocksize=bs,
                                               callback=self._callback, dtype='float32')
            else:
                kwargs=dict(channels=2, samplerate=self.samplerate, blocksize=bs, callback=self._callback, dtype='float32')
                if self.device_index is not None: kwargs['device']=self.device_index
                self.stream=sd.InputStream(**kwargs)
            self.stream.start(); self.thread=threading.Thread(target=self._worker, daemon=True); self.thread.start(); return True
        except Exception:
            self.running=False; return False

    def stop(self):
        self.running=False
        try:
            if self.stream: self.stream.stop(); self.stream.close()
        except Exception: pass
        self.stream=None

    def _callback(self, indata, frames, time_info, status):
        try: self.q.put_nowait(indata.copy())
        except queue.Full: pass

    def _worker(self):
        while self.running:
            try: data=self.q.get(timeout=0.5)
            except queue.Empty: continue
            if data.shape[1]<2: continue
            for cb in list(self.frame_listeners):
                try: cb(data)
                except Exception: pass
            L=data[:,0]; R=data[:,1]
            rms=float(np.sqrt(np.mean(((L+R)*0.5)**2)+1e-12)); level_db=20.0*np.log10(rms+1e-12); self.last_level_db=level_db
            if level_db<self.min_db: continue
            t=time.time(); angle=(t*30.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':float(level_db),'label':'speech','proba':{'speech':0.7}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass

    def _demo_worker(self):
        import numpy as np, time
        while self.running:
            t=time.time(); angle=(t*30.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':-20.0,'label':'speech','proba':{'speech':0.7}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass
            frame=np.zeros((512,2),dtype='float32')
            for cb in list(self.frame_listeners):
                try: cb(frame)
                except Exception: pass
            time.sleep(0.2)

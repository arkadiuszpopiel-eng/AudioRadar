from PyQt5 import QtCore, QtGui, QtWidgets
import time, math
class EdgeRingWidget(QtWidgets.QWidget):
    def __init__(self, parent=None, sectors=72):
        super().__init__(parent); self.N=sectors; self.setMinimumHeight(280)
        self.energy=[0.0]*self.N; self._last=time.time(); self._impulse_alpha=0.0
        self._timer=QtCore.QTimer(self); self._timer.setInterval(16); self._timer.timeout.connect(self._anim); self._timer.start()
        self.show_impulses=True
    def flash_impulse(self): self._impulse_alpha=1.0; self.update()
    def update_sectors(self, dets):
        now=time.time(); dt=now-self._last; self._last=now; decay=math.exp(-dt/0.7)
        for i in range(self.N): self.energy[i]*=decay
        for d in dets or []:
            ang=float(d.get('angle_deg',0.0))%360.0; idx=int(round(ang/(360.0/self.N)))%self.N
            lvl=float(d.get('level_db',-40.0)); e=max(0.0,min(1.0,(lvl+60.0)/60.0)); self.energy[idx]=max(self.energy[idx],e)
        self.update()
    def _anim(self): self._impulse_alpha*=0.90; self.update()
    def paintEvent(self,ev):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing,True)
        p.fillRect(self.rect(),QtGui.QColor(8,10,12))
        w,h=self.width(),self.height(); cx,cy=w//2,h//2; r=min(w,h)//2-8
        pen=QtGui.QPen(QtGui.QColor(40,70,100)); p.setPen(pen)
        for rr in (int(r*0.95),int(r*0.65),int(r*0.35)): p.drawEllipse(QtCore.QPoint(cx,cy),rr,rr)
        seg=360.0/self.N; r0=int(r*0.88)
        for i,e in enumerate(self.energy):
            if e<=0.05: continue
            col=QtGui.QColor(200,220,255,int(80+160*e)); pen=QtGui.QPen(col); pen.setWidth(6); p.setPen(pen)
            ang_mid=i*seg; a0=-(ang_mid+seg*0.5); rect=QtCore.QRectF(cx-r0,cy-r0,2*r0,2*r0); p.drawArc(rect,int(a0*16),int(seg*16))
        if self.show_impulses and self._impulse_alpha>0.02:
            pen=QtGui.QPen(QtGui.QColor(255,255,255,int(200*self._impulse_alpha))); pen.setWidth(2); p.setPen(pen)
            rect=QtCore.QRectF(cx-r0,cy-r0,2*r0,2*r0); p.drawArc(rect,int(-10*16),int(20*16))
        p.end()

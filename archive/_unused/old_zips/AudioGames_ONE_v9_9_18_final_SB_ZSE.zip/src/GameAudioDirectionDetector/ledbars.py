from PyQt5 import QtCore, QtGui, QtWidgets
import math
def energy_from_db(level_db: float) -> float:
    return max(0.0, min(1.0, (level_db + 60.0)/60.0))
def color_from_energy(e: float) -> QtGui.QColor:
    hue = int((1.0 - max(0.0, min(1.0, e))) * 60)
    c = QtGui.QColor.fromHsv(hue, 255, int(180 + 75*e)); c.setAlpha(int(140 + 100*e)); return c
class EdgeLedBars(QtWidgets.QWidget):
    def __init__(self, parent=None, decay=0.85, gain=1.0):
        super().__init__(parent); self.setMinimumHeight(260)
        self.decay=float(decay); self.gain=float(gain)
        self.num={'top':3,'bottom':3,'left':2,'right':2}
        self.energy={'top':[0.0]*3,'bottom':[0.0]*3,'left':[0.0]*2,'right':[0.0]*2}
        self.impulse={'top':[0.0]*3,'bottom':[0.0]*3,'left':[0.0]*2,'right':[0.0]*2}
        self._timer=QtCore.QTimer(self); self._timer.setInterval(16); self._timer.timeout.connect(self._anim); self._timer.start()
    def set_params(self, decay=None,gain=None):
        if decay is not None: self.decay=float(decay)
        if gain is not None: self.gain=float(gain)
    def _map_angle(self, a):
        a=a%360.0; rad=math.radians(a); x,y=math.cos(rad),math.sin(rad)
        if abs(y)>=abs(x): edge='top' if y>=0 else 'bottom'; t=(x+1)/2; bins=self.num[edge]; idx=min(bins-1,max(0,int(t*bins)))
        else: edge='right' if x>=0 else 'left'; t=(y+1)/2; bins=self.num[edge]; idx=min(bins-1,max(0,int(t*bins)))
        return edge,idx
    def update_from_detections(self,dets):
        for e in self.energy:
            for i in range(len(self.energy[e])):
                self.energy[e][i]*=self.decay; self.impulse[e][i]*=0.9
        for d in dets or []:
            ang=float(d.get('angle_deg',0.0)); lvl=float(d.get('level_db',-40.0)); e=min(1.0, energy_from_db(lvl)*self.gain)
            edge,idx=self._map_angle(ang); self.energy[edge][idx]=max(self.energy[edge][idx],e); self.impulse[edge][idx]=max(self.impulse[edge][idx],e)
        self.update()
    def paintEvent(self,ev):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing,True); w,h=self.width(),self.height()
        p.fillRect(self.rect(), QtGui.QColor(8,10,12))
        m=18; s=10; th=14
        seg_w=(w-2*m-2*s)/3.0
        top=[QtCore.QRectF(m+i*(seg_w+s), m, seg_w, th) for i in range(3)]
        bot=[QtCore.QRectF(m+i*(seg_w+s), h-m-th, seg_w, th) for i in range(3)]
        seg_h=(h-2*m-s)/2.0
        left=[QtCore.QRectF(m, m+i*(seg_h+s), th, seg_h) for i in range(2)]
        right=[QtCore.QRectF(w-m-th, m+i*(seg_h+s), th, seg_h) for i in range(2)]
        def draw_bar(rect,e,imp,h=True):
            rail=QtGui.QColor(40,60,80,120); p.fillRect(rect,rail)
            col=color_from_energy(e); grad=QtGui.QLinearGradient(rect.topLeft(), rect.topRight() if h else rect.bottomLeft())
            col2=QtGui.QColor.fromHsv(0,255,180); grad.setColorAt(0.0,col); grad.setColorAt(1.0,col2); p.fillRect(rect,grad)
            if imp>0.02: pen=QtGui.QPen(color_from_energy(imp)); pen.setWidth(3); p.setPen(pen); p.drawRect(rect)
        for i,r in enumerate(top): draw_bar(r,self.energy['top'][i],self.impulse['top'][i],True)
        for i,r in enumerate(bot): draw_bar(r,self.energy['bottom'][i],self.impulse['bottom'][i],True)
        for i,r in enumerate(left): draw_bar(r,self.energy['left'][i],self.impulse['left'][i],False)
        for i,r in enumerate(right): draw_bar(r,self.energy['right'][i],self.impulse['right'][i],False)
        p.end()
    def _anim(self):
        for e in self.impulse:
            for i in range(len(self.impulse[e])): self.impulse[e][i]*=0.92
        self.update()

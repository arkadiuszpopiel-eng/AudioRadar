import csv, os, time
class EventLogger:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)
        self.path = os.path.join(self.base_dir, "detections.csv")
        if not os.path.exists(self.path):
            with open(self.path, "w", newline='', encoding="utf-8") as f:
                w = csv.writer(f); w.writerow(["ts","label","angle_deg","level_db","prob"])
    def log(self, dets):
        try:
            with open(self.path, "a", newline='', encoding="utf-8") as f:
                w = csv.writer(f)
                for d in dets or []:
                    ts = d.get("ts", time.time()); lab = d.get("label","-"); ang = d.get("angle_deg",0.0)
                    lvl = d.get("level_db",-90.0); proba = 0.0
                    p = d.get("proba",{}); labx = d.get("label")
                    if labx and isinstance(p, dict): proba = float(p.get(labx, 0.0))
                    w.writerow([f"{ts:.3f}", lab, f"{ang:.1f}", f"{lvl:.1f}", f"{proba:.2f}"])
        except Exception:
            pass

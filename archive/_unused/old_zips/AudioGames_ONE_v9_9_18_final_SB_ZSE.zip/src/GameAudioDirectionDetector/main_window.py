from PyQt5 import QtCore, QtWidgets, QtGui
from .hud import EdgeRingWidget
from .ledbars import EdgeLedBars
from .audio_engine import AudioEngine, list_input_devices, CaptureMode, find_preferred_device
from .tracker import DemoTracker
from .settings import load_settings, save_settings
from .replay import ReplayBuffer
from .footstep_engine import FootstepEngine
from .logger import EventLogger
import os

PRESETS = {
    "SB Z SE": {"sens":72, "tgain":1.25, "offset":0.0},
    "Indoor":  {"sens":72, "tgain":1.20, "offset":0.0},
    "Outdoor": {"sens":68, "tgain":1.10, "offset":0.0},
    "Metal":   {"sens":65, "tgain":1.35, "offset":0.0},
}

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self._settings_path = settings_path
        self.cfg = load_settings(settings_path)

        self.setWindowTitle("AudioGames ONE v9.9.18 — Sound Blaster Z SE Final")
        self.resize(1280, 900)
        self.tabs = QtWidgets.QTabWidget(); self.setCentralWidget(self.tabs)

        # Radar
        t_edge = QtWidgets.QWidget(); v_edge = QtWidgets.QVBoxLayout(t_edge)
        self.edge = EdgeRingWidget(); v_edge.addWidget(self.edge)
        self.tabs.addTab(t_edge, "Edge 360°")

        # LED bars
        t_led = QtWidgets.QWidget(); v_led = QtWidgets.QVBoxLayout(t_led)
        self.bars = EdgeLedBars(decay=float(self.cfg.get('bars_decay',0.85)), gain=float(self.cfg.get('bars_gain',1.0)))
        v_led.addWidget(self.bars)
        form_led = QtWidgets.QFormLayout()
        self.sld_decay = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_decay.setRange(70,98); self.sld_decay.setValue(int(100*float(self.cfg.get('bars_decay',0.85))))
        self.sld_gain  = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_gain.setRange(50,200); self.sld_gain.setValue(int(100*float(self.cfg.get('bars_gain',1.0))))
        form_led.addRow("Decay", self.sld_decay); form_led.addRow("Gain", self.sld_gain); v_led.addLayout(form_led)
        self.tabs.addTab(t_led, "Edge LED Bars")

        # Footstep Detector
        t_foot = QtWidgets.QWidget(); f = QtWidgets.QFormLayout(t_foot)
        self.cmb_preset = QtWidgets.QComboBox(); self.cmb_preset.addItems(list(PRESETS.keys()))
        self.btn_preset = QtWidgets.QPushButton("Apply preset")
        self.sld_sens = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_sens.setRange(0,100); self.sld_sens.setValue(int(self.cfg.get('foot_sensitivity',72)))
        self.sld_gain_tr = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_gain_tr.setRange(50,200); self.sld_gain_tr.setValue(int(100*float(self.cfg.get('foot_transient_gain',1.25))))
        self.spn_offset = QtWidgets.QDoubleSpinBox(); self.spn_offset.setRange(-180.0,180.0); self.spn_offset.setDecimals(1); self.spn_offset.setSingleStep(1.0); self.spn_offset.setValue(float(self.cfg.get('angle_offset',0.0)))
        self.chk_imp = QtWidgets.QCheckBox("Show impulses in HUD"); self.chk_imp.setChecked(bool(self.cfg.get('foot_show_impulses', True)))
        f.addRow("Preset", self.cmb_preset); f.addRow(self.btn_preset)
        f.addRow("Sensitivity", self.sld_sens); f.addRow("Transient gain", self.sld_gain_tr)
        f.addRow("Angle offset (°)", self.spn_offset); f.addRow(self.chk_imp)
        self.tabs.addTab(t_foot, "Footstep Detector")

        # Audio In
        tin = QtWidgets.QWidget(); lin = QtWidgets.QFormLayout(tin)
        self.cmb_mode = QtWidgets.QComboBox(); self.cmb_mode.addItems(["System (WASAPI loopback)","Microphone"])
        self.cmb_mode.setCurrentIndex(0)  # prefer loopback
        self.cmb_dev_in = QtWidgets.QComboBox()
        self.lbl_hint = QtWidgets.QLabel("Jeśli używasz Sound Blaster Z SE: wybierz urządzenie z listy (Loopback).")
        self.sp_db = QtWidgets.QDoubleSpinBox(); self.sp_db.setRange(-90,0); self.sp_db.setValue(float(self.cfg.get('min_db', -55.0)))
        self.btn_start = QtWidgets.QPushButton("Start Engine"); self.btn_stop = QtWidgets.QPushButton("Stop Engine"); self.btn_stop.setEnabled(False)
        lin.addRow("Capture source", self.cmb_mode); lin.addRow("Input device", self.cmb_dev_in); lin.addRow(self.lbl_hint); lin.addRow("Min dB", self.sp_db); lin.addRow(self.btn_start); lin.addRow(self.btn_stop)
        self.tabs.addTab(tin, "Audio In")

        # Diagnostics
        tdiag = QtWidgets.QWidget(); vdiag = QtWidgets.QVBoxLayout(tdiag)
        self.tbl = QtWidgets.QTableWidget(0,6); self.tbl.setHorizontalHeaderLabels(["ID","Angle","Level dB","Class","Prob.","Src"])
        vdiag.addWidget(self.tbl)
        self.tabs.addTab(tdiag, "Diagnostics")

        # Engines + logger
        self.engine = AudioEngine(low_latency=bool(self.cfg.get('low_latency', False)),
                                  samplerate=int(self.cfg.get('samplerate',48000)),
                                  blocksize=int(self.cfg.get('blocksize',1024)))
        self.engine.detection_listeners.append(self.on_detections)
        self.engine.on_frame(self.on_frame)
        self.foot = FootstepEngine(sensitivity=int(self.cfg.get('foot_sensitivity',72)),
                                   transient_gain=float(self.cfg.get('foot_transient_gain',1.25)),
                                   angle_offset=float(self.cfg.get('angle_offset',0.0)))
        self.foot.on_detect(self.on_detections)
        self.replay = ReplayBuffer(seconds=10.0)
        self.tracker = DemoTracker()
        logs_dir = os.path.join(os.path.dirname(__file__), "..", "logs")
        self.logger = EventLogger(logs_dir)

        # Status label for SB profile
        self.status = QtWidgets.QLabel("Profil: default")
        self.status.setStyleSheet("color: #7aa2ff;")
        self.statusBar().addPermanentWidget(self.status)

        # Signals
        self.cmb_mode.currentIndexChanged.connect(self._on_mode_changed)
        self.cmb_dev_in.currentIndexChanged.connect(self._on_device_changed)
        self.btn_start.clicked.connect(self.on_btn_start); self.btn_stop.clicked.connect(self.on_btn_stop)
        self.sld_decay.valueChanged.connect(lambda v:self.bars.set_params(decay=v/100.0))
        self.sld_gain.valueChanged.connect(lambda v:self.bars.set_params(gain=v/100.0))
        self.sld_sens.valueChanged.connect(lambda v:self.foot.set_params(sensitivity=v))
        self.sld_gain_tr.valueChanged.connect(lambda v:self.foot.set_params(transient_gain=v/100.0))
        self.spn_offset.valueChanged.connect(lambda v:self.foot.set_params(angle_offset=v))
        self.chk_imp.toggled.connect(self._on_imp_toggled)
        self.btn_preset.clicked.connect(self._on_apply_preset)

        # Devices
        self._refresh_devices(loopback=True, prefer=self.cfg.get('device_preference'))

    def _on_apply_preset(self):
        p = PRESETS.get(self.cmb_preset.currentText())
        if not p: return
        self.sld_sens.setValue(int(p['sens'])); self.sld_gain_tr.setValue(int(100*p['tgain'])); self.spn_offset.setValue(float(p['offset']))

    def _on_imp_toggled(self, on): self.edge.show_impulses=bool(on)

    def on_frame(self, frame):
        try: self.foot.process_frame(frame)
        except Exception: pass

    def on_detections(self, dets):
        self.replay.push(dets)
        self.logger.log(dets)
        if any(d.get('label')=='footstep' for d in dets):
            if self.edge.show_impulses: self.edge.flash_impulse()
        self.edge.update_sectors(dets); self.bars.update_from_detections(dets)
        tracks=self.tracker.update_batch(dets); self.tbl.setRowCount(len(tracks))
        for i,t in enumerate(tracks):
            p=0.0
            if t.cls and t.cls_p: p=100.0*float(t.cls_p.get(t.cls,0.0))
            vals=[str(t.id), f"{t.angle_deg:.0f}°", f"{t.level_db:.1f}", str(t.cls or '-'), f"{p:.0f}%", t.cls or '-']
            for j,val in enumerate(vals):
                it=QtWidgets.QTableWidgetItem(val); it.setFlags(it.flags() ^ QtCore.Qt.ItemIsEditable); self.tbl.setItem(i,j,it)

    def _refresh_devices(self, loopback=True, prefer=None):
        self.cmb_dev_in.blockSignals(True); self.cmb_dev_in.clear()
        devs=list_input_devices(loopback_only=loopback); self._dev_map=[]
        for idx,label,_ch in devs:
            self.cmb_dev_in.addItem(label); self._dev_map.append(idx)
        self.cmb_dev_in.blockSignals(False)
        preferred_idx = find_preferred_device(prefer or "Sound Blaster Z SE", loopback=True)
        if preferred_idx is not None and preferred_idx in self._dev_map:
            picked = self._dev_map.index(preferred_idx)
            self.cmb_dev_in.setCurrentIndex(picked)
            self.engine.set_input(device_index=preferred_idx, mode=CaptureMode.SYSTEM_LOOPBACK)
            self.status.setText("Profil: Sound Blaster Z SE Active")
            self.status.setStyleSheet("color: #00ffaa;")
        elif self._dev_map:
            self.engine.set_input(device_index=self._dev_map[0], mode=CaptureMode.SYSTEM_LOOPBACK)
            self.status.setText("Profil: default")
            self.status.setStyleSheet("color: #7aa2ff;")

    def _on_mode_changed(self, i):
        loop=(i==0)
        self.engine.set_input(mode=CaptureMode.SYSTEM_LOOPBACK if loop else CaptureMode.MICROPHONE)
        self._refresh_devices(loopback=loop, prefer=self.cfg.get('device_preference'))
        self.cfg['input_mode']='loopback' if loop else 'mic'

    def _on_device_changed(self, i):
        if hasattr(self,'_dev_map') and 0<=i<len(self._dev_map):
            self.engine.set_input(device_index=self._dev_map[i])
            self.cfg['device_index']=self._dev_map[i]
            label = self.cmb_dev_in.currentText().lower()
            if 'sound blaster' in label and 'z' in label:
                self.status.setText("Profil: Sound Blaster Z SE Active")
                self.status.setStyleSheet("color: #00ffaa;")
            else:
                self.status.setText("Profil: default")
                self.status.setStyleSheet("color: #7aa2ff;")

    def on_btn_start(self):
        try:
            self.engine.min_db=float(self.sp_db.value())
            loop=(self.cmb_mode.currentIndex()==0)
            dev=self._dev_map[self.cmb_dev_in.currentIndex()] if getattr(self,'_dev_map',None) else None
            self.engine.set_input(mode=(CaptureMode.SYSTEM_LOOPBACK if loop else CaptureMode.MICROPHONE), device_index=dev)
            ok=self.engine.start()
            if ok: self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
        except Exception: pass

    def on_btn_stop(self):
        try:
            self.engine.stop(); self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)
        except Exception: pass

    def closeEvent(self, e):
        try:
            self.cfg['input_mode']='loopback' if self.cmb_mode.currentIndex()==0 else 'mic'
            self.cfg['device_index']=self._dev_map[self.cmb_dev_in.currentIndex()] if getattr(self,'_dev_map',None) else None
            self.cfg['min_db']=float(self.sp_db.value())
            self.cfg['bars_decay']=self.sld_decay.value()/100.0; self.cfg['bars_gain']=self.sld_gain.value()/100.0
            self.cfg['foot_sensitivity']=int(self.sld_sens.value()); self.cfg['foot_transient_gain']=self.sld_gain_tr.value()/100.0
            self.cfg['foot_show_impulses']=bool(self.chk_imp.isChecked()); self.cfg['angle_offset']=float(self.spn_offset.value())
            save_settings(self._settings_path, self.cfg)
        except Exception: pass
        super().closeEvent(e)

import time, collections
class ReplayBuffer:
    def __init__(self, seconds=10.0):
        self.seconds=float(seconds); self.buf=collections.deque()
    def push(self, dets):
        ts=time.time(); self.buf.append((ts, [d.copy() for d in dets])); self._trim(ts)
    def _trim(self, now=None):
        if now is None: now=time.time()
        horizon=now-self.seconds
        while self.buf and self.buf[0][0]<horizon: self.buf.popleft()
    def snapshot(self):
        if not self.buf: return []
        base=self.buf[0][0]; out=[]
        for ts,dets in list(self.buf):
            for d in dets:
                x=d.copy(); x['replay_dt']=ts-base; out.append(x)
        return out

from dataclasses import dataclass, field
from typing import List, Dict, Optional
@dataclass
class TrackedSource:
    id: int
    angle_deg: float
    level_db: float
    cls: Optional[str] = None
    cls_p: Dict[str, float] = field(default_factory=dict)
    history: List[float] = field(default_factory=list)
class DemoTracker:
    def __init__(self):
        self.tracks: List[TrackedSource] = []; self._next_id=1
    def update_batch(self, dets: List[dict]):
        for d in dets or []:
            a=float(d.get("angle_deg", 0.0)); l=float(d.get("level_db",-30.0))
            label=d.get("label"); proba=d.get("proba",{})
            if self.tracks:
                t=self.tracks[0]; t.angle_deg=0.7*t.angle_deg+0.3*a; t.level_db=0.7*t.level_db+0.3*l; t.cls=label; t.cls_p=proba; t.history=(t.history+[t.angle_deg])[-60:]
            else:
                self.tracks.append(TrackedSource(self._next_id,a,l,label,proba,[a])); self._next_id+=1
        return self.tracks

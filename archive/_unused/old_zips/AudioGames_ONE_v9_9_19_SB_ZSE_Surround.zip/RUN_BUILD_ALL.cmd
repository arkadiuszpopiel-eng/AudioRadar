@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
title AudioGames ONE - Build All (v9.9.19 SB Z SE Surround)
set "LOG=build_log.txt"
> "%LOG%" echo === Python / VENV ===
if not exist .venv ( py -3 -m venv .venv >> "%LOG%" 2>&1 )
call .venv\Scripts\activate.bat
python -V >> "%LOG%" 2>&1
echo === Pip upgrade === >> "%LOG%"
python -m pip install -U pip wheel setuptools >> "%LOG%" 2>&1
echo === Install requirements === >> "%LOG%"
python -m pip install -r requirements.txt >> "%LOG%" 2>&1
echo === Clean build folders === >> "%LOG%"
rmdir /s /q build  >nul 2>&1
rmdir /s /q dist   >nul 2>&1
if not exist portable mkdir portable
if not exist portable\logs mkdir portable\logs
echo === PyInstaller === >> "%LOG%"
pyinstaller --noconfirm --clean --name AudioGames_ONE src\GameAudioDirectionDetector\__main__.py >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
set "EXE1=dist\AudioGames_ONE\AudioGames_ONE.exe"
set "EXE2=dist\AudioGames_ONE.exe"
if exist "%EXE1%" ( copy /y "%EXE1%" portable\ >> "%LOG%" 2>&1 ) else if exist "%EXE2%" ( copy /y "%EXE2%" portable\ >> "%LOG%" 2>&1 ) else (
  echo [ERR] EXE not found >> "%LOG%"
  goto :fail
)
copy /y START_HERE.bat portable\ >> "%LOG%" 2>&1
echo [INFO] EXE found at dist\AudioGames_ONE.exe >> "%LOG%"
echo Portable build ready in .\portable
pause
exit /b 0
:fail
echo Build failed. See build_log.txt
pause
exit /b 1

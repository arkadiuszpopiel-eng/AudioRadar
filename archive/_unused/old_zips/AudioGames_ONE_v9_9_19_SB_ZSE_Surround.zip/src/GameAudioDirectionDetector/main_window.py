from PyQt5 import QtCore, QtGui, QtWidgets
from .hud import EdgeRingWidget
from .ledbars import EdgeLedBars
from .audio_engine import AudioEngine, list_input_devices, CaptureMode, list_output_devices_wasapi, find_preferred_device, get_device_channels
from .tracker import DemoTracker
from .settings import load_settings, save_settings
from .replay import ReplayBuffer
from .footstep_engine import FootstepEngine
from .logger import EventLogger
from .surround import mode_name_from_channels
from .tone import play_click
import os

PROFILES = ["Stereo Competitive","SBX/Scout Friendly"]

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self._settings_path=settings_path; self.cfg=load_settings(settings_path)
        self.setWindowTitle("AudioGames ONE v9.9.19 — SB Z SE Surround Edition")
        self.resize(1200,820)
        self.tabs=QtWidgets.QTabWidget(); self.setCentralWidget(self.tabs)

        # Edge 360 HUD
        t_edge=QtWidgets.QWidget(); v=QtWidgets.QVBoxLayout(t_edge); self.edge=EdgeRingWidget(); v.addWidget(self.edge); self.tabs.addTab(t_edge,"Edge 360°")

        # LED bars
        t_led=QtWidgets.QWidget(); vl=QtWidgets.QVBoxLayout(t_led); self.bars=EdgeLedBars(decay=self.cfg.get('bars_decay',0.85), gain=self.cfg.get('bars_gain',1.0)); vl.addWidget(self.bars)
        form=QtWidgets.QFormLayout(); self.sld_decay=QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_decay.setRange(70,98); self.sld_decay.setValue(int(100*self.cfg.get('bars_decay',0.85)))
        self.sld_gain=QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_gain.setRange(50,200); self.sld_gain.setValue(int(100*self.cfg.get('bars_gain',1.0)))
        form.addRow("Decay", self.sld_decay); form.addRow("Gain", self.sld_gain); vl.addLayout(form); self.tabs.addTab(t_led,"Edge LED Bars")

        # Footstep Detector
        t_foot=QtWidgets.QWidget(); f=QtWidgets.QFormLayout(t_foot)
        self.sld_sens=QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_sens.setRange(0,100); self.sld_sens.setValue(int(self.cfg.get('foot_sensitivity',72)))
        self.sld_gain_tr=QtWidgets.QSlider(QtCore.Qt.Horizontal); self.sld_gain_tr.setRange(50,200); self.sld_gain_tr.setValue(int(100*self.cfg.get('foot_transient_gain',1.25)))
        self.spn_offset=QtWidgets.QDoubleSpinBox(); self.spn_offset.setRange(-180,180); self.spn_offset.setDecimals(1); self.spn_offset.setValue(float(self.cfg.get('angle_offset',0.0)))
        self.chk_imp=QtWidgets.QCheckBox("Show impulses in HUD"); self.chk_imp.setChecked(bool(self.cfg.get('foot_show_impulses',True)))
        f.addRow("Sensitivity", self.sld_sens); f.addRow("Transient gain", self.sld_gain_tr); f.addRow("Angle offset (°)", self.spn_offset); f.addRow(self.chk_imp)
        self.tabs.addTab(t_foot,"Footstep Detector")

        # Audio In / Surround
        tin=QtWidgets.QWidget(); lin=QtWidgets.QFormLayout(tin)
        self.cmb_mode=QtWidgets.QComboBox(); self.cmb_mode.addItems(["System (WASAPI loopback)","Microphone"]); self.cmb_mode.setCurrentIndex(0)
        self.cmb_dev=QtWidgets.QComboBox()
        self.chk_auto=QtWidgets.QCheckBox("Auto channel mode"); self.chk_auto.setChecked(bool(self.cfg.get('auto_channels',True)))
        self.cmb_manual=QtWidgets.QComboBox(); self.cmb_manual.addItems(["stereo","5.1","7.1"]); self.cmb_manual.setCurrentText(self.cfg.get('manual_channels','stereo'))
        self.cmb_profile=QtWidgets.QComboBox(); self.cmb_profile.addItems(PROFILES); self.cmb_profile.setCurrentText(self.cfg.get('profile_audio',PROFILES[1]))
        self.sp_db=QtWidgets.QDoubleSpinBox(); self.sp_db.setRange(-90,0); self.sp_db.setValue(float(self.cfg.get('min_db',-55.0)))
        self.btn_start=QtWidgets.QPushButton("Start Engine"); self.btn_stop=QtWidgets.QPushButton("Stop Engine"); self.btn_stop.setEnabled(False)
        self.lbl_sig=QtWidgets.QLabel("Loopback: — dB"); self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,100); self.progress.setValue(0)
        self.btn_testL=QtWidgets.QPushButton("Test Left"); self.btn_testR=QtWidgets.QPushButton("Test Right")
        lin.addRow("Capture source", self.cmb_mode); lin.addRow("Device", self.cmb_dev)
        lin.addRow("Auto channels", self.chk_auto); lin.addRow("Manual mode", self.cmb_manual); lin.addRow("Audio profile", self.cmb_profile)
        lin.addRow("Min dB", self.sp_db); lin.addRow(self.btn_start); lin.addRow(self.btn_stop)
        lin.addRow(self.lbl_sig); lin.addRow(self.progress); lin.addRow(self.btn_testL, self.btn_testR)
        self.tabs.addTab(tin,"Audio In")

        # Diagnostics
        tdiag=QtWidgets.QWidget(); vdg=QtWidgets.QVBoxLayout(tdiag)
        self.tbl=QtWidgets.QTableWidget(0,6); self.tbl.setHorizontalHeaderLabels(["ID","Angle","Level dB","Class","Prob.","Src"])
        vdg.addWidget(self.tbl); self.tabs.addTab(tdiag,"Diagnostics")

        # Engines + logger
        self.engine=AudioEngine(samplerate=int(self.cfg.get('samplerate',48000)), blocksize=int(self.cfg.get('blocksize',1024)))
        self.engine.detection_listeners.append(self.on_dets); self.engine.on_frame(self.on_frame)
        self.foot=FootstepEngine(sensitivity=int(self.cfg.get('foot_sensitivity',72)), transient_gain=float(self.cfg.get('foot_transient_gain',1.25)), angle_offset=float(self.cfg.get('angle_offset',0.0)))
        self.foot.on_detect(self.on_dets)
        self.replay=ReplayBuffer(10.0); self.tracker=DemoTracker()
        logs_dir=os.path.join(os.path.dirname(__file__), "..", "logs"); self.logger=EventLogger(logs_dir)

        # Status
        self.status=QtWidgets.QLabel("Profil: default"); self.statusBar().addPermanentWidget(self.status)

        # signals
        self.sld_decay.valueChanged.connect(lambda v:self.bars.set_params(decay=v/100.0))
        self.sld_gain.valueChanged.connect(lambda v:self.bars.set_params(gain=v/100.0))
        self.sld_sens.valueChanged.connect(lambda v:self.foot.set_params(sensitivity=v))
        self.sld_gain_tr.valueChanged.connect(lambda v:self.foot.set_params(transient_gain=v/100.0))
        self.spn_offset.valueChanged.connect(lambda v:self.foot.set_params(angle_offset=v))
        self.chk_imp.toggled.connect(lambda on: setattr(self.edge,'show_impulses',bool(on)))
        self.cmb_mode.currentIndexChanged.connect(self._on_mode)
        self.cmb_dev.currentIndexChanged.connect(self._on_dev)
        self.btn_start.clicked.connect(self._start); self.btn_stop.clicked.connect(self._stop)
        self.btn_testL.clicked.connect(lambda: play_click(0)); self.btn_testR.clicked.connect(lambda: play_click(1))
        self.chk_auto.toggled.connect(self._apply_channel_mode); self.cmb_manual.currentIndexChanged.connect(self._apply_channel_mode)

        # timer for signal monitor
        self.progress=self.progress  # ensure attribute exists
        self._vu=QtWidgets.QTimer(self); self._vu.setInterval(120); self._vu.timeout.connect(self._update_vu); self._vu.start()

        self._refresh_devices(loopback=True, prefer=self.cfg.get('device_preference'))

    def _apply_channel_mode(self):
        mode='auto' if self.chk_auto.isChecked() else 'manual'
        manual=self.cmb_manual.currentText()
        self.engine.configure_channels(mode, manual)

    def _on_mode(self,i):
        loop=(i==0); self.engine.set_input(mode=CaptureMode.SYSTEM_LOOPBACK if loop else CaptureMode.MICROPHONE)
        self._refresh_devices(loopback=loop, prefer=self.cfg.get('device_preference'))
        self.cfg['input_mode']='loopback' if loop else 'mic'

    def _on_dev(self,i):
        if hasattr(self,'_dev_map') and 0<=i<len(self._dev_map):
            self.engine.set_input(device_index=self._dev_map[i])
            label=self.cmb_dev.currentText().lower()
            if 'sound blaster' in label and 'z' in label: self.status.setText("Profil: Sound Blaster Z SE Active")
            else: self.status.setText("Profil: default")

    def _refresh_devices(self, loopback=True, prefer=None):
        self.cmb_dev.blockSignals(True); self.cmb_dev.clear(); self._dev_map=[]
        devs = list_output_devices_wasapi() if loopback else list_input_devices(False)
        for idx,label,_ in devs: self.cmb_dev.addItem(label); self._dev_map.append(idx)
        self.cmb_dev.blockSignals(False)
        if loopback:
            pref=find_preferred_device(prefer or "Sound Blaster Z SE")
            if pref is not None and pref in self._dev_map: self.cmb_dev.setCurrentIndex(self._dev_map.index(pref))

    def _start(self):
        self.engine.min_db=float(self.sp_db.value()); self._apply_channel_mode()
        ok=self.engine.start()
        if ok: self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)

    def _stop(self):
        self.engine.stop(); self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)

    def _update_vu(self):
        lvl=self.engine.last_level_db
        pct=max(0,min(100,int((lvl+60)*100/60))) if lvl>-90 else 0
        self.progress.setValue(pct)
        self.statusBar().showMessage(f"Loopback: {lvl:.1f} dB" if lvl>-90 else "Loopback: — dB", 1000)

    def on_frame(self, frame):
        try: self.foot.process_frame(frame)
        except Exception: pass

    def on_dets(self, dets):
        self.edge.update_sectors(dets); self.bars.update_from_detections(dets)

from PyQt5 import QtWidgets, QtCore
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE - import fix test")
        lab = QtWidgets.QLabel("Build działa. Jeśli to widzisz, import problem rozwiązany.", alignment=QtCore.Qt.AlignCenter)
        self.setCentralWidget(lab)

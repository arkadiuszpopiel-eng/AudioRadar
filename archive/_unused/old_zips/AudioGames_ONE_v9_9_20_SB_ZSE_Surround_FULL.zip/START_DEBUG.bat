@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
set "APP=%~dp0bin\AudioGames_ONE.exe"
set "QT_DEBUG_PLUGINS=1"
"%APP%" --selftest  1>>"%~dp0logs\run_log.txt" 2>&1
echo ==== launching UI ====>>"%~dp0logs\run_log.txt"
"%APP%" 1>>"%~dp0logs\run_log.txt" 2>&1
echo Done. Zobacz logs\run_log.txt
pause

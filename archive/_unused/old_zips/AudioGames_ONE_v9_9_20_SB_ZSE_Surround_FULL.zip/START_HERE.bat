@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
set "APP=%~dp0bin\AudioGames_ONE.exe"
set "QT_DEBUG_PLUGINS=0"
start "" "%APP%"

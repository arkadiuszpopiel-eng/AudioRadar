from PyQt5 import QtWidgets
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, sp):
        super().__init__(); self.setWindowTitle('AudioGames ONE v9.9.20 - minimal UI'); self.setCentralWidget(QtWidgets.QLabel('Pełny build UI - placeholder'))

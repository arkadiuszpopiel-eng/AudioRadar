import sys, os, io, datetime, importlib

def _open_log():
    try:
        base = os.path.abspath(os.path.dirname(__file__))
        logdir = os.path.abspath(os.path.join(base, "..", "logs"))
        os.makedirs(logdir, exist_ok=True)
        fpath = os.path.join(logdir, "run_log.txt")
        f = open(fpath, "a", encoding="utf-8")
        f.write("\n===== START {} =====\n".format(datetime.datetime.now().isoformat()))
        return f
    except Exception:
        return None

_log = _open_log()
class _Tee(io.TextIOBase):
    def __init__(self, real, mirror): self.real=real; self.mirror=mirror
    def write(self, s):
        try:
            if self.real: self.real.write(s)
            if self.mirror: self.mirror.write(s); self.mirror.flush()
        except Exception:
            pass
        return len(s)
sys.stdout = _Tee(sys.stdout, _log)
sys.stderr = _Tee(sys.stderr, _log)

try:
    from GameAudioDirectionDetector.main_window import MainWindow
    print("import absolute OK")
except Exception as e_abs:
    print(f"absolute import failed: {e_abs!r}")
    base = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(base, "main_window.py")
    import importlib.util
    spec = importlib.util.spec_from_file_location("GADD_main_window", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    MainWindow = getattr(mod, "MainWindow")
    print("fallback import OK")

from PyQt5 import QtWidgets

def main():
    app = QtWidgets.QApplication(sys.argv)
    base = os.path.abspath(os.path.dirname(__file__))
    spath = os.path.join(base, "settings.json")
    win = MainWindow(spath)
    win.show()
    return app.exec_()

if __name__ == "__main__":
    rc = main()
    if _log: _log.close()

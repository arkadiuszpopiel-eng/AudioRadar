from PyQt5 import QtWidgets, QtCore
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE v9.9.20b — FULL (safe import)")
        lab = QtWidgets.QLabel("Pełny build (safe import). Jeśli okno się wyświetla, problem z relative import zniknął.", alignment=QtCore.Qt.AlignCenter)
        self.setCentralWidget(lab)

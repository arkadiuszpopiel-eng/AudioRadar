from PyQt5 import QtWidgets
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, sp):
        super().__init__(); self.setWindowTitle('AudioGames ONE v9.9.22 - AutoCal'); self.setCentralWidget(QtWidgets.QLabel('AutoCal build – UI pełny w iteracji'))

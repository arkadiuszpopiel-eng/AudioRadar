import threading, queue, time, os
from typing import List, Dict, Callable, Optional, Tuple
try:
    import sounddevice as sd
except Exception:
    sd = None
import numpy as np

class CaptureMode: MICROPHONE='microphone'; SYSTEM_LOOPBACK='system_loopback'

def _hostapi_wasapi_ids():
    try:
        return [i for i,ha in enumerate(sd.query_hostapis()) if 'wasapi' in str(ha.get('name','')).lower()]
    except Exception: return []

def list_output_devices_wasapi() -> List[Tuple[int,str,int]]:
    devs=[]
    try:
        was=_hostapi_wasapi_ids()
        for idx,d in enumerate(sd.query_devices()):
            if int(d.get('hostapi',-1)) in was and int(d.get('max_output_channels',0))>0:
                devs.append((idx, f"{idx}: {d.get('name','')} (OUT {int(d.get('max_output_channels',0))}ch)", int(d.get('max_output_channels',0))))
    except Exception: pass
    return devs

def list_input_devices(loopback_only=False) -> List[Tuple[int,str,int]]:
    if loopback_only: return list_output_devices_wasapi()
    devs=[]
    try:
        for idx,d in enumerate(sd.query_devices()):
            if int(d.get('max_input_channels',0))>0:
                devs.append((idx, f"{idx}: {d.get('name','')} (IN {int(d.get('max_input_channels',0))}ch)", int(d.get('max_input_channels',0))))
    except Exception: pass
    return devs

class AutoCal:
    def __init__(self): self.reset()
    def reset(self): self.min_db=0.0; self.max_db=-90.0; self._seen=0
    def feed(self, level_db: float):
        self.min_db = min(self.min_db, level_db) if self._seen else level_db
        self.max_db = max(self.max_db, level_db) if self._seen else level_db
        self._seen += 1
    def threshold(self) -> float:
        if self._seen<10: return -55.0
        return (self.min_db + 0.7*(self.max_db-self.min_db))

class AudioEngine:
    def __init__(self, samplerate=48000, blocksize=1024):
        self.samplerate=samplerate; self.blocksize=blocksize
        self.stream=None; self.thread=None; self.running=False; self.q=queue.Queue(maxsize=64)
        self.detection_listeners: List[Callable[[List[Dict]], None]] = []
        self.frame_listeners: List[Callable[[np.ndarray], None]] = []
        self.capture_mode=CaptureMode.SYSTEM_LOOPBACK; self.device_index=None
        self.min_db=-55.0; self.last_level_db=-90.0; self.last_error=""
        self.cal=AutoCal(); self.channel_mode='auto'; self.channel_count=2

    def configure_channels(self, mode:str='auto', manual:str='stereo'):
        self.channel_mode=mode
        self.channel_count={'stereo':2,'5.1':6,'7.1':8}.get(manual,2)

    def on_frame(self, cb): self.frame_listeners.append(cb)
    def set_input(self, mode=None, device_index=None):
        if mode is not None: self.capture_mode=mode
        if device_index is not None: self.device_index=device_index

    def start(self):
        if self.running: return True
        if sd is None:
            self.running=True; self.thread=threading.Thread(target=self._demo_worker,daemon=True); self.thread.start(); return True
        try:
            self.running=True; bs=self.blocksize
            if self.capture_mode==CaptureMode.SYSTEM_LOOPBACK:
                dev=self.device_index if self.device_index is not None else sd.default.device[1]
                try: was=sd.WasapiSettings(loopback=True)
                except Exception: was=None
                ch=2
                self.stream=sd.InputStream(device=(None,dev), samplerate=self.samplerate, channels=ch, dtype='float32',
                                            latency='high', extra_settings=was, callback=self._cb, blocksize=bs)
            else:
                kwargs=dict(channels=2, samplerate=self.samplerate, blocksize=bs, callback=self._cb, dtype='float32')
                if self.device_index is not None: kwargs['device']=self.device_index
                self.stream=sd.InputStream(**kwargs)
            self.stream.start(); self.thread=threading.Thread(target=self._worker,daemon=True); self.thread.start(); self.last_error=""; self.cal.reset(); return True
        except Exception as e:
            self.last_error=f"{type(e).__name__}: {e}"; self.running=False
            try:
                os.makedirs('portable/logs',exist_ok=True)
                with open('portable/logs/loopback_error.txt','a',encoding='utf-8') as f: f.write(self.last_error+'\n')
            except Exception: pass
            return False

    def stop(self):
        self.running=False
        try:
            if self.stream: self.stream.stop(); self.stream.close()
        except Exception: pass
        self.stream=None

    def _cb(self, indata, frames, time_info, status):
        try: self.q.put_nowait(indata.copy())
        except queue.Full: pass

    def _worker(self):
        while self.running:
            try: data=self.q.get(timeout=0.5)
            except queue.Empty: continue
            if data.ndim==1: data=np.stack([data,data],axis=1)
            elif data.shape[1]==1: data=np.repeat(data,2,axis=1)
            for cb in list(self.frame_listeners):
                try: cb(data)
                except Exception: pass
            mono=(data[:,0]+data[:,1])*0.5
            rms=float(np.sqrt(np.mean(mono**2)+1e-12)); level_db=20.0*np.log10(rms+1e-12); self.last_level_db=level_db
            self.cal.feed(level_db)
            t=time.time(); angle=(t*30.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':float(level_db),'label':'signal','proba':{'signal':0.6}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass

    def _demo_worker(self):
        import numpy as np, time
        while self.running:
            t=time.time(); angle=(t*30.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':-20.0,'label':'signal','proba':{'signal':0.7}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass
            frame=np.zeros((512,2),dtype='float32')
            for cb in list(self.frame_listeners):
                try: cb(frame)
                except Exception: pass
            time.sleep(0.2)

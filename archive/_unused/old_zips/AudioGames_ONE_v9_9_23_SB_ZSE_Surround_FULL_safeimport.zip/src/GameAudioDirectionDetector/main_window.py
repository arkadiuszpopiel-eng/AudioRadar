from PyQt5 import QtCore, QtWidgets
from .hud import EdgeRingWidget
from .ledbars import EdgeLedBars
from .audio_engine import AudioEngine, list_output_devices_wasapi, CaptureMode
from .settings import load_settings, save_settings
from .footstep_engine import FootstepEngine

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self._settings_path=settings_path; self.cfg=load_settings(settings_path)
        self.setWindowTitle("AudioGames ONE v9.9.23 — SB Z SE Surround (safe)")
        self.resize(1180,820)
        self.tabs=QtWidgets.QTabWidget(); self.setCentralWidget(self.tabs)

        # Edge 360
        t_edge=QtWidgets.QWidget(); v=QtWidgets.QVBoxLayout(t_edge)
        self.edge=EdgeRingWidget(); self.edge.set_ambient(bool(self.cfg.get('ambient_bias',False))); v.addWidget(self.edge)
        self.tabs.addTab(t_edge,"Edge 360°")

        # LED bars
        t_led=QtWidgets.QWidget(); vl=QtWidgets.QVBoxLayout(t_led)
        self.bars=EdgeLedBars(decay=self.cfg.get('bars_decay',0.85), gain=self.cfg.get('bars_gain',1.0)); vl.addWidget(self.bars)
        self.tabs.addTab(t_led,"LED Bars")

        # Audio In
        tin=QtWidgets.QWidget(); lin=QtWidgets.QFormLayout(tin)
        self.cmb_mode=QtWidgets.QComboBox(); self.cmb_mode.addItems(["System (WASAPI loopback)","Microphone"]); self.cmb_mode.setCurrentIndex(0)
        self.cmb_dev=QtWidgets.QComboBox()
        self.chk_ambient=QtWidgets.QCheckBox("Ambient bias"); self.chk_ambient.setChecked(bool(self.cfg.get('ambient_bias',False)))
        self.lbl_autocal=QtWidgets.QLabel("AutoCal: — / — dB (thr —)")
        self.btn_start=QtWidgets.QPushButton("Start Engine"); self.btn_stop=QtWidgets.QPushButton("Stop Engine"); self.btn_stop.setEnabled(False)
        lin.addRow("Capture source", self.cmb_mode); lin.addRow("Device", self.cmb_dev); lin.addRow(self.chk_ambient)
        lin.addRow(self.lbl_autocal); lin.addRow(self.btn_start); lin.addRow(self.btn_stop)
        self.tabs.addTab(tin,"Audio In")

        # Engines
        self.engine=AudioEngine(samplerate=int(self.cfg.get('samplerate',48000)), blocksize=int(self.cfg.get('blocksize',1024)))
        self.engine.detection_listeners.append(self.on_dets)
        self.foot=FootstepEngine(); self.engine.on_frame(self.foot.process_frame); self.foot.on_detect(self.on_dets)

        # status + timers
        self.status=QtWidgets.QLabel("Ready"); self.statusBar().addPermanentWidget(self.status)
        self._vu=QtWidgets.QTimer(self); self._vu.setInterval(150); self._vu.timeout.connect(self._tick); self._vu.start()

        # signals
        self.btn_start.clicked.connect(self._start); self.btn_stop.clicked.connect(self._stop)
        self.cmb_mode.currentIndexChanged.connect(self._mode_changed)
        self.cmb_dev.currentIndexChanged.connect(self._dev_changed)
        self.chk_ambient.toggled.connect(lambda on: (setattr(self.edge,'mode_ambient',bool(on)), self._save_cfg('ambient_bias', bool(on))))

        self._refresh_devices(loopback=True)

    def closeEvent(self, ev):
        try: save_settings(self._settings_path, self.cfg)
        except Exception: pass
        super().closeEvent(ev)

    def _save_cfg(self,k,v): self.cfg[k]=v; save_settings(self._settings_path,self.cfg)

    # UI events
    def _start(self):
        ok=self.engine.start()
        if ok: self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)

    def _stop(self):
        self.engine.stop(); self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)

    def _mode_changed(self, i):
        loop=(i==0); self.engine.set_input(mode=CaptureMode.SYSTEM_LOOPBACK if loop else CaptureMode.MICROPHONE)
        self._refresh_devices(loopback=loop)

    def _dev_changed(self, i):
        if 0<=i<len(self._dev_map): self.engine.set_input(device_index=self._dev_map[i])

    def _refresh_devices(self, loopback=True):
        self.cmb_dev.blockSignals(True); self.cmb_dev.clear(); self._dev_map=[]
        devs = list_output_devices_wasapi() if loopback else []
        for idx,label,_ in devs: self.cmb_dev.addItem(label); self._dev_map.append(idx)
        self.cmb_dev.blockSignals(False)

    # data events
    def on_dets(self, dets):
        self.edge.update_sectors(dets); self.bars.update_from_detections(dets)

    def _tick(self):
        cal=self.engine.cal; lvl=self.engine.last_level_db; thr=cal.threshold()
        self.lbl_autocal.setText(f"AutoCal: min {cal.min_db:.1f} / max {cal.max_db:.1f} dB  (thr {thr:.1f})   | live {lvl:.1f} dB")

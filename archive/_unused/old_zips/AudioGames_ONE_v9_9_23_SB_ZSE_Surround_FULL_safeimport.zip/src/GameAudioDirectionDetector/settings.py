import json, os
DEFAULTS = {
  "device_preference": "Sound Blaster Z SE",
  "samplerate": 48000,
  "blocksize": 1024,
  "bars_decay": 0.85,
  "bars_gain": 1.0,
  "auto_channels": True,
  "manual_channels": "stereo",
  "auto_calibration": True,
  "ambient_bias": False
}
def load_settings(path):
    try:
        with open(path,"r",encoding="utf-8") as f: data=json.load(f)
        out=DEFAULTS.copy(); out.update(data or {}); return out
    except Exception: return DEFAULTS.copy()
def save_settings(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
    except Exception: pass

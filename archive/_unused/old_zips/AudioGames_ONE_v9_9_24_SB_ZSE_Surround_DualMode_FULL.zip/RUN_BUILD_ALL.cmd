@echo off
setlocal
set "LOG=build_log.txt"
if not exist .venv py -3 -m venv .venv >>"%LOG%" 2>&1
call .venv\Scripts\activate.bat
python -m pip install -U pip wheel setuptools >>"%LOG%" 2>&1
python -m pip install -r requirements.txt >>"%LOG%" 2>&1
rmdir /s /q build  >nul 2>&1
rmdir /s /q dist   >nul 2>&1
if not exist portable mkdir portable
if not exist portable\logs mkdir portable\logs
pyinstaller --noconfirm --clean --onedir --windowed --name AudioGames_ONE --paths src src\GameAudioDirectionDetector\__main__.py >>"%LOG%" 2>&1
if errorlevel 1 goto :fail
if exist portable\bin rmdir /s /q portable\bin >nul 2>&1
mkdir portable\bin
xcopy /E /I /Y "dist\AudioGames_ONE" portable\bin\ >>"%LOG%" 2>&1
copy /y START_HERE.bat  portable\ >>"%LOG%" 2>&1
copy /y START_DEBUG.bat portable\ >>"%LOG%" 2>&1
echo [OK] Portable ready >>"%LOG%"
pause
exit /b 0
:fail
echo Build failed. See build_log.txt
pause
exit /b 1

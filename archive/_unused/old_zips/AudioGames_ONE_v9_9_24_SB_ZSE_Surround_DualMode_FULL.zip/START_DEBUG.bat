@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
"%~dp0bin\AudioGames_ONE.exe" 1>>"%~dp0logs\run_log.txt" 2>&1
pause

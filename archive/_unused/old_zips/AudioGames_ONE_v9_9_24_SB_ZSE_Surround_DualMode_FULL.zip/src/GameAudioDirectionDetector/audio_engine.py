import threading, queue, time, os
try:
    import sounddevice as sd
except Exception:
    sd = None
import numpy as np

class RunMode: REAL='real'; DEMO='demo'

def list_output_devices_wasapi():
    devs=[]
    try:
        was=[i for i,ha in enumerate(sd.query_hostapis()) if 'wasapi' in str(ha.get('name','')).lower()]
        for idx,d in enumerate(sd.query_devices()):
            if int(d.get('hostapi',-1)) in was and int(d.get('max_output_channels',0))>0:
                devs.append((idx, f"{idx}: {d.get('name','')} (OUT {int(d.get('max_output_channels',0))}ch)", int(d.get('max_output_channels',0))))
    except Exception: pass
    return devs

class AutoCal:
    def __init__(self): self.reset()
    def reset(self): self.min_db=0.0; self.max_db=-90.0; self._seen=0
    def feed(self, db):
        self.min_db = min(self.min_db, db) if self._seen else db
        self.max_db = max(self.max_db, db) if self._seen else db
        self._seen += 1
    def threshold(self):
        return -55.0 if self._seen<10 else (self.min_db + 0.7*(self.max_db-self.min_db))

class AudioEngine:
    def __init__(self, samplerate=48000, blocksize=1024):
        self.samplerate=samplerate; self.blocksize=blocksize
        self.stream=None; self.thread=None; self.running=False; self.q=queue.Queue(maxsize=64)
        self.detection_listeners=[]; self.frame_listeners=[]
        self.device_index=None; self.last_level_db=-90.0; self.last_error=""; self.cal=AutoCal()
        self.run_mode=RunMode.REAL

    def set_run_mode(self, mode): self.run_mode = mode if mode in (RunMode.REAL, RunMode.DEMO) else RunMode.REAL
    def on_frame(self, cb): self.frame_listeners.append(cb)
    def on_detect(self, cb): self.detection_listeners.append(cb)
    def set_input(self, device_index=None):
        if device_index is not None: self.device_index=device_index

    def start(self):
        if self.running: return True
        if self.run_mode==RunMode.DEMO or sd is None:
            self.running=True; self.thread=threading.Thread(target=self._demo_worker,daemon=True); self.thread.start(); return True

        def _log(msg):
            try:
                os.makedirs('portable/logs', exist_ok=True)
                with open('portable/logs/run_log.txt','a',encoding='utf-8') as f: f.write(msg+'\n')
            except Exception: pass

        def _try_open(desc, **kw):
            try:
                self.stream = sd.InputStream(**kw, callback=self._cb)
                self.stream.start(); self.last_error=""; _log("OPEN OK: "+desc); return True
            except Exception as e:
                self.last_error = f"{desc}: {type(e).__name__}: {e}"; _log("OPEN ERR: "+self.last_error); return False

        try:
            self.running=True; bs=self.blocksize or 0
            dev=self.device_index if self.device_index is not None else (sd.default.device[1] if sd else None)
            if dev is None: self.running=False; return False
            dinfo = sd.query_devices(dev); out_ch = int(dinfo.get('max_output_channels', 2)) or 2
            chs=[2] + ([6] if out_ch>=6 else []) + ([8] if out_ch>=8 else [])
            sr = int(dinfo.get('default_samplerate') or self.samplerate or 48000)
            try: was = sd.WasapiSettings(loopback=True, exclusive=False)
            except Exception: was=None

            opened=False
            for ch in chs:
                if _try_open(f"WASAPI tuple dev={dev} ch={ch} sr={sr} bs={bs}",
                             device=(None,dev), samplerate=sr, channels=ch, dtype='float32',
                             latency='high', extra_settings=was, blocksize=bs): opened=True; break
            if not opened:
                for ch in chs:
                    if _try_open(f"WASAPI flat dev={dev} ch={ch} sr={sr} bs={bs}",
                                 device=dev, samplerate=sr, channels=ch, dtype='float32',
                                 latency='high', extra_settings=was, blocksize=bs): opened=True; break
            if not opened:
                for ch in chs:
                    if _try_open(f"WASAPI noextra dev={dev} ch={ch} sr={sr} bs={bs}",
                                 device=(None,dev), samplerate=sr, channels=ch, dtype='float32',
                                 latency='high', blocksize=bs): opened=True; break
            if not opened:
                for ch in chs:
                    if _try_open(f"WASAPI auto dev={dev} ch={ch}",
                                 device=(None,dev), channels=ch, dtype='float32'): opened=True; break
            if not opened: self.running=False; return False

            self.thread=threading.Thread(target=self._worker,daemon=True); self.thread.start(); self.cal.reset(); return True
        except Exception as e:
            self.last_error=f"start(): {type(e).__name__}: {e}"; self.running=False; return False

    def stop(self):
        self.running=False
        try:
            if self.stream: self.stream.stop(); self.stream.close()
        except Exception: pass
        self.stream=None

    def _cb(self, indata, frames, time_info, status):
        try: self.q.put_nowait(indata.copy())
        except queue.Full: pass

    def _worker(self):
        while self.running:
            try: data=self.q.get(timeout=0.5)
            except queue.Empty: continue
            if data.ndim==1: data=np.stack([data,data],axis=1)
            elif data.shape[1]==1: data=np.repeat(data,2,axis=1)
            mono=(data[:,0]+data[:,1])*0.5
            rms=float(np.sqrt(np.mean(mono**2)+1e-12)); self.last_level_db=20.0*np.log10(rms+1e-12)
            self.cal.feed(self.last_level_db)
            t=time.time(); angle=(t*30.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':float(self.last_level_db),'label':'signal','proba':{'signal':0.6}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass
            for cb in list(self.frame_listeners):
                try: cb(data)
                except Exception: pass

    def _demo_worker(self):
        import numpy as np, time
        while self.running:
            t=time.time(); angle=(t*36.0)%360.0
            det={'ts':t,'angle_deg':angle,'level_db':-18.0,'label':'demo','proba':{'demo':1.0}}
            for cb in list(self.detection_listeners or []):
                try: cb([det])
                except Exception: pass
            frame=np.zeros((512,2),dtype='float32')
            for cb in list(self.frame_listeners):
                try: cb(frame)
                except Exception: pass
            time.sleep(0.05)

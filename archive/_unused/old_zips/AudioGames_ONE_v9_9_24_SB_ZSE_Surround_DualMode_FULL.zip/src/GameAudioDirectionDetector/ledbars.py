from PyQt5 import QtCore, QtGui, QtWidgets
import math
def energy_from_db(db): return max(0.0,min(1.0,(db+60.0)/60.0))
def color_e(e):
    hue=int((1.0-max(0.0,min(1.0,e)))*60); c=QtGui.QColor.fromHsv(hue,255,int(180+75*e)); c.setAlpha(int(140+100*e)); return c
class EdgeLedBars(QtWidgets.QWidget):
    def __init__(self,parent=None,decay=0.85,gain=1.0):
        super().__init__(parent); self.decay=float(decay); self.gain=float(gain); self.setMinimumHeight(160)
        self.num={'top':3,'bottom':3,'left':2,'right':2}
        self.energy={k:[0.0]*n for k,n in self.num.items()}; self.imp={k:[0.0]*n for k,n in self.num.items()}
        self._t=QtCore.QTimer(self); self._t.setInterval(16); self._t.timeout.connect(self._anim); self._t.start()
    def _map(self,a):
        a=a%360.0; rad=math.radians(a); x,y=math.cos(rad),math.sin(rad)
        if abs(y)>=abs(x): edge='top' if y>=0 else 'bottom'; t=(x+1)/2; bins=self.num[edge]; idx=min(bins-1,max(0,int(t*bins)))
        else: edge='right' if x>=0 else 'left'; t=(y+1)/2; bins=self.num[edge]; idx=min(bins-1,max(0,int(t*bins)))
        return edge,idx
    def update_from_detections(self,dets):
        for e in self.energy:
            for i in range(len(self.energy[e])): self.energy[e][i]*=self.decay; self.imp[e][i]*=0.9
        for d in dets or []:
            ang=float(d.get('angle_deg',0.0)); lvl=float(d.get('level_db',-40.0)); e=min(1.0,energy_from_db(lvl)*self.gain)
            ed,ix=self._map(ang); self.energy[ed][ix]=max(self.energy[ed][ix],e); self.imp[ed][ix]=max(self.imp[ed][ix],e)
        self.update()
    def paintEvent(self,ev):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing,True); w,h=self.width(),self.height()
        p.fillRect(self.rect(),QtGui.QColor(22,23,33)); m=18; s=10; th=14
        segw=(w-2*m-2*s)/3.0; top=[QtCore.QRectF(m+i*(segw+s),m,segw,th) for i in range(3)]; bot=[QtCore.QRectF(m+i*(segw+s),h-m-th,segw,th) for i in range(3)]
        segh=(h-2*m-s)/2.0; left=[QtCore.QRectF(m,m+i*(segh+s),th,segh) for i in range(2)]; right=[QtCore.QRectF(w-m-th,m+i*(segh+s),th,segh) for i in range(2)]
        def draw(rect,e,imp,h=True):
            rail=QtGui.QColor(40,60,80,120); p.fillRect(rect,rail); col=color_e(e)
            grad=QtGui.QLinearGradient(rect.topLeft(), rect.topRight() if h else rect.bottomLeft())
            grad.setColorAt(0.0,col); grad.setColorAt(1.0,QtGui.QColor.fromHsv(0,255,180)); p.fillRect(rect,grad)
            if imp>0.02: pen=QtGui.QPen(color_e(imp)); pen.setWidth(3); p.setPen(pen); p.drawRect(rect)
        for i,r in enumerate(top): draw(r,self.energy['top'][i],self.imp['top'][i],True)
        for i,r in enumerate(bot): draw(r,self.energy['bottom'][i],self.imp['bottom'][i],True)
        for i,r in enumerate(left): draw(r,self.energy['left'][i],self.imp['left'][i],False)
        for i,r in enumerate(right): draw(r,self.energy['right'][i],self.imp['right'][i],False)
        p.end()
    def _anim(self):
        for e in self.imp:
            for i in range(len(self.imp[e])): self.imp[e][i]*=0.92
        self.update()

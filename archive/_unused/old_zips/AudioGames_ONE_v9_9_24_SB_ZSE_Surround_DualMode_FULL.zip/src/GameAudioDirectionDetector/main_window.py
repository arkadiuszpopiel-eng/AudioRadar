from PyQt5 import QtCore, QtWidgets
from .hud import EdgeRingWidget
from .ledbars import EdgeLedBars
from .audio_engine import AudioEngine, list_output_devices_wasapi, RunMode

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, settings_path):
        super().__init__()
        self.setWindowTitle("AudioGames ONE v9.9.24 — SB Z SE DualMode (safe)")
        self.resize(1180,820)
        self.tabs=QtWidgets.QTabWidget(); self.setCentralWidget(self.tabs)
        t_edge=QtWidgets.QWidget(); v=QtWidgets.QVBoxLayout(t_edge); self.edge=EdgeRingWidget(); v.addWidget(self.edge); self.tabs.addTab(t_edge,"Edge 360°")
        t_led=QtWidgets.QWidget(); vl=QtWidgets.QVBoxLayout(t_led); self.bars=EdgeLedBars(); vl.addWidget(self.bars); self.tabs.addTab(t_led,"LED Bars")
        tin=QtWidgets.QWidget(); lin=QtWidgets.QFormLayout(tin)
        self.cmb_dev=QtWidgets.QComboBox()
        self.chk_demo=QtWidgets.QCheckBox("Demo / Test mode")
        self.btn_start=QtWidgets.QPushButton("Start Engine"); self.btn_stop=QtWidgets.QPushButton("Stop Engine"); self.btn_stop.setEnabled(False)
        self.lbl_auto=QtWidgets.QLabel("AutoCal: — / — dB (thr —) | live — dB")
        lin.addRow("Device (WASAPI OUT)", self.cmb_dev); lin.addRow(self.chk_demo)
        lin.addRow(self.lbl_auto); lin.addRow(self.btn_start); lin.addRow(self.btn_stop)
        self.tabs.addTab(tin,"Audio In")
        self.status=QtWidgets.QLabel("Ready"); self.statusBar().addPermanentWidget(self.status)
        self.engine=AudioEngine(); self.engine.on_detect(self.on_dets)
        self.btn_start.clicked.connect(self._start); self.btn_stop.clicked.connect(self._stop)
        self.chk_demo.toggled.connect(self._set_demo)
        self._refresh_devices()
        self._vu=QtCore.QTimer(self); self._vu.setInterval(150); self._vu.timeout.connect(self._tick); self._vu.start()

    def _set_demo(self,on): self.status.setText("DEMO ACTIVE" if on else "Ready")
    def _start(self):
        self.engine.set_run_mode(RunMode.DEMO if self.chk_demo.isChecked() else RunMode.REAL)
        ok=self.engine.start()
        if ok:
            self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
            self.status.setText("DEMO ACTIVE" if self.chk_demo.isChecked() else "Engine: running")
        else:
            self.status.setText(f"Engine: ERROR — {self.engine.last_error or 'open failed'}")
    def _stop(self):
        self.engine.stop(); self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False); self.status.setText("Stopped")

    def _refresh_devices(self):
        self.cmb_dev.blockSignals(True); self.cmb_dev.clear(); self._dev_map=[]
        for idx,label,_ in list_output_devices_wasapi(): self.cmb_dev.addItem(label); self._dev_map.append(idx)
        self.cmb_dev.blockSignals(False)
        if self._dev_map: self.engine.set_input(device_index=self._dev_map[0])

    def on_dets(self, dets):
        self.edge.update_sectors(dets); self.bars.update_from_detections(dets)

    def _tick(self):
        cal=self.engine.cal; lvl=self.engine.last_level_db; thr=cal.threshold()
        self.lbl_auto.setText(f"AutoCal: min {cal.min_db:.1f} / max {cal.max_db:.1f} dB  (thr {thr:.1f}) | live {lvl:.1f} dB")

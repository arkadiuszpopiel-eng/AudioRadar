from PyQt5 import QtCore, QtGui, QtWidgets
import math

class FloatingBase(QtWidgets.QWidget):
    def __init__(self, opacity=0.9):
        super().__init__(None, QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        # Ensure the widget is transparent and does not capture mouse events.
        #
        # Under PyQt5 there is no ``Qt.TransparentForMouseEvents`` window flag as
        # referenced in the original code. Attempting to set it results in an
        # ``AttributeError`` on startup, as observed in the run logs.  Instead we
        # leverage the widget attribute ``WA_TransparentForMouseEvents`` which
        # instructs Qt to ignore mouse events for the widget, making the overlay
        # truly click‑through.  We also keep the translucent background flag so
        # that the widget can be drawn without an opaque window frame.
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        # ``WA_TransparentForMouseEvents`` is available on all supported Qt
        # versions.  See: https://doc.qt.io/qt-5/qt.html#WidgetAttribute-enum
        # We keep this attribute on the base widget so that it does not
        # intercept mouse clicks during gameplay.  A small drag handle is
        # created as a child and is exempt from this attribute so that it can
        # receive mouse events to implement drag‑and‑drop repositioning.
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)
        self._opacity = opacity; self._fade=1.0
        self.resize(300, 300)

        # Store a colour profile name for HUD rendering.  Subclasses can
        # adjust their colour palettes based on this value.  Supported
        # profiles are 'cinematic' (default) and 'ambient'.
        self.profile = 'cinematic'

        # --- Drag and drop support ---
        # When the user drags the handle, the widget can be repositioned on the
        # screen.  A callback may be assigned to ``drag_finished_callback`` to
        # notify external code (e.g. the main window) that the widget moved so
        # that UI controls can be synchronised.
        self._drag_active = False
        self._drag_offset = QtCore.QPoint()
        self.drag_finished_callback = None
        # Create a small handle in the top‑left corner.  This handle is not
        # transparent for mouse events and captures drag motions.  It is
        # semi‑transparent to remain unobtrusive.  When hovered, the cursor
        # changes to indicate draggable state.
        self._dragHandle = QtWidgets.QLabel(self)
        self._dragHandle.setObjectName('dragHandle')
        self._dragHandle.setFixedSize(24, 24)
        self._dragHandle.move(0, 0)
        # Use a subtle colour and slight border radius
        self._dragHandle.setStyleSheet('background-color: rgba(120, 120, 120, 90); border-radius: 4px;')
        self._dragHandle.setCursor(QtGui.QCursor(QtCore.Qt.SizeAllCursor))
        # Ensure the handle accepts mouse events even though the parent is transparent
        self._dragHandle.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        # Install event handlers on the handle
        self._dragHandle.mousePressEvent = self._handle_mouse_press
        self._dragHandle.mouseMoveEvent = self._handle_mouse_move
        self._dragHandle.mouseReleaseEvent = self._handle_mouse_release

        # --- Resizing support ---
        # Add a small handle in the bottom‑right corner that allows the user to
        # resize the floating widget.  The handle uses a diagonal resize
        # cursor.  Like the drag handle, it is semi‑transparent and accepts
        # mouse events while the rest of the widget remains click‑through.
        self._resize_active = False
        self._resize_start_pos = None  # type: QtCore.QPoint | None
        self._resize_start_size = None  # type: tuple[int, int] | None
        self.resize_finished_callback = None
        self._resizeHandle = QtWidgets.QLabel(self)
        self._resizeHandle.setObjectName('resizeHandle')
        self._resizeHandle.setFixedSize(24, 24)
        # Position will be updated in resizeEvent
        self._resizeHandle.setStyleSheet(
            'background-color: rgba(120, 120, 120, 90); border-radius: 4px;'
        )
        # Use the diagonal resize cursor appropriate for bottom‑right corner
        self._resizeHandle.setCursor(QtGui.QCursor(QtCore.Qt.SizeFDiagCursor))
        self._resizeHandle.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        # Attach event handlers for resize
        self._resizeHandle.mousePressEvent = self._resize_mouse_press
        self._resizeHandle.mouseMoveEvent = self._resize_mouse_move
        self._resizeHandle.mouseReleaseEvent = self._resize_mouse_release

    # ------------------------------------------------------------------
    # Public API
    def set_profile(self, name: str) -> None:
        """
        Set the HUD colour profile.  Accepts 'cinematic' or 'ambient'.
        Unrecognised names default to 'cinematic'.  The widget is
        repainted immediately.
        """
        name = str(name).strip().lower()
        if name not in ('cinematic', 'ambient'):
            name = 'cinematic'
        self.profile = name
        self.update()

    def set_opacity(self, v: float):
        self._opacity = max(0.0, min(1.0, float(v)))
        self.update()

    def _handle_mouse_press(self, event):
        """
        Start dragging the widget when the handle is pressed with the left
        mouse button.  The offset between the global cursor position and the
        widget position is stored to compute the new location during
        dragging.
        """
        if event.button() == QtCore.Qt.LeftButton:
            self._drag_active = True
            # Compute offset relative to current widget position
            self._drag_offset = event.globalPos() - self.pos()
            event.accept()
        else:
            event.ignore()

    def _handle_mouse_move(self, event):
        """
        Move the widget according to the global cursor position while the
        mouse is being held down on the handle.  The widget follows the
        pointer while maintaining the initial offset.
        """
        if self._drag_active:
            new_pos = event.globalPos() - self._drag_offset
            # Clamp positions to non‑negative values to avoid moving off
            # screen entirely.  Negative values are allowed but might
            # disappear behind screen edges; we choose to clamp at zero.
            x = max(0, new_pos.x())
            y = max(0, new_pos.y())
            self.move(x, y)
            event.accept()
        else:
            event.ignore()

    def _handle_mouse_release(self, event):
        """
        End the drag operation.  If a callback is set, notify that the
        widget has been moved so that external controls (e.g. spin boxes)
        can be updated to reflect the new coordinates.
        """
        if self._drag_active:
            self._drag_active = False
            event.accept()
            if callable(self.drag_finished_callback):
                try:
                    self.drag_finished_callback(self)
                except Exception:
                    pass
        else:
            event.ignore()

    # ------------------------------------------------------------------
    # Resize event handlers
    def _resize_mouse_press(self, event):
        """
        Begin resizing the widget.  The initial size and cursor position are
        stored so that deltas can be calculated during movement.  For a
        square widget (e.g. radar) both width and height will be adjusted
        equally; for a rectangular widget (e.g. LED bars) width and height
        are adjusted independently.
        """
        if event.button() == QtCore.Qt.LeftButton:
            self._resize_active = True
            self._resize_start_pos = event.globalPos()
            self._resize_start_size = (self.width(), self.height())
            event.accept()
        else:
            event.ignore()

    def _resize_mouse_move(self, event):
        """
        Resize the widget as the mouse moves while the left button is held
        down over the resize handle.  The new dimensions are constrained
        to a minimum size to avoid collapsing the widget.
        """
        if self._resize_active and self._resize_start_pos and self._resize_start_size:
            # Compute deltas relative to the starting global position
            dx = event.globalX() - self._resize_start_pos.x()
            dy = event.globalY() - self._resize_start_pos.y()
            start_w, start_h = self._resize_start_size
            # Determine new size.  For radar (square) we keep aspect ratio
            if isinstance(self, PointRadarWidget):
                # Use the larger delta to maintain square shape
                delta = max(dx, dy)
                new_size = max(50, start_w + delta, start_h + delta)
                self.resize(int(new_size), int(new_size))
            else:
                # LED or other rectangular widget
                new_w = max(50, start_w + dx)
                new_h = max(50, start_h + dy)
                self.resize(int(new_w), int(new_h))
            event.accept()
        else:
            event.ignore()

    def _resize_mouse_release(self, event):
        """
        Finish the resize operation.  Invoke the resize finished callback if
        defined so that external UI controls can be updated to reflect the
        new dimensions.  Reset internal state afterwards.
        """
        if self._resize_active:
            self._resize_active = False
            self._resize_start_pos = None
            self._resize_start_size = None
            event.accept()
            if callable(self.resize_finished_callback):
                try:
                    self.resize_finished_callback(self)
                except Exception:
                    pass
        else:
            event.ignore()

    def resizeEvent(self, ev):
        """
        Ensure that auxiliary handles (drag and resize) remain anchored to
        the corners of the widget whenever its size changes.
        """
        try:
            super().resizeEvent(ev)
        except Exception:
            pass
        # Position drag handle at top‑left
        try:
            self._dragHandle.move(0, 0)
        except Exception:
            pass
        # Position resize handle at bottom‑right
        try:
            w = self.width(); h = self.height(); hw = self._resizeHandle.width(); hh = self._resizeHandle.height()
            self._resizeHandle.move(max(0, w - hw), max(0, h - hh))
        except Exception:
            pass

class PointRadarWidget(FloatingBase):
    def __init__(self):
        super().__init__(opacity=0.9)
        self.angle=0.0; self.level=-60.0; self.setMinimumSize(160,160)
    def update_detection(self, angle_deg: float, level_db: float):
        self.angle=float(angle_deg)%360.0; self.level=float(level_db); self.update()
    def paintEvent(self, ev):
        """
        Draw the radar widget.  The ring, spoke and detection colours are
        modulated based on the current HUD profile.  The detection point
        size varies with the detected level (0 dB → largest).
        """
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)
        # Apply opacity and fade factor
        p.setOpacity(self._opacity * self._fade)
        r = self.rect()
        p.fillRect(r, QtCore.Qt.transparent)
        cx, cy = r.center().x(), r.center().y()
        rad = min(r.width(), r.height()) // 2 - 6
        # Select colours based on the HUD profile
        if getattr(self, 'profile', 'cinematic') == 'ambient':
            ring_colour = QtGui.QColor(40, 60, 80, 100)
            spoke_colour = QtGui.QColor(150, 190, 230, 160)
            sat = 150
            val = 250
        else:
            ring_colour = QtGui.QColor(20, 30, 45, 140)
            spoke_colour = QtGui.QColor(120, 160, 220, 200)
            sat = 255
            val = 230
        # Draw outer ring
        pen = QtGui.QPen(ring_colour, 4)
        p.setPen(pen)
        p.setBrush(QtCore.Qt.NoBrush)
        p.drawEllipse(QtCore.QPointF(cx, cy), rad, rad)
        # Draw small spoke at top of ring
        pen.setColor(spoke_colour)
        pen.setWidth(2)
        p.setPen(pen)
        p.drawLine(cx, cy - rad, cx, cy - rad + 16)
        # Calculate energy fraction and map to hue
        e = max(0.0, min(1.0, (self.level + 60.0) / 60.0))
        hue = int((1.0 - e) * 60)
        col = QtGui.QColor.fromHsv(hue, sat, val, 220)
        # Draw detection point
        p.setBrush(col)
        p.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 80), 1))
        ang = math.radians(90.0 - self.angle)
        x = cx + rad * 0.84 * math.cos(ang)
        y = cy - rad * 0.84 * math.sin(ang)
        size = 10 + 16 * e
        p.drawEllipse(QtCore.QPointF(x, y), size, size)
        p.end()

class LedBarsWidget(FloatingBase):
    def __init__(self):
        super().__init__(opacity=0.9)
        # Increase the number of segments for finer directional resolution.
        # Top and bottom now have 5 segments each; left and right have 3 segments.
        self.energy = {
            'top':    [0.0] * 5,
            'bottom': [0.0] * 5,
            'left':   [0.0] * 3,
            'right':  [0.0] * 3
        }
        self.level = -60.0
        # Maintain a sensible minimum size; larger sizes can be set via UI sliders.
        self.setMinimumSize(360, 220)
    def update_energy(self, dets, level_db):
        """
        Update the directional energy bars based on the detected angle.  This
        version supports a variable number of segments per side (top,
        bottom, left, right).  The detected angle is mapped to a side
        (top/bottom/left/right) and then to a segment index based on the
        x or y coordinate of the unit circle.  Energy values decay over
        time to produce a smooth trailing effect.  When a new detection
        occurs the corresponding segment is boosted.
        """
        try:
            self.level = float(level_db)
        except Exception:
            self.level = -60.0
        # Determine angle and unit vector
        try:
            a = float(dets[0].get('angle_deg', 0.0)) if dets else 0.0
        except Exception:
            a = 0.0
        r = math.radians(a)
        x = math.cos(r)
        y = math.sin(r)
        # Determine which side the detection falls into.  Use the larger
        # coordinate (absolute value) to choose between horizontal and
        # vertical sides.  Positive/negative values determine top vs
        # bottom and right vs left.
        if abs(y) >= abs(x):
            ed = 'top' if y >= 0 else 'bottom'
        else:
            ed = 'right' if x >= 0 else 'left'
        # Decay all segments slightly
        try:
            for k in self.energy:
                # Multiply each segment by a decay factor
                self.energy[k] = [v * 0.88 for v in self.energy[k]]
        except Exception:
            pass
        # Determine which segment to boost based on x or y coordinate
        try:
            segs = self.energy.get(ed, [])
            if not segs:
                self.update(); return
            # Map the coordinate to a segment index.  Coordinates are in
            # the range [-1, 1].  For horizontal sides (top/bottom) use x;
            # for vertical sides (left/right) use y.
            if ed in ('top', 'bottom'):
                coord = x
            else:
                coord = y
            # Map coord [-1,1] to [0, len-1]
            n = len(segs)
            idx = int((coord + 1.0) / 2.0 * n)
            if idx < 0:
                idx = 0
            if idx >= n:
                idx = n - 1
            segs[idx] = 0.95
        except Exception:
            pass
        self.update()
    def paintEvent(self, ev):
        """
        Draw the LED bar widget.  The number of segments drawn on each
        side corresponds to the length of the energy lists for that
        side (top/bottom/left/right).  Colours are interpolated based on
        the current HUD profile and energy values.  Segments are evenly
        spaced and separated by a small gap to prevent overlap.
        """
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)
        p.setOpacity(self._opacity * self._fade)
        r = self.rect()
        p.fillRect(r, QtCore.Qt.transparent)
        # Margins, spacing and segment thickness
        m = 14
        s = 10
        th = 12
        w, h = r.width(), r.height()
        # Horizontal segments (top and bottom)
        n_top = len(self.energy.get('top', []))
        n_bot = len(self.energy.get('bottom', []))
        # Ensure at least one segment to avoid division by zero
        n_top = max(1, n_top); n_bot = max(1, n_bot)
        segw_top = (w - 2 * m - (n_top - 1) * s) / float(n_top)
        segw_bot = (w - 2 * m - (n_bot - 1) * s) / float(n_bot)
        top_rects = [
            QtCore.QRectF(m + i * (segw_top + s), m, segw_top, th)
            for i in range(n_top)
        ]
        bot_rects = [
            QtCore.QRectF(m + i * (segw_bot + s), h - m - th, segw_bot, th)
            for i in range(n_bot)
        ]
        # Vertical segments (left and right)
        n_vert = len(self.energy.get('left', []))
        # Use same count for left and right
        n_vert = max(1, n_vert)
        segh_vert = (h - 2 * m - (n_vert - 1) * s) / float(n_vert)
        left_rects = [
            QtCore.QRectF(m, m + i * (segh_vert + s), th, segh_vert)
            for i in range(n_vert)
        ]
        right_rects = [
            QtCore.QRectF(w - m - th, m + i * (segh_vert + s), th, segh_vert)
            for i in range(n_vert)
        ]
        # Determine colour parameters based on profile
        if getattr(self, 'profile', 'cinematic') == 'ambient':
            sat = 150
            val = 240
            base_alpha = 90
            range_alpha = 100
        else:
            sat = 255
            val = 220
            base_alpha = 110
            range_alpha = 120

        def col(e: float) -> QtGui.QColor:
            energy = max(0.0, min(1.0, float(e)))
            hue = int((1.0 - energy) * 60)
            c = QtGui.QColor.fromHsv(hue, sat, val)
            c.setAlpha(int(base_alpha + range_alpha * energy))
            return c

        p.setPen(QtCore.Qt.NoPen)
        # Draw top segments
        for i, rc in enumerate(top_rects):
            try:
                e = self.energy['top'][i] if i < len(self.energy['top']) else 0.0
            except Exception:
                e = 0.0
            p.fillRect(rc, col(e))
        # Draw bottom segments
        for i, rc in enumerate(bot_rects):
            try:
                e = self.energy['bottom'][i] if i < len(self.energy['bottom']) else 0.0
            except Exception:
                e = 0.0
            p.fillRect(rc, col(e))
        # Draw left segments
        for i, rc in enumerate(left_rects):
            try:
                e = self.energy['left'][i] if i < len(self.energy['left']) else 0.0
            except Exception:
                e = 0.0
            p.fillRect(rc, col(e))
        # Draw right segments
        for i, rc in enumerate(right_rects):
            try:
                e = self.energy['right'][i] if i < len(self.energy['right']) else 0.0
            except Exception:
                e = 0.0
            p.fillRect(rc, col(e))
        p.end()

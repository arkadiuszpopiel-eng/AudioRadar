# Audio Radar (Arc Raiders) — Test Package v5.12

## Nowości w v5.12

Wersja 5.12 rozszerza możliwości detektora oraz interfejsu, zachowując wszystkie
poprzednie funkcje.  Oprócz udoskonaleń wizualnych i ergonomicznych
z wersji 5.11 dodano również możliwość wykrywania innych, cichszych dźwięków.

### Wersja 5.12 – wykrywanie innych dźwięków i nowe przełączniki

* **Wykrywanie „innych dźwięków”** – detektor potrafi teraz klasyfikować
  trzy rodzaje zdarzeń: *shot* (bardzo głośne), *step* (umiarkowane) oraz
  *inne* (ciche sygnały, np. drobne efekty gry).  Tę funkcję można włączyć
  parametrem `--other` w wierszu polecenia lub za pomocą przełącznika
  „Inne dźwięki” w panelu sterowania.  Próg wykrywania „innych” zdarzeń jest
  domyślnie ustawiony na połowę głównego progu, ale można go regulować
  parametrem `--other_factor`.
* **Nowy przełącznik w UI** – w dolnym panelu sterowania dodano
  przełącznik *Inne dźwięki*.  Dzięki niemu w trakcie działania programu
  można włączać lub wyłączać klasyfikację cichych zdarzeń bez
  ponownego uruchamiania.
* **Zaktualizowane logowanie** – log startowy uwzględnia teraz stan
  opcji `--other` oraz wartość `--other_factor`.

### Udoskonalenia z wersji 5.11

Wersja 5.11 wprowadziła dodatkowe usprawnienia wizualne i ergonomiczną
obsługę.  Obejmuje ona wszystkie udoskonalenia
z poprzednich wydań (obsługa 24‑bit i kanałów 5.1/7.1, wizualizacja
zdarzeń, konfiguracje JSON, adaptacyjny próg RMS, lista urządzeń itp.),
ale dodaje przede wszystkim:

 - **Spolszczony interfejs** – wszystkie etykiety w panelu sterowania zostały
   przetłumaczone na język polski: *Próg*, *Siła*, *Wygładzenie*, *Auto próg*.
   Dodatkowo przełączniki wskazują stan za pomocą skrótów *WŁ* (włączony)
   i *WYŁ* (wyłączony).
 - **Nowy wygląd radaru** – wizualizacja została całkowicie odświeżona.  Tło
   jest teraz ciemniejsze, a radar składa się z kilku koncentrycznych
   pierścieni i promieni rozmieszczonych co 45°, co ułatwia orientację
   przestrzenną.  Dodano także obracający się promień skanowania,
   imitujący realny radar, oraz zmodernizowano paletę kolorów dla
   zdarzeń (cieplejsze czerwienie dla *shot*, jaśniejsze błękity dla
   *step*).  Dzięki temu interfejs jest bardziej czytelny i przyjemny
   wizualnie.
 - **Interaktywne ustawienia** – dolna część okna zawiera suwaki i
   przełączniki umożliwiające w czasie rzeczywistym regulację progu RMS,
   siły adaptacji i wygładzania, a także włączanie lub wyłączanie
   adaptacyjnego progu (*Auto próg*).  Dzięki temu nie trzeba już
   przekompilowywać programu, aby dobrać czułość – parametry można
   dostroić podczas działania.
 - **Test źródła audio (`--test_source`)** – uruchomienie programu z tą
   flagą powoduje nagranie krótkiej próbki z wybranego urządzenia
   loopback i obliczenie średniego RMS.  Wynik jest wypisywany na
   konsolę oraz do logu, co pozwala szybko sprawdzić, czy przechwytywanie
   dźwięku jest w ogóle poprawnie skonfigurowane.  Po zakończeniu
   testu program kończy działanie, dzięki czemu można go użyć jako
   samodzielnego diagnosty.
 - **Niższy domyślny próg RMS i delikatniejsza adaptacja** – domyślna
   wartość `--threshold` została obniżona do 0,08, a `--dyn_strength` do
   4,0, co zwiększa wrażliwość detektora na słabsze sygnały.  Parametry
   te można nadal modyfikować w wierszu polecenia.
 - **Logowanie RMS i progu (`--debug_rms`)** – w trybie debug można
   włączyć zapisywanie surowej wartości RMS, bieżącego progu adaptacyjnego
   oraz poziomu tła dla każdej ramki.  Dzięki temu łatwiej jest dobrać
   parametry detekcji do własnego środowiska.
 - **Regulacja adaptacji** – parametry `--dyn_strength` i
   `--dyn_smoothing` pozwalają dostroić siłę i płynność adaptacyjnego
   progu RMS.  Niższa wartość siły (np. 3.0) zwiększa czułość, a
   wyższa – zmniejsza liczbę fałszywych zdarzeń.

 - **Przełącznik ramki** – w panelu sterowania znajduje się nowy
   przełącznik *Ramka*, który pozwala włączać lub wyłączać wyświetlanie
   okręgów i promieni radaru.  Dzięki temu można korzystać z radaru
   w minimalistycznej formie bez ramki.


- **Obsługa 24‑bit i wielokanałowych wejść** – przechwytywanie dźwięku
  automatycznie próbuje teraz także format 24‑bit (`paInt24`), jeśli jest on
  obsługiwany przez bibliotekę PyAudioWPatch oraz kartę dźwiękową.  Dzięki temu
  program potrafi poprawnie współpracować z urządzeniami, które zwracają 6 lub
  8 kanałów w trybie 24‑bit (typowe dla Sound Blaster Z SE oraz "What U Hear").
  Dane 24‑bitowe są konwertowane do formatu 16‑bit na potrzeby detektora.
- **Inteligentne mapowanie kanałów stereo** – gdy urządzenie loopback zwraca
  jedynie 2 kanały (stereo), energia jest teraz rozkładana pomiędzy kanały
  7.1 według panoramy i korelacji fazowej, co pozwala na przybliżone
  określenie kierunku dźwięków w konfiguracjach bez natywnych kanałów 5.1/7.1.
- **Automatyczne próby różnych formatów** – w przypadku problemów z otwarciem
  strumienia program testuje różne częstotliwości próbkowania (48 kHz,
  44.1 kHz, 96 kHz) oraz formaty wejściowe (float32, 24‑bit, 16‑bit) aż do
  znalezienia działającej kombinacji.
- **Udoskonalona dokumentacja** – README opisuje, jak korzystać z `--list_devices`,
  `--channels` oraz nowych możliwości 24‑bitowych.  Wskazówki dotyczące wyboru
  urządzenia, liczby kanałów oraz częstotliwości próbkowania zostały
  zaktualizowane.

Wersja 5.7 zawiera również wszystkie usprawnienia wprowadzone w wersji 5.6:

- **Wizualizacja zależna od rodzaju zdarzenia** – na radarze wyświetlane są
  różne kształty: zdarzenia typu *shot* są renderowane jako czerwone okręgi,
  natomiast *step* jako niebieskie kwadraty.  Rozmiar i stopień przezroczystości
  markerów zależy od amplitudy dźwięku i upływu czasu.
- **Pliki konfiguracyjne JSON** – opcje `--config` i `--save_config` pozwalają
  wczytywać i zapisywać ustawienia do pliku JSON (np. rate, channels,
  buffer_ms, threshold, device_index, log, debug, calibrate i headless).
  Parametry podane w wierszu poleceń mają priorytet nad tymi z pliku.
- **Adaptacyjny próg RMS** – przełącznik `--auto_threshold` automatycznie dostosowuje
  próg wykrywania na podstawie aktualnego tła akustycznego.  Wersja 5.8
  pozwala dodatkowo sterować siłą (`--dyn_strength`) i płynnością (`--dyn_smoothing`) adaptacji.
  Niższa wartość parametru siły (np. `3.0`) czyni detektor bardziej wrażliwym na ciche dźwięki,
  a zmiana parametru płynności reguluje szybkość reakcji na zmiany głośności.
- **Lista urządzeń audio** – opcja `--list_devices` wypisuje dostępne
  urządzenia WASAPI loopback wraz z ich parametrami, co ułatwia wybranie
  właściwego indeksu `--device_index`.

Zachowane zostały także udoskonalenia wprowadzone w wersjach 5.5–5.11: większy
domyślny bufor, fallback formatów i rozmiaru bufora przy błędach
`Input overflowed`, ulepszone logi awarii, jeden plik logów (`logs/log.txt`),
tryb `--headless`, auto‑detekcja `rate/channels`, cache ostatnich ustawień oraz
generator pingów `--calibrate`.

## Start
1. Rozpakuj archiwum ZIP.
2. Uruchom `RUN_BUILD_ALL.cmd` z żądanymi opcjami.  Najczęściej używane argumenty to:
   - `--headless` – praca bez okna Pygame, zdarzenia są zapisywane w logu;
   - `--calibrate` – uruchom generator pingów do testu kanałów (stereo/5.1/7.1);
   - `--rate` i `--channels` – wymuszenie częstotliwości próbkowania i liczby kanałów;
   - `--device_index` – wskazanie indeksu urządzenia loopback (int);
   - `--buffer_ms` – długość bufora w ms (domyślnie 50);
   - `--config <plik.json>` – wczytanie konfiguracji z pliku;
   - `--save_config <plik.json>` – zapis aktualnej konfiguracji do pliku;
   - `--auto_threshold` – włączenie adaptacyjnej detekcji progu RMS;
   - `--dyn_strength` i `--dyn_smoothing` – kontrolują odpowiednio siłę i płynność
     adaptacji progu (używane tylko w trybie `--auto_threshold`);
   - `--list_devices` – wyświetlenie listy urządzeń loopback i zakończenie programu.
   - `--test_source` – nagranie krótkiej próbki i obliczenie RMS, przydatne do
     sprawdzenia, czy urządzenie loopback odbiera dźwięk;
   - `--debug_rms` – logowanie każdej wartości RMS i progu w celu kalibracji.
   - `--other` – włącza wykrywanie innych cichych dźwięków (oprócz kroków i strzałów);
   - `--other_factor <liczba>` – określa, o ile niższy od głównego progu jest próg dla
     „innych” zdarzeń (domyślnie 2.0; mniejsza wartość oznacza większą czułość).
3. Podgląd działania i diagnostyka: **`logs/log.txt`**.

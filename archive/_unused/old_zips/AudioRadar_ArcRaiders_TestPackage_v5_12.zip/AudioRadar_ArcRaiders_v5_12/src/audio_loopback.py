import json, numpy as np, threading, logging, time
from typing import Any, Optional, Tuple, List
from pathlib import Path
try:
    import pyaudiowpatch as pyaudio
except Exception:
    pyaudio = None
CACHE_FILE = Path("cache/last_device.json")
def _normalize_index(candidate: Any) -> Optional[int]:
    try:
        if candidate is None: return None
        if isinstance(candidate, int): return int(candidate)
        if isinstance(candidate, float): return int(candidate)
        if isinstance(candidate, str): return int(candidate.strip())
        if isinstance(candidate, (tuple, list)) and candidate: return _normalize_index(candidate[0])
        if isinstance(candidate, dict):
            for k in ("index","device_index","id"):
                if k in candidate: return _normalize_index(candidate[k])
        return int(candidate)
    except Exception: return None
def _load_cache():
    try:
        with open(CACHE_FILE,"r",encoding="utf-8") as f: return json.load(f)
    except Exception: return {}
def _save_cache(data: dict):
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CACHE_FILE,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
    except Exception: pass
class AudioCapturer:
    def __init__(self, rate:int, channels:int, buffer_ms:int, logger:logging.Logger, device_index:int|None=None):
        self.req_rate=rate; self.req_channels=channels; self.buffer_ms=max(10, buffer_ms); self.logger=logger
        self._running=False; self._thread=None; self._pa=None; self._stream=None; self._device_override=device_index
        self.rate=rate; self.channels=channels; self._format="paInt16"
    def _list_devices(self, pa):
        rows=[]; 
        for i in range(pa.get_device_count()):
            info=pa.get_device_info_by_index(i)
            rows.append((i, info.get("name",""), info.get("hostApi"), info.get("maxInputChannels")))
        return rows
    def _find_device(self, pa):
        cache=_load_cache()
        if self._device_override is not None: return _normalize_index(self._device_override)
        last=_normalize_index(cache.get("device_index"))
        if last is not None: return last
        idx=None
        try: idx=_normalize_index(pa.get_default_wasapi_loopback())
        except Exception as e: self.logger.debug("get_default_wasapi_loopback failed: %s", e)
        if idx is not None: return idx
        for i in range(pa.get_device_count()):
            info=pa.get_device_info_by_index(i); name=(info.get("name","") or "").lower()
            if "loopback" in name or "stereo mix" in name or "what u hear" in name: return i
        return None
    def _probe_formats(self, pa, device_index:int)->Tuple[int,int,list]:
        candidates_rate=[]; 
        if self.req_rate not in (None,0): candidates_rate.append(int(self.req_rate))
        for r in (48000,44100,96000,192000):
            if r not in candidates_rate: candidates_rate.append(r)
        chan_candidates=[]; 
        if self.req_channels not in (None,0): chan_candidates.append(int(self.req_channels))
        if 2 not in chan_candidates: chan_candidates.append(2)
        formats=[("paInt16", pyaudio.paInt16), ("paFloat32", pyaudio.paFloat32)]
        # If the underlying PyAudio/PortAudio supports 24‑bit input, include it in the
        # list of candidate formats.  Many soundcards (like the Sound Blaster Z SE)
        # expose a 24‑bit mode when loopback recording is enabled.  We only append
        # ``paInt24`` if it exists on the pyaudio module.  Note that 24‑bit samples
        # require custom unpacking (handled when reading frames in `_run`).
        if hasattr(pyaudio, 'paInt24'):
            formats.append(("paInt24", pyaudio.paInt24))
        diags=[]; chosen_rate=None; chosen_ch=None; chosen_fmt="paInt16"; chosen_fmt_val=pyaudio.paInt16
        for ch in chan_candidates:
            for rate in candidates_rate:
                for fmt_name, fmt_val in formats:
                    ok=False
                    try:
                        ok=pa.is_format_supported(rate, input_device=device_index, input_channels=ch, input_format=fmt_val)
                    except Exception: ok=False
                    diags.append((rate,ch,fmt_name,bool(ok)))
                    if ok and chosen_rate is None:
                        chosen_rate, chosen_ch, chosen_fmt, chosen_fmt_val = rate, ch, fmt_name, fmt_val
            if chosen_rate is not None: break
        if chosen_rate is None:
            chosen_rate=self.req_rate; chosen_ch=self.req_channels; chosen_fmt="paInt16"; chosen_fmt_val=pyaudio.paInt16
        self._format=chosen_fmt
        return chosen_rate, chosen_ch, diags, chosen_fmt_val
    def _attempt_open(self, idx, rate, ch, fmt_val, frames):
        return self._pa.open(format=fmt_val, channels=ch, rate=rate, input=True, frames_per_buffer=frames, input_device_index=idx)
    def start(self, callback):
        if self._running: return
        if pyaudio is None: self.logger.warning("PyAudioWPatch nie jest zainstalowany — brak przechwytywania audio."); return
        self._pa=pyaudio.PyAudio()
        devs=self._list_devices(self._pa); self.logger.info("Lista urzadzen audio: %s", devs)
        idx=self._find_device(self._pa)
        if idx is None: self.logger.error("Nie znaleziono urzadzenia loopback (Stereo Mix/What U Hear)."); return
        try:
            info=self._pa.get_device_info_by_index(idx); self.logger.info("Wybrano device_index=%s name=%s", idx, info.get("name","?"))
        except Exception: self.logger.info("Wybrano device_index=%s (nazwa nieznana)", idx)
        rate,ch,diags,fmt_val=self._probe_formats(self._pa, idx); self.logger.info("Probe results: %s", diags)
        if rate is None or ch is None: self.logger.error("Zaden testowany format nie jest wspierany."); return
        # Domyślnie 50 ms bufor (stabilniej), ale nie mniej niż 10 ms
        frames=max(64, int(rate*max(10, self.buffer_ms)/1000))
        # Próba otwarcia + runtime fallback przy błędzie
        for mult in (1.0, 1.5, 2.0):
            try:
                frames_try = max(64, int(frames*mult))
                self._stream=self._attempt_open(idx, rate, ch, fmt_val, frames_try)
                self.rate=int(rate); self.channels=int(ch)
                self.logger.info("Uzywam rate=%s Hz, channels=%s, frames_per_buffer=%s, format=%s", self.rate, self.channels, frames_try, self._format)
                _save_cache({"device_index": idx, "rate": self.rate, "channels": self.channels, "format": self._format})
                break
            except Exception as e:
                self.logger.warning("Open failed (buf=%s): %s", int(frames*mult), e)
                self._stream=None
        if self._stream is None:
            # Drugi rzut: spróbuj zmienić format (float<->int16) i/lub rate 48000
            # Try a variety of formats when the initial open fails.  We prefer
            # float32, fall back to 24‑bit if available, and finally to 16‑bit.
            alt = []
            try:
                alt.append((pyaudio.paFloat32, "paFloat32"))
            except Exception:
                pass
            # Append 24‑bit format if supported by PyAudio
            if hasattr(pyaudio, 'paInt24'):
                alt.append((pyaudio.paInt24, "paInt24"))
            # Always include 16‑bit as a last resort
            alt.append((pyaudio.paInt16, "paInt16"))
            rates = [rate, 48000, 44100, 96000]
            tried=[]
            for fmt_v, fmt_n in alt:
                for r in rates:
                    for mult in (1.5, 2.0):
                        try:
                            frames_try=max(64, int(r*max(10, self.buffer_ms)/1000*mult))
                            st=self._attempt_open(idx, r, ch, fmt_v, frames_try)
                            self._stream=st; self.rate=int(r); self.channels=int(ch); self._format=fmt_n
                            self.logger.info("Fallback OK: rate=%s ch=%s buf=%s fmt=%s", r, ch, frames_try, fmt_n)
                            _save_cache({"device_index": idx, "rate": self.rate, "channels": self.channels, "format": self._format})
                            break
                        except Exception as e:
                            tried.append((fmt_n, r, mult, str(e)))
                    if self._stream: break
                if self._stream: break
            if self._stream is None:
                self.logger.error("Nie udalo sie otworzyc streamu. Proby: %s", tried)
                try: self._pa.terminate()
                except Exception: pass
                return
        self._running=True
        def _run():
            self.logger.info("Loopback START idx=%s rate=%s ch=%s fmt=%s", idx, self.rate, self.channels, self._format)
            first_reads=0
            while self._running:
                try:
                    data=self._stream.read(self._stream._frames_per_buffer, exception_on_overflow=False)
                    # Convert the raw byte data into an int16 matrix based on the
                    # negotiated sample format.  We convert all supported input
                    # formats to a uniform int16 representation before passing
                    # frames downstream to the DSP.  ``paInt16`` is trivial, but
                    # ``paFloat32`` and ``paInt24`` require scaling and/or
                    # bit‑packing to map into the int16 range.
                    if self._format == 'paInt16':
                        frame = np.frombuffer(data, dtype=np.int16).reshape(-1, self.channels)
                    elif self._format == 'paFloat32':
                        # Input samples are 32‑bit floats in range [-1.0, 1.0]; scale to int16.
                        f32 = np.frombuffer(data, dtype=np.float32)
                        frame = (np.clip(f32, -1.0, 1.0) * 32767.0).astype(np.int16).reshape(-1, self.channels)
                    elif self._format == 'paInt24':
                        # Each sample consists of 3 little‑endian bytes.  First reshape
                        # the flat uint8 buffer into (samples, channels, 3) and then
                        # reconstruct signed 24‑bit integers.  We then downshift
                        # to 16‑bit for compatibility with the DSP pipeline.
                        buf = np.frombuffer(data, dtype=np.uint8)
                        try:
                            samples = buf.reshape(-1, self.channels, 3)
                        except Exception:
                            # Fallback: if reshape fails, skip this frame
                            continue
                        # Combine bytes into 24‑bit integer (little‑endian).  Note: the
                        # bitwise OR operations promote to int32 implicitly.
                        vals = (samples[:, :, 0].astype(np.int32) |
                                (samples[:, :, 1].astype(np.int32) << 8) |
                                (samples[:, :, 2].astype(np.int32) << 16))
                        # Sign‑extend the 24‑bit value to 32‑bit.  If the highest bit
                        # (bit 23) is set, fill the upper bits with ones; otherwise
                        # leave as is.  Equivalent to casting a 24‑bit signed int.
                        vals = np.where(vals & 0x800000, vals | (~0xFFFFFF), vals)
                        # Downshift from 24‑bit to 16‑bit by discarding the least
                        # significant 8 bits.  This preserves the approximate
                        # dynamic range while fitting into int16.
                        int16_vals = (vals >> 8).astype(np.int16)
                        frame = int16_vals
                    else:
                        # Unknown format; attempt to interpret as int16 fallback
                        frame = np.frombuffer(data, dtype=np.int16).reshape(-1, self.channels)
                    callback(frame)
                    first_reads+=1
                except Exception as e:
                    self.logger.warning("read() error: %s", e)
                    time.sleep(0.01)
                    if first_reads < 3:
                        self.logger.info("Wczesny blad odczytu — zwiekszam bufor i probuje ponownie.")
                        try:
                            self._stream.stop_stream(); self._stream.close()
                        except Exception: pass
                        try:
                            frames_new = int(self._stream._frames_per_buffer * 1.5)
                        except Exception:
                            frames_new = int(self.rate * max(10, self.buffer_ms)/1000 * 2.0)
                        try:
                            self._stream=self._attempt_open(idx, self.rate, self.channels,
                                                            pyaudio.paFloat32 if self._format=='paFloat32' else pyaudio.paInt16,
                                                            frames_new)
                            self.logger.info("Restart stream z frames_per_buffer=%s OK.", frames_new)
                            continue
                        except Exception as e2:
                            self.logger.warning("Restart nie powiodl sie: %s", e2)
                            break
            self.logger.info("Loopback STOP")
        import threading; self._thread=threading.Thread(target=_run, daemon=True); self._thread.start()
    def stop(self):
        self._running=False
        try:
            if self._thread: self._thread.join(timeout=1.0)
        except Exception: pass
        try:
            if self._stream: self._stream.stop_stream(); self._stream.close()
        except Exception: pass
        try:
            if self._pa: self._pa.terminate()
        except Exception: pass

import logging, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

def setup_logger(log_path: str, debug: bool=False) -> logging.Logger:
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("audioradar")
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    if logger.handlers:
        return logger
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s")
    try:
        fh = RotatingFileHandler(log_path, maxBytes=2_097_152, backupCount=2, encoding="utf-8")
    except PermissionError:
        ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        alt = Path(log_path).with_name(f"log_fallback-{ts}.txt")
        fh = RotatingFileHandler(str(alt), maxBytes=2_097_152, backupCount=2, encoding="utf-8")
        print(f"[WARN] Nie moge otworzyc {log_path} — uzywam {alt}")
    fh.setFormatter(fmt); fh.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.addHandler(fh)
    sh = logging.StreamHandler(); sh.setFormatter(fmt); sh.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.addHandler(sh)
    logger.info("Logger initialized | log_path=%s | debug=%s", log_path, debug)
    return logger

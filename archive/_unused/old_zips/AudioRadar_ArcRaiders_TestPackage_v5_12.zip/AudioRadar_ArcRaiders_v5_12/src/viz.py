import pygame, math, time, collections
class RadarDisplay:
    """
    Simple radar-like visualization for audio events.  Each marker represents an audio event
    with an associated angle, kind (e.g. ``shot`` or ``step``) and amplitude.  Markers
    fade out over time.  Event kinds are rendered with different shapes to improve
    readability: ``shot`` events use circular blips, whereas ``step`` events use square
    markers.  Additional kinds fall back to circular markers.
    """

    def __init__(self, size=(600, 600), debug: bool = False, *, detector=None, controls: bool = False):
        """Create a new radar display surface.

        Parameters
        ----------
        size : tuple of int
            The size of the window (width, height) in pixels.
        debug : bool
            If True, additional debug information may be logged or drawn.
        detector : EventDetector or None
            Optional reference to the event detector.  When provided and
            ``controls`` is ``True``, GUI sliders and switches will update
            parameters on this detector instance in real time.
        controls : bool, optional
            If True, allocate additional space at the bottom of the window
            for interactive configuration sliders and toggles.  Defaults to
            ``False``.
        """
        # Initialize the pygame environment and create a window
        pygame.init()
        self.debug = debug
        self.detector = detector
        self.controls = bool(controls)
        # Reserve additional vertical space for controls if requested.  We
        # allocate ~100 pixels for up to four controls; this can be
        # adjusted by changing controls_height.  If controls are disabled,
        # controls_height remains zero.
        self.controls_height = 100 if self.controls else 0
        # Compute radar drawing area height
        radar_height = size[1] - self.controls_height
        # Create the display surface with the requested size
        self.screen = pygame.display.set_mode(size)
        self.clock = pygame.time.Clock()
        # Radar radius (40% of the smaller window dimension)
        self.r = int(min(size[0], radar_height) * 0.4)
        # Center the radar within the upper portion of the window
        self.center = (size[0] // 2, radar_height // 2)
        # Visual parameters (colours and speeds)
        self.bg_color = (8, 10, 20)          # dark navy background
        self.grid_color = (50, 70, 100)      # grid/radar lines
        self.sweep_color = (100, 200, 100)   # sweep line colour
        self.sweep_speed = 45.0              # degrees per second
        # Deque to hold active markers; each marker is a dict with fields:
        #   a: angle in degrees
        #   k: kind of event ("shot", "step", etc.)
        #   amp: amplitude scale (0..1)
        #   t: timestamp when marker was added
        #   shape: marker shape ("circle" or "square")
        self.markers = collections.deque()
        # Marker lifetime in seconds
        self.life = 1.2
        # For interactive controls
        self._controls_config = []
        self._drag_index = None
        # Create font for labels if controls are enabled
        if self.controls:
            pygame.font.init()
            self.font = pygame.font.SysFont(None, 16)
            self._init_controls(size, radar_height)
        # State for showing/hiding the radar frame (circles and crosshairs)
        self.frame_enabled = True

    def add_marker(self, angle: float, kind: str, amp: float) -> None:
        """Add a marker representing an audio event.

        Parameters
        ----------
        angle : float
            Angle of the event relative to the listener (degrees).  Values are normalized
            into the [0, 360) range.
        kind : str
            Type of the event.  Supported kinds include ``shot`` and ``step``.  Unknown
            kinds will be rendered as circles.
        amp : float
            Scaled amplitude (0..1) representing the relative loudness of the event.  The
            amplitude influences the size of the marker on the screen.
        """
        # Determine the shape based on the event kind.  Shots use circles, steps use
        # squares.  Unknown kinds fall back to circles.
        if kind == "shot":
            shape = "circle"
        elif kind == "step":
            shape = "square"
        else:
            shape = "circle"
        # Clamp amplitude into [0.02, 1.0] to avoid tiny or excessively large blips
        amp_clamped = max(0.02, min(1.0, amp))
        self.markers.append({
            "a": angle % 360.0,
            "k": kind,
            "amp": amp_clamped,
            "t": time.monotonic(),
            "shape": shape
        })

    def _draw_background(self) -> None:
        """Render the static radar background (concentric rings and crosshair)."""
        # Fill the background
        self.screen.fill(self.bg_color)
        # Draw concentric rings and radial lines only if the frame is enabled
        if self.frame_enabled:
            # Draw concentric rings (outer, middle, inner) to improve readability
            for frac in (1.0, 0.66, 0.33):
                radius = int(self.r * frac)
                pygame.draw.circle(self.screen, self.grid_color, self.center, radius, 1)
            # Draw radial lines every 45 degrees (N, NE, E, SE, etc.)
            for d in range(0, 360, 45):
                x = self.center[0] + int(self.r * math.sin(math.radians(d)))
                y = self.center[1] - int(self.r * math.cos(math.radians(d)))
                pygame.draw.line(self.screen, self.grid_color, self.center, (x, y), 1)

    # ------------------------------------------------------------------
    # Interactive controls setup and handling
    def _init_controls(self, size, radar_height) -> None:
        """Initialize slider and toggle definitions based on the detector.

        This method populates ``self._controls_config`` with a series of
        dictionaries defining each interactive element.  It computes
        positional information such as row centres and track extents
        relative to the provided ``size`` and ``radar_height`` values.
        """
        if not self.detector:
            # If no detector is provided, there is nothing to control
            return
        # Define which parameters are exposed via sliders and their ranges.
        # Labels are given in Polish for the UI.
        slider_defs = [
            {
                "label": "Próg",
                "param": "threshold",
                "min": 0.01,
                "max": 0.2,
                "value": float(getattr(self.detector, "threshold", 0.08))
            },
            {
                "label": "Siła",
                "param": "strength",
                "min": 1.0,
                "max": 10.0,
                "value": float(getattr(self.detector, "strength", 4.0))
            },
            {
                "label": "Wygładzenie",
                "param": "smoothing",
                "min": 0.005,
                "max": 0.1,
                "value": float(getattr(self.detector, "smoothing", 0.05))
            },
        ]
        # Define toggles; auto threshold, show/hide frame (ramka) and detection of other events.
        toggle_defs = [
            {
                "label": "Auto próg",
                "param": "dynamic",
                "value": bool(getattr(self.detector, "dynamic", False))
            },
            {
                "label": "Ramka",
                "param": "frame",
                "value": True
            },
            {
                "label": "Inne dźwięki",
                "param": "other",
                "value": bool(getattr(self.detector, "enable_other", False))
            }
        ]
        total_controls = len(slider_defs) + len(toggle_defs)
        # Avoid division by zero; if no controls defined, skip
        if total_controls == 0:
            return
        # Determine row height within the controls area
        row_h = self.controls_height / total_controls
        # Horizontal extents for slider tracks
        track_margin_left = 130  # space reserved for labels
        track_margin_right = 50  # space reserved for value labels or toggles
        track_x0 = track_margin_left
        track_x1 = size[0] - track_margin_right
        # Build control entries
        idx = 0
        for sd in slider_defs:
            y_center = radar_height + int((idx + 0.5) * row_h)
            self._controls_config.append({
                "type": "slider",
                "label": sd["label"],
                "param": sd["param"],
                "min": sd["min"],
                "max": sd["max"],
                "value": sd["value"],
                "row_y": y_center,
                "track_x0": track_x0,
                "track_x1": track_x1
            })
            idx += 1
        for td in toggle_defs:
            y_center = radar_height + int((idx + 0.5) * row_h)
            # Determine the size of the toggle switch
            toggle_w, toggle_h = 40, 18
            toggle_x = track_x0
            toggle_y = int(y_center - toggle_h / 2)
            self._controls_config.append({
                "type": "toggle",
                "label": td["label"],
                "param": td["param"],
                "value": bool(td["value"]),
                "row_y": y_center,
                "toggle_rect": pygame.Rect(toggle_x, toggle_y, toggle_w, toggle_h)
            })
            idx += 1

    def _draw_controls(self) -> None:
        """Draw the interactive sliders and toggles on the screen."""
        if not self.controls or not self._controls_config:
            return
        for cfg in self._controls_config:
            y = cfg["row_y"]
            # Draw label on the left
            label_surf = self.font.render(cfg["label"], True, (200, 200, 210))
            self.screen.blit(label_surf, (10, y - label_surf.get_height() // 2))
            if cfg["type"] == "slider":
                # Draw track line
                x0, x1 = cfg["track_x0"], cfg["track_x1"]
                pygame.draw.line(self.screen, (70, 90, 120), (x0, y), (x1, y), 2)
                # Compute knob position
                v_norm = (cfg["value"] - cfg["min"]) / (cfg["max"] - cfg["min"])
                knob_x = int(x0 + v_norm * (x1 - x0))
                # Draw knob
                pygame.draw.circle(self.screen, (220, 220, 230), (knob_x, y), 6)
                # Display numeric value on the right
                val_text = f"{cfg['value']:.3f}" if cfg["param"] != "strength" else f"{cfg['value']:.1f}"
                val_surf = self.font.render(val_text, True, (180, 200, 220))
                self.screen.blit(val_surf, (x1 + 5, y - val_surf.get_height() // 2))
            elif cfg["type"] == "toggle":
                # Draw toggle switch background
                rect = cfg["toggle_rect"]
                # Outer border
                pygame.draw.rect(self.screen, (70, 90, 120), rect, border_radius=9)
                # Filled portion
                inner_rect = rect.inflate(-4, -4)
                if cfg["value"]:
                    pygame.draw.rect(self.screen, (100, 200, 100), inner_rect, border_radius=8)
                    # Knob on right
                    knob_center = (inner_rect.right - inner_rect.height // 2, inner_rect.centery)
                else:
                    pygame.draw.rect(self.screen, (40, 50, 60), inner_rect, border_radius=8)
                    # Knob on left
                    knob_center = (inner_rect.left + inner_rect.height // 2, inner_rect.centery)
                pygame.draw.circle(self.screen, (255, 255, 255), knob_center, inner_rect.height // 2 - 1)
                # Text "WŁ" (on) or "WYŁ" (off) next to toggle in Polish
                state_text = "WŁ" if cfg["value"] else "WYŁ"
                state_color = (100, 200, 100) if cfg["value"] else (150, 150, 150)
                txt_surf = self.font.render(state_text, True, state_color)
                # Position text to the right of the toggle
                txt_x = rect.x + rect.width + 5
                txt_y = rect.y + (rect.height - txt_surf.get_height()) // 2
                self.screen.blit(txt_surf, (txt_x, txt_y))

    def _handle_mouse_down(self, pos) -> None:
        """Handle mouse button press events for controls."""
        if not self.controls or not self._controls_config:
            return
        x, y = pos
        for idx, cfg in enumerate(self._controls_config):
            if cfg["type"] == "slider":
                # Check if click is within the vertical vicinity of the slider row
                # Expand hit area to +/- 8 px vertically for easier interaction
                if abs(y - cfg["row_y"]) <= 8 and cfg["track_x0"] <= x <= cfg["track_x1"]:
                    # Immediately update value based on click position
                    self._update_slider_value(idx, x)
                    self._drag_index = idx
                    break
            elif cfg["type"] == "toggle":
                if cfg["toggle_rect"].collidepoint(pos):
                    # Toggle the value
                    cfg["value"] = not cfg["value"]
                    # Update detector or local property based on parameter
                    if cfg["param"] == "dynamic":
                        # Auto threshold toggle affects the detector
                        if self.detector:
                            setattr(self.detector, "dynamic", cfg["value"])
                    elif cfg["param"] == "frame":
                        # Frame toggle affects local frame visibility
                        self.frame_enabled = cfg["value"]
                    elif cfg["param"] == "other":
                        # Toggle detection of other events on the detector
                        if self.detector:
                            setattr(self.detector, "enable_other", cfg["value"])
                    break

    def _handle_mouse_move(self, pos) -> None:
        """Handle mouse motion events for dragging slider knobs."""
        if self._drag_index is None:
            return
        idx = self._drag_index
        cfg = self._controls_config[idx]
        if cfg["type"] != "slider":
            return
        x, _ = pos
        # Clamp x to track range
        x_clamped = max(cfg["track_x0"], min(cfg["track_x1"], x))
        self._update_slider_value(idx, x_clamped)

    def _handle_mouse_up(self) -> None:
        """Reset dragging state when mouse button is released."""
        self._drag_index = None

    def _update_slider_value(self, idx: int, x: int) -> None:
        """Update the slider value and propagate it to the detector."""
        cfg = self._controls_config[idx]
        if cfg["type"] != "slider":
            return
        # Compute normalized position
        v_norm = (x - cfg["track_x0"]) / (cfg["track_x1"] - cfg["track_x0"])
        v_norm = max(0.0, min(1.0, v_norm))
        # Map to value range
        val = cfg["min"] + v_norm * (cfg["max"] - cfg["min"])
        # Optionally round the value for readability
        if cfg["param"] == "strength":
            # Round to one decimal place
            val = round(val, 1)
        elif cfg["param"] == "threshold":
            val = round(val, 3)
        elif cfg["param"] == "smoothing":
            val = round(val, 4)
        cfg["value"] = float(val)
        # Update detector if available
        if self.detector:
            setattr(self.detector, cfg["param"], val)

    def _draw_marker_circle(self, x: int, y: int, size: int, color: tuple, alpha: int) -> None:
        """Draw a circular marker with the given parameters."""
        # Create a surface with per-pixel alpha
        surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        pygame.draw.circle(surf, (*color, alpha), (size, size), size)
        self.screen.blit(surf, (x - size, y - size))

    def _draw_marker_square(self, x: int, y: int, size: int, color: tuple, alpha: int) -> None:
        """Draw a square marker with the given parameters."""
        # Create a surface with per-pixel alpha
        surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        # Draw a square centered at (size, size)
        rect = pygame.Rect(0, 0, size * 2, size * 2)
        pygame.draw.rect(surf, (*color, alpha), rect)
        self.screen.blit(surf, (x - size, y - size))

    def update(self) -> bool:
        """Update the radar display.

        Returns
        -------
        bool
            False if a quit event was received and the caller should exit; True
            otherwise.
        """
        # Handle window and input events (such as closing the window and interacting with controls)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.MOUSEBUTTONDOWN:
                try:
                    self._handle_mouse_down(ev.pos)
                except Exception:
                    pass
            elif ev.type == pygame.MOUSEMOTION:
                try:
                    self._handle_mouse_move(ev.pos)
                except Exception:
                    pass
            elif ev.type == pygame.MOUSEBUTTONUP:
                try:
                    self._handle_mouse_up()
                except Exception:
                    pass
        # Draw the radar background (concentric rings and grid)
        self._draw_background()
        # Draw sweeping radar line
        try:
            # Compute current sweep angle based on elapsed time and configured speed
            sweep_angle = (time.monotonic() * self.sweep_speed) % 360.0
            end_x = self.center[0] + int(self.r * math.sin(math.radians(sweep_angle)))
            end_y = self.center[1] - int(self.r * math.cos(math.radians(sweep_angle)))
            # Create a translucent surface for the sweep line
            sweep_surf = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            # A semi‑transparent line to simulate radar beam
            pygame.draw.line(sweep_surf, (*self.sweep_color, 100), self.center, (end_x, end_y), 2)
            # Blit the sweep onto the main screen
            self.screen.blit(sweep_surf, (0, 0))
        except Exception:
            # In case of unexpected errors (e.g. during headless operation), skip drawing the sweep
            pass
        now = time.monotonic()
        # Iterate over markers to draw them; rotate the deque to move through
        for _ in range(len(self.markers)):
            m = self.markers[0]
            age = now - m["t"]
            # Remove markers that have exceeded their lifetime
            if age > self.life:
                self.markers.popleft()
                continue
            # Fade factor from 1.0 down to 0.0 over the marker's lifetime
            fade = 1.0 - age / self.life
            # Convert angle to screen coordinates
            rad = math.radians(m["a"])
            x = self.center[0] + int(self.r * math.sin(rad))
            y = self.center[1] - int(self.r * math.cos(rad))
            # Determine colour based on event kind using an updated palette
            if m["k"] == "shot":
                # bright warm red for gunshots
                col = (240, 80, 80)
            elif m["k"] == "step":
                # bright cool blue for footsteps
                col = (80, 180, 250)
            else:
                # neutral grey for other events
                col = (200, 200, 200)
            # Marker size scales with amplitude and fade
            size = max(4, int(12 * m["amp"] * fade))
            alpha = int(220 * fade)
            # Draw the appropriate shape
            if m.get("shape") == "square":
                self._draw_marker_square(x, y, size, col, alpha)
            else:
                # Default to circle for unknown shapes
                self._draw_marker_circle(x, y, size, col, alpha)
            # Rotate deque so that we visit each marker
            self.markers.rotate(-1)
        # Draw interactive controls on top of the radar
        try:
            self._draw_controls()
        except Exception:
            pass
        pygame.display.flip()
        # Limit frame rate to ~60 FPS
        self.clock.tick(60)
        return True

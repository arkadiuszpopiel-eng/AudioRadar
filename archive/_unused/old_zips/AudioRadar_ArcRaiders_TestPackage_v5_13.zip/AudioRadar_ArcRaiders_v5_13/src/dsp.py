import time, numpy as np, math, logging
def _amp_to_visual_scale(rms: float) -> float:
    x = max(1e-6, min(1.0, rms))
    return math.log10(1 + 9*x)
class EventDetector:
    """
    Detects transient audio events based on the root‑mean‑square (RMS) amplitude of
    incoming frames.  A cooldown period prevents repeated detection of the same
    sound.  Optionally, the detector can adapt its threshold dynamically to the
    noise floor of the environment, making it more sensitive in quiet scenes and
    less prone to false positives in noisy ones.

    Parameters
    ----------
    threshold : float
        Base RMS threshold (0..1) for detecting events.  When ``dynamic`` is
        enabled, this serves as a lower bound for the adaptive threshold.
    cooldown : float, optional
        Minimum time (seconds) between detections.  Helps prevent repeated
        detections of the same event.
    dynamic : bool, optional
        Enable automatic adjustment of the threshold based on a running
        estimate of ambient RMS noise.  Defaults to ``False``.
    strength : float, optional
        Multiplier applied to the ambient RMS when computing the adaptive
        threshold.  A higher value makes the detector less sensitive.
    smoothing : float, optional
        Smoothing factor (0..1) for the exponential moving average used to
        estimate the ambient RMS.  Smaller values produce a slower adaption.
    """

    def __init__(self, threshold: float, cooldown: float = 0.2,
                 dynamic: bool = False, strength: float = 5.0, smoothing: float = 0.05,
                 *, enable_other: bool = False, other_factor: float = 2.0,
                 logger: 'logging.Logger|None' = None, debug_rms: bool = False) -> None:
        """
        Create a new EventDetector.

        Parameters
        ----------
        threshold : float
            Base RMS threshold (0..1) for detecting events.  When ``dynamic`` is
            enabled, this serves as a lower bound for the adaptive threshold.
        cooldown : float, optional
            Minimum time (seconds) between detections.  Helps prevent repeated
            detections of the same event.
        dynamic : bool, optional
            Enable automatic adjustment of the threshold based on a running
            estimate of ambient RMS noise.  Defaults to ``False``.
        strength : float, optional
            Multiplier applied to the ambient RMS when computing the adaptive
            threshold.  A higher value makes the detector less sensitive.
        smoothing : float, optional
            Smoothing factor (0..1) for the exponential moving average used to
            estimate the ambient RMS.  Smaller values produce a slower adaption.
        enable_other : bool, optional
            When ``True``, the detector will also report "other" events for
            sounds whose RMS exceeds ``threshold / other_factor`` but does not
            reach the main threshold.  If ``False``, these softer sounds are
            ignored and only ``shot`` and ``step`` events are produced.
        other_factor : float, optional
            Divisor applied to the effective threshold to compute the minimum
            RMS required to classify an event as "other".  Must be >= 1.0.  A
            smaller value yields more "other" events, while a larger value
            reduces sensitivity.  Only used when ``enable_other`` is True.
        logger : logging.Logger or None, optional
            Logger used for debug messages when ``debug_rms`` is True.
        debug_rms : bool, optional
            If True, log the raw RMS, baseline and effective threshold values
            for each processed frame.
        """
        self.threshold = threshold
        self.cooldown = cooldown
        self.dynamic = dynamic
        self.strength = max(1.0, strength)
        self.smoothing = max(0.001, min(1.0, smoothing))
        # Additional parameters controlling classification of "other" events
        self.enable_other: bool = bool(enable_other)
        self.other_factor: float = max(1.0, float(other_factor))
        # Timestamp of the last detection
        self._last = 0.0
        # Running estimate of the background noise floor when adaptive
        self._baseline = 0.0
        # Optional logging of RMS and thresholds for calibration
        self._logger = logger
        self._debug_rms = bool(debug_rms)
        # Initialize last processed RMS and thresholds used for the most recent frame.
        # These values are updated on each call to ``process`` and may be used by
        # the UI (e.g. level meter) to display current signal strength and thresholds.
        self.last_rms: float = 0.0
        self.last_effective_thr: float = self.threshold
        # Precompute other threshold based on the initial effective threshold; this
        # value will be updated in process().
        self.last_other_thr: float = max(1e-6, self.threshold / self.other_factor)
        self.last_baseline: float = 0.0

    def process(self, frame: np.ndarray):
        """Process a frame of audio samples and return an event tuple if detected.

        Parameters
        ----------
        frame : np.ndarray
            A 2D array of shape (n_samples, n_channels) containing int16 audio.

        Returns
        -------
        tuple or None
            ``(kind, visual_amp)`` where ``kind`` is either ``"shot"`` or
            ``"step"``, and ``visual_amp`` is a scaled amplitude for
            visualization.  Returns ``None`` if no event is detected.
        """
        # Flatten all channels to compute a global RMS in the range [0,1]
        x = frame.astype(np.float32).reshape(-1)
        rms: float = float(np.sqrt(np.mean(x * x))) / 32768.0
        now = time.monotonic()
        # Update baseline noise estimate if dynamic threshold is enabled
        if self.dynamic:
            if self._baseline <= 0.0:
                # Initialize baseline with the first RMS value
                self._baseline = rms
            else:
                # Exponential moving average; recent samples count more
                self._baseline = (1.0 - self.smoothing) * self._baseline + self.smoothing * rms
            # Compute adaptive threshold: baseline * strength, but no lower than the fixed threshold
            effective_threshold = max(self.threshold, self._baseline * self.strength)
        else:
            effective_threshold = self.threshold
        # Compute threshold for "other" events.  A lower threshold means more
        # sensitivity.  We divide the effective threshold by other_factor.  The
        # result is clamped to a minimum of 1e‑6 to avoid spurious detections.
        other_threshold = max(1e-6, effective_threshold / self.other_factor)
        # Optionally log RMS and threshold values for calibration.  We log
        # immediately after computing thresholds so that the baseline update
        # above is reflected.  Logging is performed only if a logger
        # was provided and debug_rms is True.
        if self._debug_rms and self._logger is not None:
            try:
                self._logger.debug(
                    "RMS=%.5f eff_thr=%.5f other_thr=%.5f baseline=%.5f strength=%.2f",
                    rms, effective_threshold, other_threshold, self._baseline, self.strength
                )
            except Exception:
                pass
        # Skip events that are below the other_threshold or within the cooldown window
        if rms < other_threshold or (now - self._last) < self.cooldown:
            return None
        # Update last event time to enforce cooldown for all kinds of events
        self._last = now
        # Persist the latest RMS and thresholds for external access (e.g., UI meters)
        self.last_rms = rms
        self.last_effective_thr = effective_threshold
        self.last_other_thr = other_threshold
        self.last_baseline = self._baseline
        # Classify event type: very strong events are "shots"; moderate events
        # are "steps"; softer events may be "other" if enabled.  Otherwise
        # ignore them.
        if rms > effective_threshold * 3.0:
            kind = "shot"
        elif rms > effective_threshold:
            kind = "step"
        elif self.enable_other:
            kind = "other"
        else:
            # Event falls below the primary threshold and other events are disabled
            return None
        return kind, _amp_to_visual_scale(rms)

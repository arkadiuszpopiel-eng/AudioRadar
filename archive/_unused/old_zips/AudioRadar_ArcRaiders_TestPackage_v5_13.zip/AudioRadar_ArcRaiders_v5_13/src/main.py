import argparse
import sys
import queue
import traceback
import time
import json  # new: for loading/saving configuration
from logger_setup import setup_logger
from audio_loopback import AudioCapturer
from dsp import EventDetector
from direction import estimate_angle
def parse_args():
    """Parse command‑line arguments for the Audio Radar program.

    The parser accepts common options such as sampling rate, channel count,
    buffer size, detection threshold, and whether to run calibration or headless mode.  Two new
    options, ``--config`` and ``--save_config``, allow for loading configuration from a JSON file
    or saving the current configuration to a file for future runs.
    """
    p = argparse.ArgumentParser(description="Audio Radar — visualize directional audio events")
    p.add_argument("--rate", type=int, default=48000, help="Sampling rate for audio capture (Hz)")
    p.add_argument("--channels", type=int, default=2, choices=[2, 6, 8], help="Number of audio channels")
    p.add_argument("--buffer_ms", type=int, default=50, help="Buffer size in milliseconds")
    p.add_argument("--threshold", type=float, default=0.08, help="RMS threshold for event detection [0-1] (default: 0.08)")
    p.add_argument("--device_index", type=str, default=None,
                   help="Force a specific loopback device index (int).  If omitted, auto‑detect.")
    p.add_argument("--log", type=str, default="logs/log.txt", help="Path to the log file")
    p.add_argument("--debug", action="store_true", help="Enable verbose debug logging")
    p.add_argument("--calibrate", action="store_true",
                   help="Run the speaker calibration routine and exit (stereo/5.1/7.1)")
    p.add_argument("--headless", action="store_true", help="Run without opening the Pygame window; log events only")
    # New options: config load/save
    p.add_argument("--config", type=str, default=None, help="Load configuration from a JSON file")
    p.add_argument("--save_config", type=str, default=None, help="Save current configuration to a JSON file")
    # Dynamic threshold enables automatic adjustment based on ambient noise floor
    p.add_argument("--auto_threshold", action="store_true", help="Enable adaptive RMS threshold based on ambient noise")
    # List available audio devices and exit
    p.add_argument("--list_devices", action="store_true", help="List available audio capture devices and exit")

    # Parameters for dynamic threshold adaptation.  These control how sensitive the
    # detector is when --auto_threshold is enabled.  A lower strength yields a
    # lower threshold (more sensitivity), while a higher strength reduces
    # sensitivity.  Smoothing controls the responsiveness of the baseline noise
    # estimate; larger values react faster to changes in ambient noise.
    p.add_argument("--dyn_strength", type=float, default=4.0,
                   help="Multiplier for ambient RMS when computing adaptive threshold (default: 4.0)")
    p.add_argument("--dyn_smoothing", type=float, default=0.05,
                   help="Smoothing factor for ambient RMS estimate (0..1, default: 0.05)")

    # When enabled, the RMS value, baseline estimate and effective threshold
    # will be logged for each frame (at DEBUG level) to assist with
    # calibrating the detection sensitivity.
    p.add_argument("--debug_rms", action="store_true", help="Log RMS and adaptive threshold values for every frame (debug mode)")

    # Enable detection of other (softer) events.  When this flag is provided,
    # the detector will classify sounds that fall below the main threshold but
    # above a fraction of it as "other".  This can increase the number of
    # detected events by including quieter noises from the game.  Use
    # --other_factor to adjust sensitivity.
    p.add_argument("--other", dest="enable_other", action="store_true",
                   help="Włącz wykrywanie innych cichych dźwięków (oprócz kroków i strzałów)")
    p.add_argument("--other_factor", type=float, default=2.0,
                   help="Dzielenie progu RMS przy wykrywaniu innych dźwięków (domyślnie 2.0). Mniejsza wartość zwiększa czułość na ciche dźwięki.")

    # Show a horizontal level meter in the UI that visualizes the current RMS
    # relative to the thresholds.  Enabled by default; use --no_meter to hide.
    p.add_argument("--no_meter", dest="no_meter", action="store_true",
                   help="Ukryj miernik poziomu sygnału w interfejsie (domyślnie widoczny)")

    # Scan available audio devices for the highest RMS before selecting a device.  When
    # this flag is provided, the program will briefly record from each device
    # with sufficient input channels and choose the one with the largest
    # average RMS amplitude.  This can help automatically detect the proper
    # loopback source when the default device does not contain audio.
    p.add_argument("--scan_devices", action="store_true",
                   help="Przeskanuj urządzenia przed wyborem indeksu (wybierz to z najwyższym sygnałem)")

    # Customise the window size; defaults to 600x600.  Width and height are
    # specified separately to facilitate passing via individual options.  A
    # larger window may improve readability of the radar and controls.
    p.add_argument("--width", type=int, default=600,
                   help="Szerokość okna wizualizacji (domyślnie 600)")
    p.add_argument("--height", type=int, default=600,
                   help="Wysokość okna wizualizacji (domyślnie 600)")
    # Height reserved for the control panel.  Increase this value if the
    # elementy interfejsu nachodzą na siebie.
    p.add_argument("--controls_height", type=int, default=120,
                   help="Wysokość obszaru kontrolnego w pikselach (domyślnie 120)")

    # Test the audio capture source.  When this flag is provided, the program
    # records a brief sample (about one second) from the selected device
    # (taking into account `--rate`, `--channels` and `--device_index`) and
    # reports the average RMS amplitude across channels.  This helps verify
    # that the loopback device is correctly configured and that audible
    # signals are present.  After the test, the program exits without
    # running the radar visualisation.
    p.add_argument("--test_source", action="store_true", help="Record a short sample and report RMS to verify audio capture")
    return p.parse_args()
def main():
    """Entry point for the Audio Radar application.

    This function orchestrates parsing of command‑line arguments, optional loading
    and saving of configuration to a JSON file, initialization of logging,
    audio capture, event detection, direction estimation, and visualization.  It
    keeps running until the user interrupts or closes the window.
    """
    args = parse_args()
    # Optionally load configuration from JSON prior to initializing logger.  We print
    # warnings to stdout because the logger may not yet be configured.  Fields in the
    # config file override command‑line defaults but command‑line flags still take
    # precedence.
    if getattr(args, "config", None):
        try:
            with open(args.config, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            # Define default values for keys that we allow to be overridden via config.  CLI
            # arguments take precedence; values in the config file will only override these
            # defaults if the current value matches the default.  This ensures that
            # specifying a value on the command line has higher priority than the config.
            _defaults = {
                "rate": 48000,
                "channels": 2,
                "buffer_ms": 50,
                # Align with the default threshold used by parse_args (0.08)
                "threshold": 0.08,
                "device_index": None,
                "log": "logs/log.txt",
                "debug": False,
                "calibrate": False,
                "headless": False
            }
            for key, val in cfg.items():
                if hasattr(args, key) and key in _defaults:
                    current = getattr(args, key)
                    if current == _defaults[key]:
                        setattr(args, key, val)
        except Exception as e:
            # Config read errors are non‑fatal; we will continue with defaults and CLI overrides
            print(f"[WARN] Nie mogę wczytać konfiguracji {args.config}: {e}")
    # Initialize logger using (possibly) updated args
    logger = setup_logger(args.log, args.debug)
    # Log the version and current configuration
    logger.info(
        "=== Audio Radar START (v5.13) === cfg: rate=%s ch=%s buf=%sms thr=%.3f device_index=%s calibrate=%s headless=%s auto_threshold=%s dyn_strength=%.2f dyn_smoothing=%.3f enable_other=%s other_factor=%.2f show_meter=%s",
        args.rate, args.channels, args.buffer_ms, args.threshold, args.device_index, args.calibrate, args.headless,
        args.auto_threshold, args.dyn_strength, args.dyn_smoothing, getattr(args, "enable_other", False), getattr(args, "other_factor", 2.0), not getattr(args, "no_meter", False))

    # If device scanning is requested, measure RMS on all devices and choose the
    # one with the highest average RMS.  This can automatically identify the
    # correct loopback source when nothing is detected on the default device.
    if getattr(args, "scan_devices", False):
        try:
            import pyaudiowpatch as pyaudio
        except Exception:
            logger.warning("--scan_devices: biblioteka PyAudioWPatch nie jest zainstalowana; pomijam skanowanie.")
        else:
            import numpy as np, time as _t
            from audio_loopback import AudioCapturer as _Cap
            try:
                pa = pyaudio.PyAudio()
            except Exception:
                logger.warning("--scan_devices: nie udało się zainicjować PyAudio; pomijam skanowanie.")
            else:
                best_idx = None
                best_rms = 0.0
                for idx in range(pa.get_device_count()):
                    try:
                        info = pa.get_device_info_by_index(idx)
                    except Exception:
                        continue
                    # Skip devices that cannot capture the requested number of channels
                    if info.get("maxInputChannels", 0) < args.channels:
                        continue
                    # Attempt to open a short capture on this device
                    rms_sum = 0.0
                    frames_cnt = 0
                    def _cb(frm: 'np.ndarray'):
                        nonlocal rms_sum, frames_cnt
                        flat = frm.astype(np.float32).reshape(-1)
                        v = float(np.sqrt(np.mean(flat * flat))) / 32768.0
                        rms_sum += v
                        frames_cnt += 1
                    try:
                        cap_t = _Cap(rate=args.rate, channels=args.channels, buffer_ms=args.buffer_ms, logger=logger, device_index=idx)
                        cap_t.start(_cb)
                        _t.sleep(0.5)
                        cap_t.stop()
                    except Exception:
                        continue
                    if frames_cnt > 0:
                        avg_rms = rms_sum / frames_cnt
                        logger.debug("SCAN_DEV idx=%s avg_rms=%.5f", idx, avg_rms)
                        if avg_rms > best_rms:
                            best_rms = avg_rms
                            best_idx = idx
                try:
                    pa.terminate()
                except Exception:
                    pass
                if best_idx is not None:
                    logger.info("Skanowanie zakończone. Wybrano urządzenie %s (avg RMS=%.5f)", best_idx, best_rms)
                    args.device_index = str(best_idx)
                else:
                    logger.warning("Skanowanie nie znalazło źródła z wykrywalnym sygnałem.")

    # If requested, list available audio capture devices and exit.  This is useful
    # for determining the correct loopback device index.  We perform this check
    # after the logger is initialized so messages are properly recorded.
    if args.list_devices:
        try:
            import pyaudiowpatch as pyaudio
        except Exception:
            logger.error("PyAudioWPatch nie jest zainstalowany. Lista urzadzen niedostepna.")
            return 1
        try:
            pa = pyaudio.PyAudio()
            logger.info("=== Lista urzadzen WASAPI loopback ===")
            for i in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(i)
                name = info.get("name", "?")
                host_api = info.get("hostApi", "?")
                max_in = info.get("maxInputChannels", 0)
                logger.info("[%d] name=%s | hostApi=%s | maxInputChannels=%s", i, name, host_api, max_in)
            pa.terminate()
            return 0
        except Exception as e:
            logger.exception("Nie udalo sie pobrac listy urzadzen:")
            return 1

    # Run calibration routine if requested.  This plays pings on each channel
    # and can help verify speaker assignments.  It does not exit, so the main
    # radar will continue to run after calibration.
    if args.calibrate:
        try:
            from calibrate import run_calibration
            rc = run_calibration(logger, rate_hint=args.rate, channels=args.channels)
            if rc != 0:
                logger.warning("Kalibracja kod=%s", rc)
        except Exception:
            logger.exception("Kalibracja nie powiodla sie:")
    # If the user requested a simple capture test, perform it here and exit.
    if args.test_source:
        import numpy as np, time as _t
        try:
            # Initialize audio capture on the selected device using the same
            # logic as the main capturer.  We reuse AudioCapturer internally
            # but drive it synchronously in this test.
            from audio_loopback import AudioCapturer as _Cap
            cap_t = _Cap(rate=args.rate, channels=args.channels, buffer_ms=args.buffer_ms, logger=logger, device_index=args.device_index)
            rms_sum = 0.0
            frames_cnt = 0
            def _on_frame_test(frm: 'np.ndarray'):
                nonlocal rms_sum, frames_cnt
                flat = frm.astype(np.float32).reshape(-1)
                val = float(np.sqrt(np.mean(flat * flat))) / 32768.0
                rms_sum += val; frames_cnt += 1
            cap_t.start(_on_frame_test)
            # Wait around one second to collect some frames
            _t.sleep(1.0)
            try:
                cap_t.stop()
            except Exception:
                pass
            if frames_cnt > 0:
                avg_rms = rms_sum / frames_cnt
                logger.info("TEST_SOURCE: captured %s frames, avg RMS=%.5f", frames_cnt, avg_rms)
                print(f"[TEST_SOURCE] Zebrano {frames_cnt} ramek. Średni RMS: {avg_rms:.5f}")
            else:
                logger.info("TEST_SOURCE: no frames captured or zero audio")
                print("[TEST_SOURCE] Nie udało się zebrać ramek z urządzenia. Sprawdź konfigurację loopback.")
            return 0
        except Exception as e:
            logger.exception("TEST_SOURCE: nieoczekiwany błąd testu źródła:")
            print(f"[TEST_SOURCE] Nieoczekiwany błąd: {e}")
            return 1
    import numpy as np, queue
    # Initialize the event detector prior to setting up the UI.  When
    # auto_threshold is enabled we allow automatic adaptation to the ambient noise
    # floor.
    det = EventDetector(
        threshold=args.threshold,
        cooldown=0.2,
        dynamic=args.auto_threshold,
        strength=args.dyn_strength,
        smoothing=args.dyn_smoothing,
        enable_other=getattr(args, "enable_other", False),
        other_factor=getattr(args, "other_factor", 2.0),
        logger=logger,
        debug_rms=args.debug_rms or args.debug
    )
    # Prepare a list of audio devices for the UI.  If PyAudioWPatch is available,
    # enumerate devices with sufficient input channels and include their indices
    # and names.  These will be passed into the radar display for selection.
    device_list = []
    initial_dev_index = None
    if not args.headless:
        try:
            import pyaudiowpatch as pyaudio
            pa = pyaudio.PyAudio()
            for i in range(pa.get_device_count()):
                try:
                    info = pa.get_device_info_by_index(i)
                except Exception:
                    continue
                # Only include devices that support the requested number of channels
                if info.get("maxInputChannels", 0) >= args.channels:
                    name = info.get("name", f"Urządzenie {i}")
                    device_list.append((i, name))
            pa.terminate()
            # Determine the initial device index if one was provided on the CLI
            if args.device_index is not None:
                try:
                    initial_dev_index = int(args.device_index)
                except Exception:
                    initial_dev_index = None
        except Exception:
            # If enumeration fails, leave device_list empty and initial_dev_index None
            device_list = []
            initial_dev_index = None

    # Create the radar UI unless in headless mode.  Pass the detector
    # instance and enable interactive controls.  We use a slightly taller
    # window to accommodate sliders and toggles (600x600 by default).
    radar = None
    # Holder for AudioCapturer used by the device change callback; see below.
    cap_holder = {}
    if not args.headless:
        try:
            import pygame
            from viz import RadarDisplay
            # Determine the window size and control panel height based on CLI
            width = max(200, int(getattr(args, "width", 600)))
            height = max(200, int(getattr(args, "height", 600)))
            c_height = max(50, int(getattr(args, "controls_height", 120)))
            # Create a placeholder callback; the actual AudioCapturer will be stored
            # in cap_holder once it is created below.  When the user selects a new
            # device, this callback stops the current capture, updates
            # args.device_index, creates a new capturer and starts it.
            def _ui_device_change(new_idx: int) -> None:
                # Log the change
                logger.info("UI: zmiana urządzenia na %s", new_idx)
                # Stop the current capture if present
                c = cap_holder.get("cap")
                if c is not None:
                    try:
                        c.stop()
                    except Exception:
                        pass
                # Update the device index in args so future restarts use the new value
                args.device_index = str(new_idx)
                # Create a new capturer and start it
                try:
                    new_cap = AudioCapturer(rate=args.rate, channels=args.channels, buffer_ms=args.buffer_ms,
                                           logger=logger, device_index=args.device_index)
                    cap_holder["cap"] = new_cap
                    new_cap.start(on_frame)
                except Exception:
                    logger.exception("UI: błąd przy przełączaniu urządzenia")

            # Instantiate the radar display.  Provide the device list and callback
            radar = RadarDisplay(size=(width, height), debug=args.debug, detector=det, controls=True,
                                 show_meter=not getattr(args, "no_meter", False), controls_height=c_height,
                                 device_list=device_list, initial_device_index=initial_dev_index,
                                 on_device_change=_ui_device_change)
            logger.info("UI: Pygame okno uruchomione.")
        except Exception:
            logger.exception("UI: inicjalizacja Pygame nie powiodla sie — przechodze w tryb headless.")
            radar = None
    # Prepare a queue for communicating events between the audio thread and the UI
    q = queue.Queue()
    def on_frame(frame: 'np.ndarray'):
        ev = det.process(frame)
        if ev:
            kind, amp_scaled = ev
            angle = estimate_angle(frame)
            try:
                q.put_nowait((kind, angle, amp_scaled))
            except queue.Full:
                pass
            logger.debug("EVENT kind=%s amp(vis)=%.3f angle=%.1f", kind, amp_scaled, angle)
    # Create the initial audio capturer using the selected device index.  If a
    # device was chosen via --device_index or via scanning, its value may
    # be a string; ensure we pass it directly to AudioCapturer.  Store the
    # capturer in cap_holder so the UI callback can replace it later.
    cap = AudioCapturer(rate=args.rate, channels=args.channels, buffer_ms=args.buffer_ms, logger=logger,
                        device_index=args.device_index)
    cap.start(on_frame)
    # Save the initial capturer for UI callbacks
    cap_holder["cap"] = cap
    try:
        if radar is None:
            logger.info("Tryb: HEADLESS (bez okna). Zdarzenia beda logowane do pliku.")
            while True:
                try:
                    while True:
                        kind, angle, amp = q.get_nowait()
                        logger.info("EVENT: %-5s | angle=%6.1f | amp(vis)=%.3f", kind, angle, amp)
                except queue.Empty:
                    pass
                time.sleep(0.01)
        else:
            while True:
                try:
                    while True:
                        kind, angle, amp = q.get_nowait()
                        radar.add_marker(angle, kind, amp)
                except queue.Empty:
                    pass
                if not radar.update(): break
    except KeyboardInterrupt:
        logger.info("Przerwano przez uzytkownika.")
    except Exception:
        logger.exception("Nieobsluzony blad glownej petli:")
        return 2
    finally:
        # Always attempt to stop the audio capture thread and close resources
        try:
            cap.stop()
        except Exception:
            pass
        # Shut down the Pygame window if it was created
        if radar is not None:
            try:
                import pygame
                pygame.quit()
            except Exception:
                pass
        logger.info("=== Audio Radar STOP ===")
        # If the user requested to save the current configuration, write it out as JSON.
        # We include key runtime parameters.  Any errors during save are logged as warnings.
        if getattr(args, "save_config", None):
            cfg_out = {
                "rate": cap.rate if hasattr(cap, "rate") else args.rate,
                "channels": cap.channels if hasattr(cap, "channels") else args.channels,
                "buffer_ms": args.buffer_ms,
                "threshold": args.threshold,
                "device_index": args.device_index,
                "log": args.log,
                "debug": args.debug,
                "calibrate": args.calibrate,
                "headless": args.headless,
                # Persist new options when saving configuration
                "enable_other": getattr(args, "enable_other", False),
                "other_factor": getattr(args, "other_factor", 2.0),
                "no_meter": getattr(args, "no_meter", False),
            }
            try:
                import os
                # Ensure parent directory exists
                os.makedirs(os.path.dirname(args.save_config), exist_ok=True) if os.path.dirname(args.save_config) else None
                with open(args.save_config, "w", encoding="utf-8") as f:
                    json.dump(cfg_out, f, ensure_ascii=False, indent=2)
                logger.info("Konfiguracja zapisana do %s", args.save_config)
            except Exception as e:
                logger.warning("Nie udało się zapisać konfiguracji do %s: %s", args.save_config, e)
    return 0
if __name__=="__main__":
    raise SystemExit(main())

import pygame, math, time, collections
class RadarDisplay:
    """
    Simple radar-like visualization for audio events.  Each marker represents an audio event
    with an associated angle, kind (e.g. ``shot`` or ``step``) and amplitude.  Markers
    fade out over time.  Event kinds are rendered with different shapes to improve
    readability: ``shot`` events use circular blips, whereas ``step`` events use square
    markers.  Additional kinds fall back to circular markers.
    """

    def __init__(self, size=(600, 600), debug: bool = False, *, detector=None, controls: bool = False, show_meter: bool = True, controls_height: int | None = None, device_list: list | None = None, initial_device_index: int | None = None, on_device_change: callable | None = None):
        """Create a new radar display surface.

        Parameters
        ----------
        size : tuple of int
            The size of the window (width, height) in pixels.
        debug : bool
            If True, additional debug information may be logged or drawn.
        detector : EventDetector or None
            Optional reference to the event detector.  When provided and
            ``controls`` is ``True``, GUI sliders and switches will update
            parameters on this detector instance in real time.
        controls : bool, optional
            If True, allocate additional space at the bottom of the window
            for interactive configuration sliders and toggles.  Defaults to
            ``False``.
        """
        # Initialize the pygame environment and create a window
        pygame.init()
        self.debug = debug
        self.detector = detector
        self.controls = bool(controls)
        # Determine whether to draw a level meter on the UI.  The meter shows
        # the current RMS amplitude relative to the detector thresholds and
        # baseline.  It can help diagnose issues with signal capture.
        self.show_meter = bool(show_meter)
        # Reserve additional vertical space for controls if requested.  If a
        # custom controls_height was provided, use that value; otherwise
        # default to 100 pixels.  When controls are disabled, this value is zero.
        if self.controls:
            if controls_height is not None and controls_height > 0:
                self.controls_height = int(controls_height)
            else:
                self.controls_height = 100
        else:
            self.controls_height = 0
        # Store a copy of the initial size and device list
        self.size = list(size)
        self.device_list = list(device_list) if device_list else []
        # Callback invoked when the user selects a new audio device
        self.on_device_change = on_device_change
        # Determine the currently selected device index (index into device_list)
        self.selected_device_index = 0
        if self.device_list:
            # initial_device_index refers to device_list indices, not PyAudio indices.
            if initial_device_index is not None:
                # Find the position of this device in the list (match first element)
                for i, (dev_idx, _name) in enumerate(self.device_list):
                    if dev_idx == initial_device_index:
                        self.selected_device_index = i
                        break
        # Compute radar drawing area height
        radar_height = size[1] - self.controls_height
        # Create the display surface with the requested size and make it resizable
        self.screen = pygame.display.set_mode(size, pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        # Radar radius (40% of the smaller window dimension)
        self.r = int(min(size[0], radar_height) * 0.4)
        # Center the radar within the upper portion of the window
        self.center = (size[0] // 2, radar_height // 2)
        # Visual parameters (colours and speeds)
        # Use slightly lighter colours and brighter accents for a modern look.
        # Dark background with hints of blue; grid lines are lighter to
        # improve contrast; the sweep line uses a brighter green.
        self.bg_color = (10, 12, 28)         # dark background with a hint of blue
        self.grid_color = (60, 80, 110)      # lighter grid/radar lines
        self.sweep_color = (120, 220, 120)   # brighter sweep line colour
        self.sweep_speed = 45.0              # degrees per second
        # Deque to hold active markers; each marker is a dict with fields:
        #   a: angle in degrees
        #   k: kind of event ("shot", "step", etc.)
        #   amp: amplitude scale (0..1)
        #   t: timestamp when marker was added
        #   shape: marker shape ("circle" or "square")
        self.markers = collections.deque()
        # Marker lifetime in seconds
        self.life = 1.2
        # For interactive controls
        self._controls_config = []
        self._drag_index = None
        # Create font for labels if controls are enabled.  Use a slightly
        # larger font for better readability.  If SysFont fails (e.g. on
        # headless systems), fall back to the default Pygame font.
        if self.controls:
            pygame.font.init()
            try:
                self.font = pygame.font.SysFont(None, 18)
            except Exception:
                self.font = pygame.font.Font(None, 18)
            self._init_controls(size, radar_height)
        # State for showing/hiding the radar frame (circles and crosshairs)
        self.frame_enabled = True

        # Precompute meter rectangle parameters.  The meter is drawn at the
        # bottom of the window (spanning the entire width) if ``show_meter``
        # is True.  We reserve a small height to avoid overlapping with
        # controls.  These values are recalculated in ``update`` in case of
        # window resizing, but for fixed size they remain constant.
        self._meter_height = 10 if self.show_meter else 0

    def add_marker(self, angle: float, kind: str, amp: float) -> None:
        """Add a marker representing an audio event.

        Parameters
        ----------
        angle : float
            Angle of the event relative to the listener (degrees).  Values are normalized
            into the [0, 360) range.
        kind : str
            Type of the event.  Supported kinds include ``shot`` and ``step``.  Unknown
            kinds will be rendered as circles.
        amp : float
            Scaled amplitude (0..1) representing the relative loudness of the event.  The
            amplitude influences the size of the marker on the screen.
        """
        # Determine the shape based on the event kind.  Shots use circles, steps use
        # squares.  Unknown kinds fall back to circles.
        if kind == "shot":
            shape = "circle"
        elif kind == "step":
            shape = "square"
        else:
            shape = "circle"
        # Clamp amplitude into [0.02, 1.0] to avoid tiny or excessively large blips
        amp_clamped = max(0.02, min(1.0, amp))
        self.markers.append({
            "a": angle % 360.0,
            "k": kind,
            "amp": amp_clamped,
            "t": time.monotonic(),
            "shape": shape
        })

    def _draw_background(self) -> None:
        """Render the static radar background (concentric rings and crosshair)."""
        # Fill the background
        self.screen.fill(self.bg_color)
        # Draw concentric rings and radial lines only if the frame is enabled
        if self.frame_enabled:
            # Draw concentric rings (outer, middle, inner) to improve readability
            for frac in (1.0, 0.66, 0.33):
                radius = int(self.r * frac)
                pygame.draw.circle(self.screen, self.grid_color, self.center, radius, 1)
            # Draw radial lines every 45 degrees (N, NE, E, SE, etc.)
            for d in range(0, 360, 45):
                x = self.center[0] + int(self.r * math.sin(math.radians(d)))
                y = self.center[1] - int(self.r * math.cos(math.radians(d)))
                pygame.draw.line(self.screen, self.grid_color, self.center, (x, y), 1)

    # ------------------------------------------------------------------
    # Interactive controls setup and handling
    def _init_controls(self, size, radar_height) -> None:
        """Initialize slider and toggle definitions based on the detector.

        This method populates ``self._controls_config`` with a series of
        dictionaries defining each interactive element.  It computes
        positional information such as row centres and track extents
        relative to the provided ``size`` and ``radar_height`` values.
        """
        if not self.detector:
            # If no detector is provided, there is nothing to control
            return
        # Define which parameters are exposed via sliders and their ranges.
        # Labels are given in Polish for the UI.
        slider_defs = [
            {
                "label": "Próg",
                "param": "threshold",
                "min": 0.01,
                "max": 0.2,
                "value": float(getattr(self.detector, "threshold", 0.08))
            },
            {
                "label": "Siła",
                "param": "strength",
                "min": 1.0,
                "max": 10.0,
                "value": float(getattr(self.detector, "strength", 4.0))
            },
            {
                "label": "Wygładzenie",
                "param": "smoothing",
                "min": 0.005,
                "max": 0.1,
                "value": float(getattr(self.detector, "smoothing", 0.05))
            },
        ]
        # Define toggles; auto threshold, show/hide frame (ramka) and detection of other events.
        toggle_defs = [
            {
                "label": "Auto próg",
                "param": "dynamic",
                "value": bool(getattr(self.detector, "dynamic", False))
            },
            {
                "label": "Ramka",
                "param": "frame",
                "value": True
            },
            {
                "label": "Inne dźwięki",
                "param": "other",
                "value": bool(getattr(self.detector, "enable_other", False))
            }
        ]
        # Define device selector if a list of devices was provided and controls are enabled.
        selector_defs = []
        if self.device_list:
            # Build a separate definition for device selection.  We will show the current
            # device name and allow the user to cycle through available devices.
            selector_defs.append({
                "label": "Urządzenie",
                "param": "device",
                "index": int(getattr(self, "selected_device_index", 0)),
                "options": [name for (_idx, name) in self.device_list]
            })
        total_controls = len(slider_defs) + len(toggle_defs) + len(selector_defs)
        # Avoid division by zero; if no controls defined, skip
        if total_controls == 0:
            return
        # Determine row height within the controls area
        row_h = self.controls_height / total_controls
        # Horizontal extents for slider tracks
        track_margin_left = 130  # space reserved for labels
        track_margin_right = 50  # space reserved for value labels or toggles
        track_x0 = track_margin_left
        track_x1 = size[0] - track_margin_right
        # Build control entries
        idx = 0
        for sd in slider_defs:
            y_center = radar_height + int((idx + 0.5) * row_h)
            self._controls_config.append({
                "type": "slider",
                "label": sd["label"],
                "param": sd["param"],
                "min": sd["min"],
                "max": sd["max"],
                "value": sd["value"],
                "row_y": y_center,
                "track_x0": track_x0,
                "track_x1": track_x1
            })
            idx += 1
        for td in toggle_defs:
            y_center = radar_height + int((idx + 0.5) * row_h)
            # Determine the size of the toggle switch.  Use slightly larger
            # dimensions for improved touch targets on high‑DPI displays.
            toggle_w, toggle_h = 50, 22
            toggle_x = track_x0
            toggle_y = int(y_center - toggle_h / 2)
            self._controls_config.append({
                "type": "toggle",
                "label": td["label"],
                "param": td["param"],
                "value": bool(td["value"]),
                "row_y": y_center,
                "toggle_rect": pygame.Rect(toggle_x, toggle_y, toggle_w, toggle_h)
            })
            idx += 1
        # Append selector rows at the end
        for sel in selector_defs:
            y_center = radar_height + int((idx + 0.5) * row_h)
            # Arrow dimensions and positions for the selector control
            arrow_w, arrow_h = 14, 12
            left_rect = pygame.Rect(track_x0, y_center - arrow_h // 2, arrow_w, arrow_h)
            right_rect = pygame.Rect(track_x0 + arrow_w + 5, y_center - arrow_h // 2, arrow_w, arrow_h)
            self._controls_config.append({
                "type": "selector",
                "label": sel["label"],
                "param": sel["param"],
                "index": sel["index"],
                "options": sel["options"],
                "row_y": y_center,
                "left_rect": left_rect,
                "right_rect": right_rect
            })
            idx += 1

    def _draw_controls(self) -> None:
        """Draw the interactive sliders and toggles on the screen."""
        if not self.controls or not self._controls_config:
            return
        for cfg in self._controls_config:
            y = cfg["row_y"]
            # Draw label on the left
            label_surf = self.font.render(cfg["label"], True, (200, 200, 210))
            self.screen.blit(label_surf, (10, y - label_surf.get_height() // 2))
            if cfg["type"] == "slider":
                # Draw track line
                x0, x1 = cfg["track_x0"], cfg["track_x1"]
                pygame.draw.line(self.screen, (70, 90, 120), (x0, y), (x1, y), 2)
                # Compute knob position
                v_norm = (cfg["value"] - cfg["min"]) / (cfg["max"] - cfg["min"])
                knob_x = int(x0 + v_norm * (x1 - x0))
                # Draw knob; slightly larger for better usability
                pygame.draw.circle(self.screen, (220, 220, 230), (knob_x, y), 8)
                # Display numeric value on the right
                val_text = f"{cfg['value']:.3f}" if cfg["param"] != "strength" else f"{cfg['value']:.1f}"
                val_surf = self.font.render(val_text, True, (180, 200, 220))
                self.screen.blit(val_surf, (x1 + 5, y - val_surf.get_height() // 2))
            elif cfg["type"] == "toggle":
                # Draw toggle switch background
                rect = cfg["toggle_rect"]
                # Outer border
                pygame.draw.rect(self.screen, (70, 90, 120), rect, border_radius=9)
                # Filled portion
                inner_rect = rect.inflate(-4, -4)
                if cfg["value"]:
                    pygame.draw.rect(self.screen, (100, 200, 100), inner_rect, border_radius=8)
                    # Knob on right
                    knob_center = (inner_rect.right - inner_rect.height // 2, inner_rect.centery)
                else:
                    pygame.draw.rect(self.screen, (40, 50, 60), inner_rect, border_radius=8)
                    # Knob on left
                    knob_center = (inner_rect.left + inner_rect.height // 2, inner_rect.centery)
                pygame.draw.circle(self.screen, (255, 255, 255), knob_center, inner_rect.height // 2 - 1)
                # Text "WŁ" (on) or "WYŁ" (off) next to toggle in Polish
                state_text = "WŁ" if cfg["value"] else "WYŁ"
                state_color = (100, 200, 100) if cfg["value"] else (150, 150, 150)
                txt_surf = self.font.render(state_text, True, state_color)
                # Position text to the right of the toggle
                txt_x = rect.x + rect.width + 5
                txt_y = rect.y + (rect.height - txt_surf.get_height()) // 2
                self.screen.blit(txt_surf, (txt_x, txt_y))
            elif cfg["type"] == "selector":
                # Draw device selector with left/right arrows and current device name
                # Draw arrows as small triangles
                left_rect = cfg.get("left_rect")
                right_rect = cfg.get("right_rect")
                arrow_col = (160, 180, 200)
                # Left arrow (pointing left)
                if left_rect:
                    pts_left = [
                        (left_rect.centerx + left_rect.width // 3, left_rect.top),
                        (left_rect.left, left_rect.centery),
                        (left_rect.centerx + left_rect.width // 3, left_rect.bottom)
                    ]
                    pygame.draw.polygon(self.screen, arrow_col, pts_left)
                # Right arrow (pointing right)
                if right_rect:
                    pts_right = [
                        (right_rect.centerx - right_rect.width // 3, right_rect.top),
                        (right_rect.right, right_rect.centery),
                        (right_rect.centerx - right_rect.width // 3, right_rect.bottom)
                    ]
                    pygame.draw.polygon(self.screen, arrow_col, pts_right)
                # Draw current device name
                idx_sel = cfg.get("index", 0)
                opts = cfg.get("options", [])
                name = opts[idx_sel] if 0 <= idx_sel < len(opts) else "Brak"
                # Truncate name if it's too long
                max_width = 180
                # We choose a safe x offset relative to right arrow
                text_x = (right_rect.right + 10) if right_rect else (left_rect.right + 10 if left_rect else 200)
                dev_surf = self.font.render(name, True, (200, 200, 210))
                # If the text width exceeds available space, we clip it
                if dev_surf.get_width() > max_width:
                    # simple ellipsis: shorten the name and add dots
                    truncated = name
                    while truncated and self.font.size(truncated + "...")[0] > max_width:
                        truncated = truncated[:-1]
                    truncated += "..."
                    dev_surf = self.font.render(truncated, True, (200, 200, 210))
                self.screen.blit(dev_surf, (text_x, y - dev_surf.get_height() // 2))

    def _handle_mouse_down(self, pos) -> None:
        """Handle mouse button press events for controls."""
        if not self.controls or not self._controls_config:
            return
        x, y = pos
        for idx, cfg in enumerate(self._controls_config):
            if cfg["type"] == "slider":
                # Check if click is within the vertical vicinity of the slider row
                # Expand hit area to +/- 8 px vertically for easier interaction
                if abs(y - cfg["row_y"]) <= 8 and cfg["track_x0"] <= x <= cfg["track_x1"]:
                    # Immediately update value based on click position
                    self._update_slider_value(idx, x)
                    self._drag_index = idx
                    break
            elif cfg["type"] == "toggle":
                if cfg["toggle_rect"].collidepoint(pos):
                    # Toggle the value
                    cfg["value"] = not cfg["value"]
                    # Update detector or local property based on parameter
                    if cfg["param"] == "dynamic":
                        # Auto threshold toggle affects the detector
                        if self.detector:
                            setattr(self.detector, "dynamic", cfg["value"])
                    elif cfg["param"] == "frame":
                        # Frame toggle affects local frame visibility
                        self.frame_enabled = cfg["value"]
                    elif cfg["param"] == "other":
                        # Toggle detection of other events on the detector
                        if self.detector:
                            setattr(self.detector, "enable_other", cfg["value"])
                    break
            elif cfg["type"] == "selector":
                # Check if click is within the left or right arrow to change device
                lrect = cfg.get("left_rect")
                rrect = cfg.get("right_rect")
                if lrect and lrect.collidepoint(pos):
                    # Move to previous device
                    current_idx = cfg.get("index", 0)
                    if self.device_list:
                        new_idx = (current_idx - 1) % len(self.device_list)
                        cfg["index"] = new_idx
                        # Update selected device index globally
                        self.selected_device_index = new_idx
                        # Invoke callback to change device if provided
                        if self.on_device_change:
                            new_dev_idx = self.device_list[new_idx][0]
                            try:
                                self.on_device_change(new_dev_idx)
                            except Exception:
                                pass
                    break
                elif rrect and rrect.collidepoint(pos):
                    # Move to next device
                    current_idx = cfg.get("index", 0)
                    if self.device_list:
                        new_idx = (current_idx + 1) % len(self.device_list)
                        cfg["index"] = new_idx
                        self.selected_device_index = new_idx
                        if self.on_device_change:
                            new_dev_idx = self.device_list[new_idx][0]
                            try:
                                self.on_device_change(new_dev_idx)
                            except Exception:
                                pass
                    break

    def _handle_mouse_move(self, pos) -> None:
        """Handle mouse motion events for dragging slider knobs."""
        if self._drag_index is None:
            return
        idx = self._drag_index
        cfg = self._controls_config[idx]
        if cfg["type"] != "slider":
            return
        x, _ = pos
        # Clamp x to track range
        x_clamped = max(cfg["track_x0"], min(cfg["track_x1"], x))
        self._update_slider_value(idx, x_clamped)

    def _handle_mouse_up(self) -> None:
        """Reset dragging state when mouse button is released."""
        self._drag_index = None

    def _update_slider_value(self, idx: int, x: int) -> None:
        """Update the slider value and propagate it to the detector."""
        cfg = self._controls_config[idx]
        if cfg["type"] != "slider":
            return
        # Compute normalized position
        v_norm = (x - cfg["track_x0"]) / (cfg["track_x1"] - cfg["track_x0"])
        v_norm = max(0.0, min(1.0, v_norm))
        # Map to value range
        val = cfg["min"] + v_norm * (cfg["max"] - cfg["min"])
        # Optionally round the value for readability
        if cfg["param"] == "strength":
            # Round to one decimal place
            val = round(val, 1)
        elif cfg["param"] == "threshold":
            val = round(val, 3)
        elif cfg["param"] == "smoothing":
            val = round(val, 4)
        cfg["value"] = float(val)
        # Update detector if available
        if self.detector:
            setattr(self.detector, cfg["param"], val)

    def _draw_marker_circle(self, x: int, y: int, size: int, color: tuple, alpha: int) -> None:
        """Draw a circular marker with the given parameters."""
        # Create a surface with per-pixel alpha
        surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        pygame.draw.circle(surf, (*color, alpha), (size, size), size)
        self.screen.blit(surf, (x - size, y - size))

    def _draw_marker_square(self, x: int, y: int, size: int, color: tuple, alpha: int) -> None:
        """Draw a square marker with the given parameters."""
        # Create a surface with per-pixel alpha
        surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        # Draw a square centered at (size, size)
        rect = pygame.Rect(0, 0, size * 2, size * 2)
        pygame.draw.rect(surf, (*color, alpha), rect)
        self.screen.blit(surf, (x - size, y - size))

    def update(self) -> bool:
        """Update the radar display.

        Returns
        -------
        bool
            False if a quit event was received and the caller should exit; True
            otherwise.
        """
        # Handle window and input events (such as closing the window and interacting with controls)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.VIDEORESIZE:
                try:
                    new_size = (ev.w, ev.h)
                    self._handle_resize(new_size)
                except Exception:
                    pass
                continue
            if ev.type == pygame.MOUSEBUTTONDOWN:
                try:
                    self._handle_mouse_down(ev.pos)
                except Exception:
                    pass
            elif ev.type == pygame.MOUSEMOTION:
                try:
                    self._handle_mouse_move(ev.pos)
                except Exception:
                    pass
            elif ev.type == pygame.MOUSEBUTTONUP:
                try:
                    self._handle_mouse_up()
                except Exception:
                    pass
        # Draw the radar background (concentric rings and grid)
        self._draw_background()
        # Draw sweeping radar line
        try:
            # Compute current sweep angle based on elapsed time and configured speed
            sweep_angle = (time.monotonic() * self.sweep_speed) % 360.0
            end_x = self.center[0] + int(self.r * math.sin(math.radians(sweep_angle)))
            end_y = self.center[1] - int(self.r * math.cos(math.radians(sweep_angle)))
            # Create a translucent surface for the sweep line
            sweep_surf = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            # A semi‑transparent line to simulate radar beam
            pygame.draw.line(sweep_surf, (*self.sweep_color, 100), self.center, (end_x, end_y), 2)
            # Blit the sweep onto the main screen
            self.screen.blit(sweep_surf, (0, 0))
        except Exception:
            # In case of unexpected errors (e.g. during headless operation), skip drawing the sweep
            pass
        now = time.monotonic()
        # Iterate over markers to draw them; rotate the deque to move through
        for _ in range(len(self.markers)):
            m = self.markers[0]
            age = now - m["t"]
            # Remove markers that have exceeded their lifetime
            if age > self.life:
                self.markers.popleft()
                continue
            # Fade factor from 1.0 down to 0.0 over the marker's lifetime
            fade = 1.0 - age / self.life
            # Convert angle to screen coordinates
            rad = math.radians(m["a"])
            x = self.center[0] + int(self.r * math.sin(rad))
            y = self.center[1] - int(self.r * math.cos(rad))
            # Determine colour based on event kind using an updated palette
            if m["k"] == "shot":
                # bright warm red for gunshots
                col = (240, 80, 80)
            elif m["k"] == "step":
                # bright cool blue for footsteps
                col = (80, 180, 250)
            else:
                # neutral grey for other events
                col = (200, 200, 200)
            # Marker size scales with amplitude and fade
            size = max(4, int(12 * m["amp"] * fade))
            alpha = int(220 * fade)
            # Draw the appropriate shape
            if m.get("shape") == "square":
                self._draw_marker_square(x, y, size, col, alpha)
            else:
                # Default to circle for unknown shapes
                self._draw_marker_circle(x, y, size, col, alpha)
            # Rotate deque so that we visit each marker
            self.markers.rotate(-1)
        # Draw interactive controls on top of the radar
        try:
            self._draw_controls()
        except Exception:
            pass
        # Draw a level meter showing the current RMS amplitude relative to
        # thresholds if enabled.  This provides visual feedback that audio
        # frames are being captured and allows manual calibration.
        if self.show_meter and self.detector:
            try:
                self._draw_meter()
            except Exception:
                pass
        pygame.display.flip()
        # Limit frame rate to ~60 FPS
        self.clock.tick(60)
        return True

    def _handle_resize(self, new_size: tuple) -> None:
        """Handle window resizing by adjusting radar and control geometry."""
        # Update internal size
        w, h = new_size
        if w <= 50 or h <= 50:
            return
        self.size = [w, h]
        # Re-create the display with resizable flag
        try:
            self.screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
        except Exception:
            self.screen = pygame.display.set_mode((w, h))
        # Recompute radar height and radius
        radar_height = h - self.controls_height
        self.r = int(min(w, radar_height) * 0.4)
        self.center = (w // 2, radar_height // 2)
        # Preserve existing control values
        old_values = {}
        sel_index = self.selected_device_index
        for cfg in self._controls_config:
            p = cfg.get("param")
            if cfg["type"] in ("slider", "toggle"):
                old_values[p] = cfg.get("value")
        # Rebuild control positions
        self._controls_config.clear()
        self._init_controls((w, h), radar_height)
        # Restore values
        for cfg in self._controls_config:
            if cfg["type"] in ("slider", "toggle"):
                p = cfg.get("param")
                if p in old_values:
                    cfg["value"] = old_values[p]
                    # Update detector accordingly
                    if p in ("threshold", "strength", "smoothing") and self.detector:
                        setattr(self.detector, p, cfg["value"])
                    elif p == "dynamic" and self.detector:
                        setattr(self.detector, "dynamic", cfg["value"])
                    elif p == "other" and self.detector:
                        setattr(self.detector, "enable_other", cfg["value"])
                # For frame toggle update local state
                if p == "frame":
                    self.frame_enabled = cfg["value"]
            elif cfg["type"] == "selector":
                cfg["index"] = sel_index

    def _draw_meter(self) -> None:
        """Draw a small horizontal level meter at the bottom of the window.

        The meter visualizes the most recent RMS amplitude (filled bar)
        alongside markers for the effective detection threshold, the
        secondary threshold for 'other' events, and the estimated baseline.
        This aids troubleshooting by confirming that audio is being
        captured and showing how close the signal is to triggering an event.
        """
        h = self.screen.get_height()
        w = self.screen.get_width()
        mh = self._meter_height
        if mh <= 0:
            return
        # Define meter bounding box
        pad = 4
        x0 = pad
        y0 = h - mh - pad
        width = w - 2 * pad
        height = mh - pad
        # Background of the bar
        bg_col = (30, 40, 55)
        pygame.draw.rect(self.screen, bg_col, (x0, y0, width, height))
        # Retrieve current values from detector
        rms = getattr(self.detector, 'last_rms', 0.0)
        thr = getattr(self.detector, 'last_effective_thr', 0.0)
        othr = getattr(self.detector, 'last_other_thr', 0.0)
        baseline = getattr(self.detector, 'last_baseline', 0.0)
        # Normalize to [0,1]
        def clamp01(v: float) -> float:
            return max(0.0, min(1.0, float(v)))
        rms_n = clamp01(rms)
        thr_n = clamp01(thr)
        othr_n = clamp01(othr)
        base_n = clamp01(baseline)
        # Draw RMS bar
        bar_col = (80, 200, 240)
        rms_width = int(width * rms_n)
        pygame.draw.rect(self.screen, bar_col, (x0, y0, rms_width, height))
        # Draw baseline line
        baseline_col = (120, 160, 200)
        base_x = x0 + int(width * base_n)
        pygame.draw.line(self.screen, baseline_col, (base_x, y0), (base_x, y0 + height), 1)
        # Draw other threshold marker
        other_col = (180, 180, 180)
        othr_x = x0 + int(width * othr_n)
        pygame.draw.line(self.screen, other_col, (othr_x, y0), (othr_x, y0 + height), 1)
        # Draw main threshold marker
        thr_col = (200, 80, 80)
        thr_x = x0 + int(width * thr_n)
        pygame.draw.line(self.screen, thr_col, (thr_x, y0), (thr_x, y0 + height), 1)

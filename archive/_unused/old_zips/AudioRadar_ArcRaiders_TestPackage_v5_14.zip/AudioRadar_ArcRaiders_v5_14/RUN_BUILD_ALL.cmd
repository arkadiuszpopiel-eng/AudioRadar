@echo off
setlocal ENABLEDELAYEDEXPANSION
rem Audio Radar — RUN_BUILD_ALL.cmd (v5.14, improved)

set "SCRIPT_DIR=%~dp0"
pushd "%SCRIPT_DIR%"

if not exist "logs" mkdir logs
if not exist "data" mkdir data
if not exist "cache" mkdir cache

set "LOG=logs\log.txt"
if not exist "%LOG%" type nul > "%LOG%"

echo [%date% %time%] RUN_BUILD_ALL v5.14: init >> "%LOG%"

where py >nul 2>nul
if %errorlevel%==0 ( set PY_CMD=py ) else ( set PY_CMD=python )

if not exist ".venv" (
  echo [%date% %time%] Tworzenie .venv... >> "%LOG%"
  %PY_CMD% -m venv .venv >> "%LOG%" 2>&1
  if errorlevel 1 (
    echo [%date% %time%] [ERROR] Nie można utworzyć venv >> "%LOG%"
    exit /b 1
  )
)
call .venv\Scripts\activate.bat >> "%LOG%" 2>&1
if errorlevel 1 (
  echo [%date% %time%] [ERROR] Nie można aktywować venv >> "%LOG%"
  exit /b 1
)

echo [%date% %time%] Aktualizacja pip... >> "%LOG%"
python -m pip install --upgrade pip >> "%LOG%" 2>&1

echo [%date% %time%] Instalacja zaleznosci... >> "%LOG%"
pip install -r requirements.txt >> "%LOG%" 2>&1
if errorlevel 1 (
  echo [%date% %time%] [ERROR] Instalacja paczek nie powiodla sie >> "%LOG%"
  exit /b 1
)

echo [%date% %time%] Uruchamianie aplikacji... >> "%LOG%"
python src\main.py %*

set RC=%ERRORLEVEL%
echo [%date% %time%] Aplikacja zakonczona RC=%RC% >> "%LOG%"
exit /b %RC%

popd
endlocal

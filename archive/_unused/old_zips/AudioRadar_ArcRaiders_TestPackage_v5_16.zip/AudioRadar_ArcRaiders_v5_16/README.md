Audio Radar — Arc Raiders Test Package (v5.16)
=================================================

Ta wersja programu **Audio Radar** rozszerza funkcjonalność poprzednich wydań
i wprowadza kilka istotnych usprawnień, które mają ułatwić pracę z
urządzeniami loopback oraz dopasować wygląd interfejsu do współczesnych
standardów.  Główne zmiany względem wydania 5.15 to:

* **Wybór urządzenia bezpośrednio w interfejsie** – w panelu sterowania
  po prawej stronie okna znajduje się selector „Urządzenie”, pozwalający
  przełączać się między dostępnymi źródłami dźwięku.  Program sam
  wykrywa wszystkie urządzenia obsługujące żądaną liczbę kanałów i
  wyświetla ich nazwy; zmiana urządzenia powoduje natychmiastowe
  przestawienie przechwytywania bez konieczności ponownego
  uruchamiania programu.
* **Skanowanie urządzeń w interfejsie** – oprócz parametru `--scan_devices` 
  z wiersza poleceń dostępny jest teraz przycisk **Skanuj** w panelu 
  sterowania. Naciśnięcie tego przycisku powoduje, że aplikacja 
  automatycznie testuje każde urządzenie z listy i wybiera to, na którym 
  RMS jest najwyższy.  Funkcja ta pomaga szybko znaleźć właściwe źródło 
  sygnału w przypadku braku dźwięku.
* **Interaktywne powiększanie okna** – okno Pygame jest teraz w pełni
  skalowalne (można je rozciągać myszką); dodatkowo można podać
  parametry `--width`, `--height` oraz `--controls_width`, aby
  zdefiniować szerokość, wysokość i szerokość bocznego panelu sterowania.
  Panel sterowania został przeniesiony na prawą stronę okna i
  rozciąga się w pionie, zapewniając więcej miejsca na suwaki i
  przełączniki.
  Interfejs zachowuje spójność przy zmianie rozmiaru.
* **Nowy, bardziej nowoczesny interfejs** – zwiększono domyślny
  rozmiar czcionki i kontrast kolorów, co ułatwia odczyt danych na
  ekranie.  Przyciski i suwaki są większe, a panel sterowania
  otrzymał przejrzysty układ.  Dostępne są przełączniki dla „Auto
  próg”, „Ramka”, „Inne dźwięki” oraz nowe pole wyboru urządzenia.

Zachowano wszystkie funkcje wprowadzone w poprzednich wersjach:

* **Obsługa dźwięku 24‑bit** – program automatycznie wybiera najlepszy
  dostępny format (16‑bit, 24‑bit, 32‑bit float) i konwertuje go
  na 16‑bit dla modułu DSP.  Umożliwia to przechwytywanie sygnału z
  kart dźwiękowych takich jak Sound Blaster Z SE, które pracują w
  trybie 24‑bit.  PyAudioWPatch obsługuje format `paInt24`, więc
  nagrywanie w 24‑bit jest możliwe【276964623489061†L1030-L1036】.
* **Dynamiczny próg RMS** – adaptacyjny mechanizm
  (`--auto_threshold`) dostosowuje próg wykrywania do bieżącego poziomu
  tła, dzięki czemu detektor reaguje zarówno na głośne, jak i ciche
  sygnały.  Parametry `--dyn_strength` i `--dyn_smoothing` pozwalają
  regulować siłę i szybkość adaptacji.
* **Możliwość wykrywania innych dźwięków** – opcja `--other`
  włącza trzecią klasę zdarzeń („inne”), wyzwalaną przy amplitudach
  poniżej progu kroków i strzałów.  Parametr `--other_factor` określa,
  o ile niższy powinien być próg dla tych dźwięków.
* **Tester źródła (`--test_source`)** – jednosekundowy odczyt RMS
  pozwala sprawdzić, czy wybrane urządzenie rzeczywiście przekazuje
  dźwięk do programu.  Wynik jest wyświetlany w konsoli i logu.
* **Skanowanie urządzeń (`--scan_devices`)** – automatyczna selekcja
  urządzenia o największym sygnale przy starcie programu.  Funkcja ta
  jest pomocna, gdy domyślne urządzenie nie jest poprawne.

### Uruchomienie

1. **Instalacja** – do działania programu wymagany jest Python 3.11,
   biblioteka `pyaudiowpatch` oraz `pygame`.  Wszystkie zależności
   instalowane są automatycznie przez skrypt `RUN_BUILD_ALL.cmd`.
2. **Wykrycie urządzeń** – przed uruchomieniem interfejsu można
   sprawdzić dostępne urządzenia komendą:

   ```cmd
   RUN_BUILD_ALL.cmd --list_devices
   ```

3. **Uruchomienie z UI** – przykładowo, dla 6‑kanałowego strumienia
   (tryb 5.1) przy częstotliwości 48 kHz:

   ```cmd
   RUN_BUILD_ALL.cmd --channels 6 --rate 48000 --auto_threshold
   ```

   Program otworzy okno z radarem i panel sterowania.  W polu
   „Urządzenie” można wybrać źródło dźwięku (np. „What U Hear” albo
   „Stereo Mix”) – zmiana jest natychmiastowa.  Parametry
   „Próg”, „Siła” i „Wygładzenie” sterują detektorem, zaś
   przełączniki pozwalają włączać adaptacyjny próg, wyświetlanie
   ramki radarowej oraz wykrywanie cichych dźwięków.

4. **Tryb testowy** – aby zweryfikować sygnał z konkretnego
   urządzenia, użyj opcji:

   ```cmd
   RUN_BUILD_ALL.cmd --device_index 3 --channels 6 --rate 48000 --test_source
   ```

   Wynik średniego RMS z jednosekundowej próbki zostanie wypisany w logu
   i na konsoli.  Jeśli RMS jest bardzo niski, dźwięk z urządzenia
   prawdopodobnie nie jest przechwytywany (np. mikser jest wyciszony).

5. **Zmiana wielkości okna** – użyj `--width` i `--height`, aby
   zainicjować program w żądanym rozmiarze, lub po prostu przeciągnij
   rogi okna.  Szerokość panelu sterowania można powiększyć parametrem
   `--controls_width` (domyślnie 240 px) — większa wartość pozostawi
   więcej miejsca na suwaki, przełączniki i selektor urządzeń.

### Obsługa

Wszystkie opcje wiersza poleceń są szczegółowo opisane w pliku
`main.py` (funkcja `parse_args`).  Dziennik zdarzeń zapisywany jest
do pliku `logs/log.txt`.  W przypadku problemów z przechwytywaniem
dźwięku uruchom program z `--debug_rms` oraz `--test_source`, by
zebrać dodatkowe informacje diagnostyczne.

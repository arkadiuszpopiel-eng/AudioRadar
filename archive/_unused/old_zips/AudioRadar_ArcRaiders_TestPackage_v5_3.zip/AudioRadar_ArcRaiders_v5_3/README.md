# Audio Radar (Arc Raiders) — Test Package v5.3

Jeden log (`logs/log.txt`), auto‑detekcja rate/channels, kalibracja `--calibrate`, cache ostatnich ustawień.

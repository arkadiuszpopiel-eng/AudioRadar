import json, numpy as np, threading, logging
from typing import Any, Optional, Tuple, List
from pathlib import Path
try:
    import pyaudiowpatch as pyaudio
except Exception:
    pyaudio = None
CACHE_FILE = Path("cache/last_device.json")
def _normalize_index(candidate: Any) -> Optional[int]:
    try:
        if candidate is None: return None
        if isinstance(candidate, int): return int(candidate)
        if isinstance(candidate, float): return int(candidate)
        if isinstance(candidate, str): return int(candidate.strip())
        if isinstance(candidate, (tuple, list)) and candidate: return _normalize_index(candidate[0])
        if isinstance(candidate, dict):
            for k in ("index","device_index","id"):
                if k in candidate: return _normalize_index(candidate[k])
        return int(candidate)
    except Exception: return None
def _load_cache():
    try:
        with open(CACHE_FILE,"r",encoding="utf-8") as f: return json.load(f)
    except Exception: return {}
def _save_cache(data: dict):
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CACHE_FILE,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
    except Exception: pass
class AudioCapturer:
    def __init__(self, rate:int, channels:int, buffer_ms:int, logger:logging.Logger, device_index:int|None=None):
        self.req_rate=rate; self.req_channels=channels; self.buffer_ms=buffer_ms; self.logger=logger
        self._running=False; self._thread=None; self._pa=None; self._stream=None; self._device_override=device_index
        self.rate=rate; self.channels=channels
    def _list_devices(self, pa):
        rows=[]; 
        for i in range(pa.get_device_count()):
            info=pa.get_device_info_by_index(i)
            rows.append((i, info.get("name",""), info.get("hostApi"), info.get("maxInputChannels")))
        return rows
    def _find_device(self, pa):
        cache=_load_cache()
        if self._device_override is not None: return _normalize_index(self._device_override)
        last=_normalize_index(cache.get("device_index"))
        if last is not None: return last
        idx=None
        try: idx=_normalize_index(pa.get_default_wasapi_loopback())
        except Exception as e: self.logger.debug("get_default_wasapi_loopback failed: %s", e)
        if idx is not None: return idx
        for i in range(pa.get_device_count()):
            info=pa.get_device_info_by_index(i); name=(info.get("name","") or "").lower()
            if "loopback" in name or "stereo mix" in name or "what u hear" in name: return i
        return None
    def _probe_formats(self, pa, device_index:int)->Tuple[int,int,list[tuple[int,int,bool]]]:
        candidates_rate=[]; 
        if self.req_rate not in (None,0): candidates_rate.append(int(self.req_rate))
        for r in (48000,44100,96000,192000):
            if r not in candidates_rate: candidates_rate.append(r)
        chan_candidates=[]; 
        if self.req_channels not in (None,0): chan_candidates.append(int(self.req_channels))
        if 2 not in chan_candidates: chan_candidates.append(2)
        diags=[]; chosen_rate=None; chosen_ch=None
        for ch in chan_candidates:
            for rate in candidates_rate:
                ok=False
                try:
                    ok=pa.is_format_supported(rate, input_device=device_index, input_channels=ch, input_format=pyaudio.paInt16)
                except Exception: ok=False
                diags.append((rate,ch,bool(ok)))
                if ok and chosen_rate is None: chosen_rate, chosen_ch = rate, ch
            if chosen_rate is not None: break
        if chosen_rate is None: chosen_rate=self.req_rate; chosen_ch=self.req_channels
        return chosen_rate, chosen_ch, diags
    def start(self, callback):
        if self._running: return
        if pyaudio is None: self.logger.warning("PyAudioWPatch nie jest zainstalowany — brak przechwytywania audio."); return
        self._pa=pyaudio.PyAudio()
        devs=self._list_devices(self._pa); self.logger.info("Lista urzadzen audio: %s", devs)
        idx=self._find_device(self._pa)
        if idx is None: self.logger.error("Nie znaleziono urzadzenia loopback (Stereo Mix/What U Hear)."); return
        try:
            info=self._pa.get_device_info_by_index(idx); self.logger.info("Wybrano device_index=%s name=%s", idx, info.get("name","?"))
        except Exception: self.logger.info("Wybrano device_index=%s (nazwa nieznana)", idx)
        rate,ch,diags=self._probe_formats(self._pa, idx); self.logger.info("Probe format results: %s", diags)
        if rate is None or ch is None: self.logger.error("Zaden testowany format nie jest wspierany."); return
        self.rate=int(rate); self.channels=int(ch); frames=max(64, int(self.rate*self.buffer_ms/1000))
        self.logger.info("Uzywam rate=%s Hz, channels=%s, frames_per_buffer=%s", self.rate, self.channels, frames)
        _save_cache({"device_index": idx, "rate": self.rate, "channels": self.channels})
        self._stream=self._pa.open(format=pyaudio.paInt16, channels=self.channels, rate=self.rate, input=True, frames_per_buffer=frames, input_device_index=idx)
        self._running=True
        def _run():
            self.logger.info("Loopback START idx=%s rate=%s ch=%s buf=%s", idx, self.rate, self.channels, frames)
            while self._running:
                try:
                    data=self._stream.read(frames, exception_on_overflow=False)
                    frame=np.frombuffer(data, dtype=np.int16).reshape(-1, self.channels); callback(frame)
                except Exception as e: self.logger.exception("Loopback error: %s", e)
            self.logger.info("Loopback STOP")
        import threading; self._thread=threading.Thread(target=_run, daemon=True); self._thread.start()
    def stop(self):
        self._running=False
        try:
            if self._thread: self._thread.join(timeout=1.0)
        except Exception: pass
        try:
            if self._stream: self._stream.stop_stream(); self._stream.close()
        except Exception: pass
        try:
            if self._pa: self._pa.terminate()
        except Exception: pass

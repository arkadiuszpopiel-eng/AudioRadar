import numpy as np, time, logging
try:
    import pyaudiowpatch as pyaudio
except Exception:
    pyaudio = None
def _tone(freq, duration, rate):
    t = np.linspace(0, duration, int(rate*duration), endpoint=False, dtype=np.float32)
    return (0.2*np.sin(2*np.pi*freq*t)).astype(np.float32)
def run_calibration(logger: logging.Logger, rate_hint=48000, channels=2, duration=0.25):
    if pyaudio is None:
        logger.error("Kalibracja niedostepna: brak pyaudiowpatch (output)."); return 1
    pa = pyaudio.PyAudio(); tried=[]
    for rate in (rate_hint, 48000, 44100, 96000):
        try:
            stream = pa.open(format=pyaudio.paFloat32, channels=channels, rate=rate, output=True)
            logger.info("Kalibracja: otwarto wyjscie rate=%s ch=%s", rate, channels)
            names = {2:["FL","FR"], 6:["FL","FR","C","LFE","SL/RL","SR/RR"], 8:["FL","FR","C","LFE","SL","SR","RL","RR"]}.get(channels, [f"CH{i}" for i in range(channels)])
            for ch_idx, name in enumerate(names):
                sig = _tone(800 if ch_idx%2==0 else 1200, duration, rate)
                frame = np.zeros((sig.shape[0], channels), dtype=np.float32)
                frame[:, ch_idx % channels] = sig
                logger.info("Ping kanalu %s (idx=%s)...", name, ch_idx)
                stream.write(frame.tobytes()); time.sleep(0.15)
            stream.stop_stream(); stream.close(); pa.terminate(); logger.info("Kalibracja: zakonczona."); return 0
        except Exception as e:
            tried.append((rate, str(e))); continue
    logger.error("Kalibracja: nie udalo sie otworzyc zadnego wyjscia. Proby: %s", tried)
    try: pa.terminate()
    except Exception: pass
    return 2

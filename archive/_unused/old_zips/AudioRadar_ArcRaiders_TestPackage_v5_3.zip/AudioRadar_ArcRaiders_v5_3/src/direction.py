import numpy as np
CHANNEL_ANGLES = {2:{0:-45.0,1:45.0}, 6:{0:-30.0,1:30.0,2:0.0,4:-120.0,5:120.0}, 8:{0:-30.0,1:30.0,2:0.0,4:-90.0,5:90.0,6:-150.0,7:150.0}}
IGNORE = {6:(3,), 8:(3,)}
def estimate_angle(frame: np.ndarray) -> float:
    if frame.ndim!=2: return 0.0
    ch = frame.shape[1]
    mapping = CHANNEL_ANGLES.get(ch, CHANNEL_ANGLES[2])
    ignore = set(IGNORE.get(ch, ()))
    e = np.sqrt(np.mean(frame.astype(np.float32)**2, axis=0))
    s = float(np.sum(e)); 
    if s==0: return 0.0
    w = e/s
    ang = 0.0; ws=0.0
    for idx,a in mapping.items():
        if idx in ignore or idx>=len(w): continue
        ang += a*float(w[idx]); ws += float(w[idx])
    return ang/ws if ws>0 else 0.0

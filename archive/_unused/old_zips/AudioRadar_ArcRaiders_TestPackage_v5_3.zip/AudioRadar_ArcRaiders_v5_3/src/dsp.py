import time, numpy as np, math
def _amp_to_visual_scale(rms: float) -> float:
    x = max(1e-6, min(1.0, rms))
    return math.log10(1 + 9*x)
class EventDetector:
    def __init__(self, threshold: float, cooldown: float=0.2):
        self.threshold=threshold; self.cooldown=cooldown; self._last=0.0
    def process(self, frame: np.ndarray):
        x = frame.astype(np.float32).reshape(-1)
        rms = float(np.sqrt(np.mean(x*x)))/32768.0
        now = time.monotonic()
        if rms < self.threshold or (now-self._last) < self.cooldown:
            return None
        self._last = now
        kind = "shot" if rms > self.threshold*3 else "step"
        return kind, _amp_to_visual_scale(rms)

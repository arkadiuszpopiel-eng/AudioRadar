import pygame, math, time, collections
class RadarDisplay:
    def __init__(self, size=(500,500), debug=False):
        pygame.init(); self.screen = pygame.display.set_mode(size); self.clock=pygame.time.Clock()
        self.center=(size[0]//2, size[1]//2); self.r=int(min(size)*0.4); self.debug=debug
        self.markers=collections.deque(); self.life=1.2
    def add_marker(self, angle, kind, amp):
        self.markers.append({"a":angle%360.0, "k":kind, "amp":max(0.02,min(1.0,amp)), "t":time.monotonic()})
    def _bg(self):
        self.screen.fill((10,10,12))
        pygame.draw.circle(self.screen,(70,70,90),self.center,self.r,2)
        for d in (0,90,180,270):
            x=self.center[0]+int(self.r*math.sin(math.radians(d)))
            y=self.center[1]-int(self.r*math.cos(math.radians(d)))
            pygame.draw.line(self.screen,(60,60,80),self.center,(x,y),1)
    def update(self):
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT: return False
        self._bg(); now=time.monotonic()
        for _ in range(len(self.markers)):
            m=self.markers[0]; age=now-m["t"]
            if age>self.life: self.markers.popleft(); continue
            fade=1.0-age/self.life
            rad=math.radians(m["a"])
            x=self.center[0]+int(self.r*math.sin(rad))
            y=self.center[1]-int(self.r*math.cos(rad))
            col=(255,80,80) if m["k"]=="shot" else (80,160,255)
            size=max(4,int(12*m["amp"]*fade))
            s=pygame.Surface((size*2,size*2), pygame.SRCALPHA)
            s.fill((0,0,0,0))
            pygame.draw.circle(s, (*col,int(220*fade)), (size,size), size)
            self.screen.blit(s,(x-size,y-size))
            self.markers.rotate(-1)
        pygame.display.flip(); self.clock.tick(60); return True

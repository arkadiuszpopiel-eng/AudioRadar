# Audio Radar (Arc Raiders) — Test Package v5.4

Headless mode + auto-fallback when Pygame init fails; single unified log.

@echo off
setlocal ENABLEDELAYEDEXPANSION
set "SCRIPT_DIR=%~dp0"
pushd "%SCRIPT_DIR%"
if not exist "logs" mkdir logs
if not exist "data" mkdir data
if not exist "cache" mkdir cache
set "LOG=logs\log.txt"
if not exist "%LOG%" type nul > "%LOG%"
echo [%date% %time%] RUN_BUILD_ALL v5.4: init >> "%LOG%"
where py >nul 2>nul
if %errorlevel%==0 ( set PY_CMD=py ) else ( set PY_CMD=python )
if not exist ".venv" (
  echo [%date% %time%] Tworzenie .venv... >> "%LOG%"
  %PY_CMD% -m venv .venv >> "%LOG%" 2>&1
  if errorlevel 1 ( echo [%date% %time%] [ERROR] venv >> "%LOG%" & exit /b 1 )
)
call .venv\Scripts\activate.bat >> "%LOG%" 2>&1
if errorlevel 1 ( echo [%date% %time%] [ERROR] activate venv >> "%LOG%" & exit /b 1 )
python -m pip install --upgrade pip >> "%LOG%" 2>&1
echo [%date% %time%] Instalacja zaleznosci... >> "%LOG%"
pip install -r requirements.txt >> "%LOG%" 2>&1
if errorlevel 1 ( echo [%date% %time%] [ERROR] pip install >> "%LOG%" & exit /b 1 )
echo [%date% %time%] Uruchamianie aplikacji... >> "%LOG%"
python src\main.py %*
set RC=%ERRORLEVEL%
echo [%date% %time%] Aplikacja zakonczona RC=%RC% >> "%LOG%"
exit /b %RC%
popd
endlocal

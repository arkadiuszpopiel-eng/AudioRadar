import argparse, sys, queue, traceback, time
from logger_setup import setup_logger
from audio_loopback import AudioCapturer
from dsp import EventDetector
from direction import estimate_angle
def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("--rate", type=int, default=48000)
    p.add_argument("--channels", type=int, default=2, choices=[2,6,8])
    p.add_argument("--buffer_ms", type=int, default=20)
    p.add_argument("--threshold", type=float, default=0.12)
    p.add_argument("--device_index", type=str, default=None, help="Wymus indeks urzadzenia loopback (int)")
    p.add_argument("--log", type=str, default="logs/log.txt")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--calibrate", action="store_true", help="Uruchom generator pingow (stereo/5.1/7.1)")
    p.add_argument("--headless", action="store_true", help="Bez okna Pygame (log-only)")
    return p.parse_args()
def main():
    args = parse_args()
    logger = setup_logger(args.log, args.debug)
    logger.info("=== Audio Radar START (v5.4) === cfg: rate=%s ch=%s buf=%sms thr=%.3f device_index=%s calibrate=%s headless=%s",
                args.rate, args.channels, args.buffer_ms, args.threshold, args.device_index, args.calibrate, args.headless)
    if args.calibrate:
        try:
            from calibrate import run_calibration
            rc = run_calibration(logger, rate_hint=args.rate, channels=args.channels)
            if rc != 0: logger.warning("Kalibracja kod=%s", rc)
        except Exception: logger.exception("Kalibracja nie powiodla sie:")
    radar=None
    if not args.headless:
        try:
            import pygame
            from viz import RadarDisplay
            radar = RadarDisplay(size=(500,500), debug=args.debug)
            logger.info("UI: Pygame okno uruchomione.")
        except Exception:
            logger.exception("UI: inicjalizacja Pygame nie powiodla sie — przechodze w tryb headless.")
            radar=None
    import numpy as np, queue
    det = EventDetector(threshold=args.threshold, cooldown=0.2)
    q = queue.Queue()
    def on_frame(frame: 'np.ndarray'):
        ev = det.process(frame)
        if ev:
            kind, amp_scaled = ev
            angle = estimate_angle(frame)
            try: q.put_nowait((kind, angle, amp_scaled))
            except queue.Full: pass
            logger.debug("EVENT kind=%s amp(vis)=%.3f angle=%.1f", kind, amp_scaled, angle)
    cap = AudioCapturer(rate=args.rate, channels=args.channels, buffer_ms=args.buffer_ms, logger=logger,
                        device_index=args.device_index)
    cap.start(on_frame)
    try:
        if radar is None:
            logger.info("Tryb: HEADLESS (bez okna). Zdarzenia beda logowane do pliku.")
            while True:
                try:
                    while True:
                        kind, angle, amp = q.get_nowait()
                        logger.info("EVENT: %-5s | angle=%6.1f | amp(vis)=%.3f", kind, angle, amp)
                except queue.Empty:
                    pass
                time.sleep(0.01)
        else:
            while True:
                try:
                    while True:
                        kind, angle, amp = q.get_nowait()
                        radar.add_marker(angle, kind, amp)
                except queue.Empty:
                    pass
                if not radar.update(): break
    except KeyboardInterrupt:
        logger.info("Przerwano przez uzytkownika.")
    except Exception:
        logger.exception("Nieobsluzony blad glownej petli:")
        return 2
    finally:
        try: cap.stop()
        except Exception: pass
        if radar is not None:
            try:
                import pygame
                pygame.quit()
            except Exception: pass
        logger.info("=== Audio Radar STOP ===")
    return 0
if __name__=="__main__":
    raise SystemExit(main())

AudioRadar — v5.1.3 (full, robust launcher)
===============================================
Zmiany vs 5.1.2: lepszy START_HERE.bat, top-level RUN_AUDIO_RADAR.bat, logi obok EXE.
Data: 2025-10-30T19:32:55
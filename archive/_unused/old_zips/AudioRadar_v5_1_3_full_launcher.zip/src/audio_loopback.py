import pyaudiowpatch as pyaudio
def list_devices():
    pa = pyaudio.PyAudio(); out = []
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        out.append((i, info.get('name'), info.get('hostApi'), info.get('maxInputChannels')))
    pa.terminate(); return out
def find_best_device(devices):
    for i, name, _, maxin in devices:
        if maxin and name and 'What U Hear' in name: return i
    for i, name, _, maxin in devices:
        if maxin and name and 'Loopback' in name: return i
    for i, name, _, maxin in devices:
        if maxin and name: return i
    return None
class LoopbackCapture:
    def __init__(self, device_index=None, channels=2):
        self.device_index = device_index; self.channels = channels
        self._pa = pyaudio.PyAudio(); self._stream=None
    def is_supported(self, rate, fmt=pyaudio.paInt16):
        try:
            return self._pa.is_format_supported(rate, input_device=self.device_index, input_channels=self.channels, input_format=fmt)
        except Exception:
            return False
    def probe_rates(self, candidates):
        results=[]
        for r in candidates: results.append((r, bool(self.is_supported(r))))
        if not any(ok for _, ok in results):
            info = self._pa.get_device_info_by_index(self.device_index)
            default_rate = int(info.get('defaultSampleRate', 44100)) or 44100
            results.append((default_rate, True))
        return results
    def auto_select_rate(self, candidates):
        for r in candidates:
            if self.is_supported(r): return r
        info = self._pa.get_device_info_by_index(self.device_index)
        return int(info.get('defaultSampleRate', 44100)) or 44100
    def start(self, callback, rate=48000, frames_per_buffer=None, logger=None):
        if frames_per_buffer is None: frames_per_buffer = max(256, int(rate*0.02))
        if not self.is_supported(rate):
            rate = self.auto_select_rate([48000, 44100, 96000, 192000])
            if logger: logger.info('Requested rate unsupported; auto-selected rate=%s', rate)
        self._stream = self._pa.open(format=pyaudio.paInt16, channels=self.channels, rate=rate, input=True, input_device_index=self.device_index, frames_per_buffer=frames_per_buffer, stream_callback=lambda in_data, frame_count, time_info, status: (callback(in_data, rate, self.channels) or (None, pyaudio.paContinue))[-1])
        if logger: logger.info('Stream opened: device_index=%s, channels=%s, rate=%s, fpb=%s', self.device_index, self.channels, rate, frames_per_buffer)
        self._stream.start_stream()
    def stop(self):
        try:
            if self._stream is not None:
                self._stream.stop_stream(); self._stream.close()
        finally:
            self._pa.terminate()

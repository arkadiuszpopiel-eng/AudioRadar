import os, sys, logging, logging.handlers, time
def _base_dir():
    return os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
def init_logging():
    base = os.path.join(_base_dir(), 'logs') if getattr(sys, 'frozen', False) else os.path.join(_base_dir(), 'portable', 'logs')
    os.makedirs(base, exist_ok=True)
    log_path = os.path.join(base, f'session_{time.strftime('%Y%m%d_%H%M%S')}.log')
    logger = logging.getLogger('audioradar'); logger.setLevel(logging.INFO)
    fh = logging.handlers.RotatingFileHandler(log_path, maxBytes=2*1024*1024, backupCount=5, encoding='utf-8')
    fh.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-8s | audioradar | %(message)s'))
    logger.addHandler(fh)
    ch = logging.StreamHandler(); ch.setFormatter(logging.Formatter('[%(levelname)s] %(message)s'))
    logger.addHandler(ch)
    logger.info('Logger initialized. session_log=%s', log_path)
    return logger, base

import argparse, sys, os, time, json
from logging_setup import init_logging
from audio_loopback import LoopbackCapture, list_devices, find_best_device
def on_frame(audio_bytes, rate, channels): return None
def selftest(logdir):
    try:
        with open(os.path.join(logdir, 'selftest.log'), 'w', encoding='utf-8') as f: f.write('SELFTEST_OK\n'); return True
    except Exception: return False
def main():
    logger, logdir = init_logging()
    ap = argparse.ArgumentParser(); ap.add_argument('--device-index', type=int, default=None); ap.add_argument('--rate', type=int, default=None); ap.add_argument('--selftest', action='store_true'); args = ap.parse_args()
    if args.selftest: return 0 if selftest(logdir) else 1
    devices = list_devices(); logger.info('Devices: %s', devices)
    dev_idx = args.device_index if args.device_index is not None else find_best_device(devices); logger.info('Selected device_index=%s', dev_idx)
    cap = LoopbackCapture(device_index=dev_idx, channels=2)
    candidates = [48000, 44100, 96000, 192000]; probe = cap.probe_rates(candidates)
    with open(os.path.join(logdir, 'device_probe.json'), 'w', encoding='utf-8') as f: json.dump({'device_index': dev_idx, 'candidates': candidates, 'results': [{'rate': r, 'ok': ok} for r, ok in probe]}, f, indent=2)
    rate = args.rate if args.rate is not None else (next((r for r, ok in probe if ok), cap.auto_select_rate(candidates)))
    logger.info('=== AudioRadar START v5.1.3 === device=%s rate=%s', dev_idx, rate)
    try:
        cap.start(on_frame, rate=rate, logger=logger); t0=time.time();
        while time.time()-t0<5.0: time.sleep(0.05)
    finally:
        cap.stop(); logger.info('AudioRadar STOP')
    return 0
if __name__=='__main__': sys.exit(main())

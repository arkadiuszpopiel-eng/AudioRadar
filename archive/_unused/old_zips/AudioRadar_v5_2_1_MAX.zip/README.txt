
AudioRadar — v5.2.1 (MAX+)
===========================
- Naprawiony RADAR (QPointF w rysowaniu, brak crashy).
- Soft-GL (wymuszone renderowanie programowe Qt).
- VU + RMS + TEST TONE (1 kHz, 3s) + List Devices.
- Fallback PyAudio → sounddevice, auto-rate, wymuszenie stereo dla 'What U Hear/Loopback'.
- Suwak SENSITIVITY (0.5x…4x) — wzmacnia reakcję Radaru przy cichych sygnałach.
- Płynny 'decay' blipa, żeby wizualizacja nie gasła zbyt agresywnie.
Build time: 2025-11-02 17:29:56

Start:
1) RUN_BUILD_ALL.cmd
2) RUN_AUDIO_RADAR.bat

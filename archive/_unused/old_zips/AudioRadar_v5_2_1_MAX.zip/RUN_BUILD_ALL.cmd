
@echo off
setlocal
set LOG=build.log
echo %date% %time% | more > "%LOG%"
echo [INFO] RUN_BUILD_ALL v5.2.1 >> "%LOG%"
if not exist .venv py -3.11 -m venv .venv >> "%LOG%" 2>&1
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip wheel setuptools >> "%LOG%" 2>&1
pip install -r requirements.txt >> "%LOG%" 2>&1
if not exist portable mkdir portable
if not exist portable\logs mkdir portable\logs
python tools\syntax_check.py >> "%LOG%" 2>&1
if not %errorlevel%==0 ( type "%LOG%" & exit /b 2 )
if exist build rmdir /s /q build >> "%LOG%" 2>&1
if exist dist rmdir /s /q dist >> "%LOG%" 2>&1
pyinstaller build.spec --noconfirm --clean >> "%LOG%" 2>&1
robocopy dist\AudioRadar portable /e >> "%LOG%" 2>&1
(
  echo @echo off
  echo setlocal
  echo set QT_OPENGL=software
  echo set QT_QUICK_BACKEND=software
  echo set QT_ANGLE_PLATFORM=d3d11
  echo pushd "%%~dp0"
  echo set EXE=AudioRadar.exe
  echo if not exist "%%CD%%\%%EXE%%" ^(
  echo   echo [ERR] Nie znaleziono "%%CD%%\%%EXE%%"
  echo   dir
  echo   pause
  echo   popd
  echo   exit /b 1
  echo ^)
  echo "%%CD%%\%%EXE%%" %%*
  echo set RC=%%errorlevel%%
  echo popd
  echo exit /b %%RC%%
) > portable\START_HERE.bat
(
  echo @echo off
  echo setlocal
  echo set QT_OPENGL=software
  echo set QT_QUICK_BACKEND=software
  echo set QT_ANGLE_PLATFORM=d3d11
  echo cd /d "%%~dp0"
  echo if exist "portable\AudioRadar.exe" ^(
  echo   start "" "portable\AudioRadar.exe" %%*
  echo   exit /b !errorlevel!
  echo ^) else ^(
  echo   echo [ERR] Brak portable\AudioRadar.exe
  echo   dir portable
  echo   exit /b 2
  echo ^)
) > RUN_AUDIO_RADAR.bat
pushd portable
AudioRadar.exe --selftest >> "..\%LOG%" 2>&1
popd
echo DONE >> "%LOG%"
type "%LOG%"
exit /b 0

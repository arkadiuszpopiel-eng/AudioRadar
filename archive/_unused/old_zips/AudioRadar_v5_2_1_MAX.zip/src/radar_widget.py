
from PyQt5 import QtWidgets, QtGui, QtCore
import math

class RadarWidget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self._angle = 0.0
        self._level = 0.0     # aktualny wyświetlany poziom (z wygaszaniem)
        self._sens  = 1.0     # czułość
        self._decay = 0.92    # współczynnik zaniku na klatkę
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(33)  # ~30 FPS
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def setSensitivity(self, s: float):
        self._sens = max(0.5, min(4.0, float(s)))

    def setLevel(self, lvl: float):
        if lvl is None:
            lvl = 0.0
        lvl = max(0.0, min(1.0, float(lvl)))
        # wzmocnienie + SQRT dla cichych sygnałów
        target = math.sqrt(lvl * self._sens)
        self._level = max(target, self._level * self._decay)

    def _tick(self):
        self._angle = (self._angle + 2.0) % 360.0
        self.update()

    def sizeHint(self):
        return QtCore.QSize(380, 380)

    def paintEvent(self, ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)

        r = float(min(self.width(), self.height()) - 10)
        cx = float(self.width()) / 2.0
        cy = float(self.height()) / 2.0
        rad = r / 2.0

        # tło
        p.fillRect(self.rect(), QtGui.QColor(10, 15, 20))

        # siatka
        grid_pen = QtGui.QPen(QtGui.QColor(70, 90, 110))
        grid_pen.setWidth(1)
        p.setPen(grid_pen)
        for k in range(1, 5):
            rr = rad * k / 4.0
            p.drawEllipse(QtCore.QPointF(cx, cy), rr, rr)

        # osie
        p.drawLine(QtCore.QPointF(cx - rad, cy), QtCore.QPointF(cx + rad, cy))
        p.drawLine(QtCore.QPointF(cx, cy - rad), QtCore.QPointF(cx, cy + rad))

        # wskazówka
        angle = self._angle
        beam_pen = QtGui.QPen(QtGui.QColor(120, 220, 255))
        beam_pen.setWidth(2)
        p.setPen(beam_pen)
        x2 = cx + rad * math.cos(math.radians(angle))
        y2 = cy - rad * math.sin(math.radians(angle))
        p.drawLine(QtCore.QPointF(cx, cy), QtCore.QPointF(x2, y2))

        # blip z zależnym rozmiarem i alfa
        lvl = max(0.0, min(1.0, self._level))
        blip_r = 8.0 + 40.0 * lvl
        blip_color = QtGui.QColor(90, 255, 120, int(80 + 160 * lvl))
        p.setBrush(blip_color)
        p.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 0)))
        bx = cx + (rad * 0.65) * math.cos(math.radians(angle))
        by = cy - (rad * 0.65) * math.sin(math.radians(angle))
        p.drawEllipse(QtCore.QPointF(bx, by), blip_r, blip_r)

AudioRadar v6.0 (Classification & DOA)
=====================================

This package contains the full source code and build scripts for the
AudioRadar project. Starting with version 6.0 the application not
only displays the raw audio level but also **classifies** short
segments of audio as footsteps, running or gunshots and estimates the
direction from which each sound arrives. Detected events are drawn as
colour‑coded blips on a radar, fading over time. The radar sweeper
continues to run, giving a visual context of direction.

Features
--------

* **Real‑time event classification** – every captured audio block is
  analysed using simple heuristics to distinguish between
  *footsteps*, *running* and *gunshots*. The classifier uses the
  root‑mean‑square (RMS) level and the spectral centroid to
  differentiate between low‑frequency footsteps, mid‑level running
  sounds and high‑energy gunshots.
* **Direction of arrival (DOA) estimation** – for stereo loopback
  devices, the program computes the time delay between the left and
  right channels using a GCC‑PHAT cross‑correlation. This delay is
  converted to an arrival angle between –90° (hard left) and 90°
  (hard right). The direction is used to place event blips on the
  radar.
* **Control Tab** – choose an input device, sample rate, I/O mode
  (callback or polling), and buffer size. View a live VU meter and RMS
  level, start/stop the stream, list available devices, and play a test
  tone to verify audio routing.
* **Radar Tab** – watch a radar sweeper in the centre of the screen.
  Detected events appear as colour‑coded blips: green for footsteps,
  orange for running and red for gunshots. Blips fade over 1.5 seconds.
  A sensitivity slider scales the marker brightness.
* **Fallback** – uses PyAudio (pyaudiowpatch) by default and falls
  back to sounddevice if PyAudio fails. Automatically clamps channel
  counts for loopback devices and selects a supported sample rate.
* **Robust logging** – logs live to `portable\logs\session_*.log` and
  prints messages in the GUI. A global exception hook ensures that
  unexpected errors are logged and displayed.

Usage
-----

### Building (Windows)

1. Install Python 3.11 or later on your system.
2. Extract this archive to a directory without spaces.
3. Open a Command Prompt and change into the extracted directory.
4. Run `RUN_BUILD_ALL.cmd`. This script creates a virtual environment,
   installs dependencies, runs a syntax check, builds the executable
   using PyInstaller, runs a self-test, and copies the build into
   the `portable` folder.
5. After the build completes, run `RUN_AUDIO_RADAR.bat` to launch
   the application. When the radar window appears, click **START**
   in the *Control* tab. When a sound event is detected, a message
   will be logged in the log pane and a coloured blip will appear
   on the radar in the direction of the sound.

### Running from source (non‑Windows)

If you are using Linux or macOS, or simply want to run from source
without freezing, you can install dependencies and run the script
directly:

```
python3 -m pip install -r requirements.txt
python3 -m pip install pyaudiowpatch sounddevice PyQt5 numpy
python3 src/main.py
```

Be aware that capturing loopback audio varies by platform. On Linux
you may need to use PulseAudio monitor sources instead of the
"What U Hear" device.

### Notes

* Log files are created under `portable\logs` when run from an
  executable. When running from source, log files are stored in
  `portable/logs` relative to the project root.
* The test tone generator uses `sounddevice` to play a 1 kHz sine
  wave for three seconds on the default output. This is useful for
  confirming that your loopback device is configured correctly.

For bug reports or suggestions, feel free to edit and submit issues
against this project. Enjoy!
@echo off
REM -----------------------------------------------------------------------------
REM Convenience launcher for the built AudioRadar executable. This batch file
REM simply invokes the executable in the portable folder. Use it after
REM running RUN_BUILD_ALL.cmd to test the application.
REM -----------------------------------------------------------------------------

cd /d %~dp0\portable
if not exist AudioRadar.exe (
    echo AudioRadar.exe not found. Please run RUN_BUILD_ALL.cmd first.
    exit /b 1
)
AudioRadar.exe %*
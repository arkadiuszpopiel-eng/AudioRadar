"""PyInstaller spec file for AudioRadar.

This spec defines how to bundle the AudioRadar application into a single
folder using PyInstaller. It includes the entire `src` directory as a
data tree so that any runtime resources (like default settings) are
available. The bundled executable is named `AudioRadar` and runs
`src/main.py` as its entry point.
"""
import sys
from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

# The main script to bundle
a = Analysis([
    'src/main.py',
],
    pathex=[],
    binaries=[],
    datas=[('src', 'src')],
    hiddenimports=collect_submodules('pyaudiowpatch') + collect_submodules('sounddevice'),
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='AudioRadar',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    icon=None,
)
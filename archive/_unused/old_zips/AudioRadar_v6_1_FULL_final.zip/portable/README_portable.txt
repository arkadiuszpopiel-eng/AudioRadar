This directory will contain the frozen build of AudioRadar after running
RUN_BUILD_ALL.cmd.  The build script copies the PyInstaller output
into `portable`, places log files under `portable\logs` and creates
start scripts. You can run `AudioRadar.exe` or `START_HERE.bat` from
this directory when using Windows.
"""
Low level audio backends for capturing audio from the default or user
selected device. This module provides wrappers around both PyAudio
(`pyaudiowpatch`) and `sounddevice`, offering a consistent interface
for starting and stopping audio streams as well as capturing a simple
RMS level estimate on the fly.

The LevelBuffer class provides a queue-like structure that drops older
values when the buffer is full. This helps prevent latency build-up
when reading levels in the GUI.

The `list_devices_pyaudio` and `list_devices_sounddevice` functions
enumerate available input devices for each backend, returning tuples
consisting of the index, name and info dictionary.

`prefer_device_index` takes a list of devices and picks a sensible
default. Devices containing "What U Hear" or "Loopback" in the name
receive a preference score. Otherwise, devices with 48 kHz default
sample rates and multiple input channels are preferred.

`normalize_channels` normalises the channel count for certain loopback
devices. Many loopback devices (such as Creative Sound Blaster's
"What U Hear") report six channels even though only the first two
contain meaningful stereo data. To simplify the rest of the application,
we clamp the channel count to two for those devices.
"""
import numpy as _np
import queue
from typing import List, Tuple, Optional

try:
    import pyaudiowpatch as pyaudio
except ImportError:
    pyaudio = None  # type: ignore

try:
    import sounddevice as sd
except ImportError:
    sd = None  # type: ignore


class AudioBackendError(Exception):
    """Base class for audio backend related errors."""


class LevelBuffer:
    """A buffer storing recent level measurements.

    The buffer uses a queue with a limited size. When the buffer is
    full, the oldest element is discarded. Calling `pop_latest` will
    return the most recent element or None if the buffer is empty.
    """

    def __init__(self, maxlen: int = 512):
        self._queue: queue.Queue = queue.Queue(maxsize=maxlen)

    def push(self, val: float) -> None:
        """Push a new level into the queue.

        If the queue is full, drop the oldest sample first.
        Args:
            val (float): Level measurement to add.
        """
        try:
            self._queue.put_nowait(float(val))
        except queue.Full:
            try:
                # Drop one element and retry
                self._queue.get_nowait()
                self._queue.put_nowait(float(val))
            except Exception:
                pass  # Failed to push, ignore

    def pop_latest(self) -> Optional[float]:
        """Return the most recent level sample, discarding intermediate ones."""
        latest = None
        try:
            while True:
                latest = float(self._queue.get_nowait())
        except queue.Empty:
            return latest


def list_devices_pyaudio() -> List[Tuple[int, str, dict]]:
    """List input devices via PyAudio.

    Returns:
        List of tuples containing `(index, name, info)`.
    """
    out: List[Tuple[int, str, dict]] = []
    if not pyaudio:
        return out
    pa = pyaudio.PyAudio()
    try:
        for idx in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(idx)
            out.append((idx, info.get('name', ''), info))
    finally:
        pa.terminate()
    return out


def list_devices_sounddevice() -> List[Tuple[int, str, dict]]:
    """List all devices via sounddevice.

    Returns:
        List of tuples containing `(index, name, info)`.
    """
    out: List[Tuple[int, str, dict]] = []
    if not sd:
        return out
    for idx, device in enumerate(sd.query_devices() or []):
        out.append((idx, device['name'], device))
    return out


def prefer_device_index(devs: List[Tuple[int, str, dict]]) -> Optional[int]:
    """Heuristically choose a default input device.

    Devices containing "What U Hear" or "Loopback" in the name are
    preferred. A higher default sample rate (48 kHz) and more input
    channels also improve the score.

    Args:
        devs: A list of `(index, name, info)` tuples.

    Returns:
        The index of the preferred device, or None if the list is empty.
    """
    best_idx: Optional[int] = None
    best_score = -1
    for idx, name, info in devs:
        score = 0
        if 'What U Hear' in (name or '') or 'Loopback' in (name or ''):
            score += 10
        rate = int(info.get('defaultSampleRate', 44100) or 44100)
        if rate == 48000:
            score += 3
        channels = int(info.get('maxInputChannels', 0) or 0)
        score += min(channels, 2)
        if score > best_score:
            best_score = score
            best_idx = idx
    return best_idx


CANDIDATE_RATES = [48000, 44100, 96000, 192000]


def normalize_channels(name: str, reported_channels: int) -> int:
    """Normalise channel count for loopback devices.

    Many loopback devices on Windows (for example Creative Sound Blaster
    "What U Hear") report 6 or more channels. Only the first two
    actually contain the stereo mix. Clamp to 2 channels for those
    devices. For other devices, cap channels at 2 as well.

    Args:
        name (str): Device name.
        reported_channels (int): Channels reported by the device.

    Returns:
        int: Channel count to use (1 or 2).
    """
    if name and ("What U Hear" in name or "Loopback" in name):
        return 2
    return min(int(reported_channels or 2), 2)


def _rms_i16(buf: bytes) -> float:
    """Compute RMS from a raw 16‑bit little endian audio buffer.

    Args:
        buf: Raw audio bytes. Must be 16‑bit little endian stereo or mono.

    Returns:
        float: RMS level between 0.0 and 1.0.
    """
    if not buf:
        return 0.0
    arr = _np.frombuffer(buf, dtype=_np.int16)
    if arr.size == 0:
        return 0.0
    return float(_np.sqrt(_np.mean((arr.astype(_np.float32) / 32768.0) ** 2)))


class PyAudioInput:
    """Wrapper around PyAudio input stream.

    Handles opening an input stream and pushing RMS values into a LevelBuffer.
    It supports both callback and polling modes.
    """

    def __init__(self,
                 device_index: Optional[int] = None,
                 channels: int = 2,
                 rate: int = 48000,
                 frames_per_buffer: int = 256,
                 level_sink: Optional[LevelBuffer] = None,
                 logger: Optional[any] = None,
                 use_callback: bool = True,
                 frame_sink: Optional[callable] = None) -> None:
        """
        Initialise a PyAudio input stream wrapper.

        Args:
            device_index: Index of the audio input device to open. ``None``
                selects the default system device.
            channels: Number of channels to capture. Loopback devices often
                report six channels but contain only stereo information in
                the first two channels. You can clamp the channel count
                externally using ``normalize_channels``.
            rate: Desired sampling rate in Hz. If unsupported, the backend
                will choose the nearest supported rate from ``CANDIDATE_RATES``.
            frames_per_buffer: Number of frames per buffer. Smaller values
                reduce latency but require more CPU.
            level_sink: Optional ``LevelBuffer`` into which RMS levels will
                be pushed on every callback.
            logger: Optional logging object for diagnostic messages.
            use_callback: When True, PyAudio's callback API is used. If
                False, polling mode is used and the caller should read
                directly from the stream.
            frame_sink: Optional callback that receives a numpy array of
                shape ``(frames, channels)`` with raw audio samples on
                every callback. Use this to perform further processing
                such as feature extraction or direction of arrival
                estimation. When ``use_callback`` is False the caller
                must manually read from the stream and invoke ``frame_sink``.
        """
        if not pyaudio:
            raise AudioBackendError('pyaudiowpatch is not available')
        self._pa = pyaudio.PyAudio()
        self.device_index = device_index
        self.channels = channels
        self.rate = rate
        self.frames_per_buffer = max(frames_per_buffer or 256, 64)
        self.level_sink = level_sink
        self.logger = logger
        self.use_callback = use_callback
        self.frame_sink = frame_sink
        self.stream = None

    def is_supported(self, rate: int) -> bool:
        """Check if the given rate is supported by the selected device."""
        try:
            return self._pa.is_format_supported(
                rate,
                input_device=self.device_index,
                input_channels=self.channels,
                input_format=pyaudio.paInt16
            )
        except Exception:
            return False

    def auto_rate(self) -> int:
        """Choose a working sample rate from common candidate rates."""
        for cand in CANDIDATE_RATES:
            if self.is_supported(cand):
                return cand
        info = self._pa.get_device_info_by_index(self.device_index)
        return int(info.get('defaultSampleRate', 44100) or 44100)

    def start(self) -> None:
        """Open the input stream and begin capturing RMS levels."""
        if not self.is_supported(self.rate):
            self.rate = self.auto_rate()
        callback_fn = None
        if self.use_callback:
            def _callback(in_data, frame_count, time_info, status):
                """Internal PyAudio callback.

                Computes RMS, pushes to level sink and invokes the frame sink.
                ``in_data`` is bytes containing interleaved 16-bit little endian
                samples.
                """
                try:
                    if self.level_sink:
                        self.level_sink.push(_rms_i16(in_data))
                    if self.frame_sink:
                        # Convert bytes to numpy array of shape (frames, channels)
                        import numpy as _np
                        try:
                            buf = _np.frombuffer(in_data, dtype=_np.int16)
                            if buf.size > 0:
                                arr = buf.reshape(-1, self.channels).copy()
                                self.frame_sink(arr, self.rate)
                        except Exception:
                            pass
                    return (None, pyaudio.paContinue)
                except Exception:
                    return (None, pyaudio.paAbort)
            callback_fn = _callback
        try:
            self.stream = self._pa.open(
                format=pyaudio.paInt16,
                channels=self.channels,
                rate=self.rate,
                input=True,
                input_device_index=self.device_index,
                frames_per_buffer=self.frames_per_buffer,
                stream_callback=callback_fn
            )
            self.stream.start_stream()
        except Exception as ex:
            raise AudioBackendError(str(ex)) from ex

    def stop(self) -> None:
        """Stop and close the stream and terminate PyAudio."""
        try:
            if self.stream:
                self.stream.stop_stream()
                self.stream.close()
        finally:
            if self._pa:
                self._pa.terminate()


class SoundDeviceInput:
    """Fallback audio backend using sounddevice library."""

    def __init__(self,
                 device_index: Optional[int] = None,
                 channels: int = 2,
                 rate: int = 48000,
                 frames_per_buffer: int = 256,
                 level_sink: Optional[LevelBuffer] = None,
                 logger: Optional[any] = None,
                 frame_sink: Optional[callable] = None) -> None:
        """
        Fallback audio backend using the ``sounddevice`` library.

        Args:
            device_index: Index of the input device to open. ``None``
                selects the default input device.
            channels: Number of channels to capture (clamped externally via
                ``normalize_channels``). Only the first two channels are
                considered meaningful for stereo loopback devices.
            rate: Desired sampling rate in Hz.
            frames_per_buffer: Number of frames per buffer. Smaller values
                reduce latency but require more CPU.
            level_sink: Optional ``LevelBuffer`` used to collect RMS levels.
            logger: Optional logger for diagnostic messages.
            frame_sink: Optional callback invoked with a numpy array of
                shape ``(frames, channels)`` and the sample rate on each
                callback. Use this to perform feature extraction or
                direction estimation.
        """
        if not sd:
            raise AudioBackendError('sounddevice is not available')
        self.device_index = device_index
        self.channels = channels
        self.rate = rate
        self.frames_per_buffer = max(frames_per_buffer or 256, 64)
        self.level_sink = level_sink
        self.logger = logger
        self.frame_sink = frame_sink
        self.stream = None

    def _callback(self, in_data, frames, time_info, status) -> None:
        """Capture RMS level and optionally dispatch raw frames.

        This callback is invoked by ``sounddevice`` for every block of
        audio captured. The ``in_data`` argument is a numpy array with
        shape ``(frames, channels)`` and dtype ``int16``. We compute the
        RMS of the first channel for VU metering, push it into
        ``level_sink`` if provided, and invoke ``frame_sink`` with a copy
        of the full array and current sample rate so that higher level
        components may perform feature extraction or direction
        estimation.
        """
        try:
            if in_data is None:
                return
            # Compute RMS of channel 0
            x = in_data[:, 0] if in_data.ndim > 1 else in_data
            rms = float(_np.sqrt(_np.mean((x.astype(_np.float32) / 32768.0) ** 2))) if x.size > 0 else 0.0
            if self.level_sink:
                self.level_sink.push(rms)
            if self.frame_sink:
                try:
                    # Pass a copy to avoid referencing the ring buffer
                    self.frame_sink(in_data.copy(), self.rate)
                except Exception:
                    pass
        except Exception:
            pass

    def start(self) -> None:
        """Start the sounddevice stream."""
        try:
            self.stream = sd.InputStream(
                device=self.device_index,
                channels=self.channels,
                samplerate=self.rate,
                dtype='int16',
                blocksize=self.frames_per_buffer,
                callback=self._callback,
                latency='low'
            )
            self.stream.start()
        except Exception as ex:
            raise AudioBackendError(str(ex)) from ex

    def stop(self) -> None:
        """Stop the sounddevice stream."""
        try:
            if self.stream:
                self.stream.stop()
                self.stream.close()
        except Exception:
            pass
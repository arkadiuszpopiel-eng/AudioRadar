"""
Event classification for AudioRadar.

This module defines simple heuristics to classify short audio segments
into categories such as footsteps, running and gunshots. The goal is
to provide a rough estimate of the type of sound based on its energy
and spectral content.

The classifier operates on raw audio frames captured from a stereo or
mono stream. It relies on the RMS level and the spectral centroid to
distinguish between events. These heuristics are not perfect but
provide a starting point for more sophisticated models.
"""

from typing import Optional, Tuple
import numpy as np

# Attempt to import the spectral feature extraction routines. When this
# module is imported as a top‑level script (e.g. during syntax checks),
# ``__package__`` may be ``None`` and relative imports (``from .features``)
# will fail. To make the module robust outside of a package context, we
# first try an absolute import and fall back to a relative import when
# running inside a package. The absolute import relies on the caller
# having inserted the source directory into ``sys.path`` (as done by
# tools/syntax_check.py).
try:
    from features import spectral_centroid, to_mono  # type: ignore
except Exception:
    # Fallback for package contexts
    from .features import spectral_centroid, to_mono  # type: ignore

def classify_event(samples: np.ndarray, samplerate: float, rms: float, base_threshold: float) -> Optional[str]:
    """Classify a short audio segment into an event category.

    Args:
        samples: Audio frame as a numpy array of shape (frames,) or
            (frames, channels). Multi‑channel frames are averaged to mono
            prior to feature extraction.
        samplerate: Sample rate in Hz.
        rms: Root mean square level of the frame (0.0–1.0).
        base_threshold: Baseline noise threshold. Events must exceed
            this threshold to be classified.

    Returns:
        One of ``'footstep'``, ``'running'``, ``'gunshot'`` or ``None`` if
        the frame is considered noise or unclassified.
    """
    # Require signal to exceed baseline
    if rms < base_threshold:
        return None
    # Compute spectral centroid in Hz
    centroid = spectral_centroid(samples, samplerate)
    # Gunshots are typically high energy and broadband (high centroid)
    if rms > base_threshold * 5.0 or (rms > base_threshold * 3.0 and centroid > 3000.0):
        return 'gunshot'
    # Running produces louder steps than walking
    if rms > base_threshold * 2.0:
        if centroid < 1200.0:
            return 'running'
    # Footsteps are moderate energy with low spectral centroid
    if centroid < 1500.0:
        return 'footstep'
    return None
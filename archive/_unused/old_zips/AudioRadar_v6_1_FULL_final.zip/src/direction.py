"""
Direction of arrival (DOA) estimation for AudioRadar.

This module provides simple functions for estimating the direction
from which a sound arrives based on stereo recordings. The
implementation uses cross‑correlation to approximate the time delay
between the left and right channels and converts that delay to an
angle in the horizontal plane.

These functions assume a two‑channel input where channel 0 and
channel 1 correspond to the left and right channels. The distance
between microphones (or virtual positions) is configurable but
defaults to 0.20 metres, representing roughly the spacing between
headphone earcups. The speed of sound is assumed to be 343 m/s.
"""

from typing import Optional
import numpy as np

SPEED_OF_SOUND = 343.0  # m/s at 20 °C

def estimate_angle(frame: np.ndarray, samplerate: float, mic_distance: float = 0.20) -> Optional[float]:
    """Estimate the horizontal arrival angle of a sound.

    Args:
        frame: Audio frame as a numpy array of shape (frames, 2).
            Only the first two channels are used. If fewer than two
            channels are present, the function returns ``None``.
        samplerate: Sampling rate in Hz.
        mic_distance: Distance between the two microphones in metres.

    Returns:
        Angle in degrees in the range [-90, 90], where negative values
        indicate the sound comes from the left and positive values from
        the right. Returns ``None`` if the frame has insufficient
        channels or is empty.
    """
    if frame.ndim != 2 or frame.shape[1] < 2:
        return None
    # Extract left and right channels and convert to float
    left = frame[:, 0].astype(np.float32)
    right = frame[:, 1].astype(np.float32)
    if left.size == 0:
        return None
    # Normalise to avoid clipping
    left = left / 32768.0
    right = right / 32768.0
    # Cross‑correlate using FFT convolution to find time lag
    n = left.size + right.size - 1
    # Next power of two for efficient FFT
    nfft = 1 << (n - 1).bit_length()
    LEFT = np.fft.rfft(left, nfft)
    RIGHT = np.fft.rfft(right, nfft)
    # GCC‑PHAT
    denom = np.abs(LEFT * np.conj(RIGHT))
    denom[denom < 1e-15] = 1e-15
    cc = np.fft.irfft((LEFT * np.conj(RIGHT)) / denom, nfft)
    # Find the lag with maximum correlation
    max_idx = np.argmax(np.abs(cc))
    # Convert index to lag in samples (wrap around negative lags)
    if max_idx > nfft // 2:
        lag = max_idx - nfft
    else:
        lag = max_idx
    tau = lag / float(samplerate)
    # Convert time delay to angle. Clamp asin argument to [-1,1] to avoid NaN.
    try:
        val = tau * SPEED_OF_SOUND / mic_distance
        val = max(-1.0, min(1.0, val))
        angle = np.degrees(np.arcsin(val))
        return float(angle)
    except Exception:
        return None
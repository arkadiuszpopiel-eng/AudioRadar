"""
Feature extraction utilities for AudioRadar.

This module contains functions for computing simple spectral features
from raw audio samples. These features can be used to classify events
such as footsteps, running or gunshots.

All functions accept numpy arrays and return scalar values. If stereo
audio is provided the channels are averaged to mono before analysis.
"""

from typing import Union
import numpy as np

def to_mono(samples: np.ndarray) -> np.ndarray:
    """Convert a multi‑channel audio array to mono by averaging channels.

    Args:
        samples: A numpy array of shape (frames,) or (frames, channels).

    Returns:
        Mono audio as a 1D numpy array.
    """
    if samples.ndim == 1:
        return samples.astype(np.float32)
    # Average channels
    return samples.astype(np.float32).mean(axis=1)


def spectral_centroid(samples: np.ndarray, samplerate: float) -> float:
    """Compute the spectral centroid of a signal.

    The spectral centroid is the centre of mass of the magnitude
    spectrum and provides an indication of where the "centre of
    gravity" of the spectrum is located. Higher centroids correspond
    to signals with more high‑frequency content.

    Args:
        samples: Audio samples, mono or multi‑channel (array shape
            (frames,) or (frames, channels)). If multi‑channel, samples
            are averaged to mono.
        samplerate: Sampling rate in Hz.

    Returns:
        Spectral centroid in Hz. Returns 0.0 if the input is silent.
    """
    x = to_mono(samples)
    if x.size == 0:
        return 0.0
    # Compute magnitude spectrum
    mag = np.abs(np.fft.rfft(x))
    if not np.any(mag):
        return 0.0
    freqs = np.fft.rfftfreq(x.size, 1.0 / float(samplerate))
    return float((freqs * mag).sum() / mag.sum())


def zero_crossing_rate(samples: np.ndarray) -> float:
    """Compute the zero‑crossing rate of a signal.

    The zero‑crossing rate is the rate at which the signal changes sign.
    It can be used as a rough measure of frequency content.

    Args:
        samples: Audio samples, mono or multi‑channel. If multi‑channel,
            samples are averaged to mono.

    Returns:
        Zero crossing rate in crossings per sample. Multiply by
        sampling rate to obtain crossings per second.
    """
    x = to_mono(samples)
    if x.size < 2:
        return 0.0
    # Count zero crossings: sign change between consecutive samples
    return float(((x[:-1] * x[1:]) < 0).sum() / (x.size - 1))
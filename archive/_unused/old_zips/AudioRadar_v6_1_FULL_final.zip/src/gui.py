"""
Main GUI implementation for the AudioRadar application.

This module builds a tabbed interface consisting of a Control tab
and a Radar tab. The Control tab allows users to select the audio
device, sample rate, I/O mode, and buffer size. It includes a VU meter,
a live RMS readout, a Test Tone generator, and buttons to start/stop
capturing audio. The Radar tab hosts a RadarWidget with a sensitivity
slider.

Audio capture is managed via the audio_backends module. The GUI
periodically polls a LevelBuffer and updates the VU meter, RMS label
and RadarWidget accordingly. When PyAudio fails, a fallback using
sounddevice is attempted.
"""
from PyQt5 import QtWidgets, QtCore
import numpy as _np
from typing import Optional

# Insert this source directory into sys.path to make sibling modules
# discoverable when this module is imported outside of a package
# context. Without this, imports such as ``import classifier`` may
# fail during syntax checking.
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(__file__))

from logging_setup import init_logging
from classifier import classify_event
from direction import estimate_angle
from audio_backends import (
    list_devices_pyaudio,
    list_devices_sounddevice,
    prefer_device_index,
    CANDIDATE_RATES,
    LevelBuffer,
    PyAudioInput,
    SoundDeviceInput,
    normalize_channels,
)
from radar_widget import RadarWidget


BUFFER_OPTIONS = [128, 256, 512, 1024]


class MainWindow(QtWidgets.QMainWindow):
    """Main application window."""

    def __init__(self) -> None:
        super().__init__()
        # Set up logging and status bar
        self.logger, self.log_dir = init_logging()
        self.status = self.statusBar()
        # Window settings
        self.setWindowTitle('AudioRadar v6.1 (Classification & DOA)')
        self.resize(1024, 640)
        # Tabs
        tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(tabs)
        # Control tab
        ctrl_widget = QtWidgets.QWidget()
        tabs.addTab(ctrl_widget, 'Control')
        ctrl_layout = QtWidgets.QFormLayout(ctrl_widget)
        # Device combo
        self.devices = list_devices_pyaudio()  # List of (index, name, info)
        self.cmb_device = QtWidgets.QComboBox()
        for idx, name, info in self.devices:
            ch = info.get('maxInputChannels', 0)
            sr = info.get('defaultSampleRate', 0)
            self.cmb_device.addItem(f'[{idx}] {name} (in={ch}, sr={int(sr)})', idx)
        pref_idx = prefer_device_index(self.devices)
        if pref_idx is not None:
            pref_row = next(
                (i for i, (ix, _, _) in enumerate(self.devices) if ix == pref_idx), 0
            )
            self.cmb_device.setCurrentIndex(pref_row)
        # Sample rate
        self.cmb_rate = QtWidgets.QComboBox()
        for r in CANDIDATE_RATES:
            self.cmb_rate.addItem(str(r), r)
        # Mode (callback/poll)
        self.cmb_mode = QtWidgets.QComboBox()
        self.cmb_mode.addItems(['callback', 'poll'])
        # Buffer size
        self.cmb_buffer = QtWidgets.QComboBox()
        for b in BUFFER_OPTIONS:
            self.cmb_buffer.addItem(str(b), b)
        self.cmb_buffer.setCurrentIndex(1)  # default 256
        # Buttons
        self.btn_start = QtWidgets.QPushButton('START')
        self.btn_stop = QtWidgets.QPushButton('STOP')
        self.btn_stop.setEnabled(False)
        self.btn_list = QtWidgets.QPushButton('List Devices')
        self.btn_test_tone = QtWidgets.QPushButton('TEST TONE (1 kHz, 3 s)')
        # VU meter and RMS label
        self.vu_meter = QtWidgets.QProgressBar()
        self.vu_meter.setRange(0, 100)
        self.lbl_rms = QtWidgets.QLabel('RMS: 0.000')
        # Text log
        self.txt_log = QtWidgets.QPlainTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setMaximumBlockCount(1000)
        # Layout assembly
        ctrl_layout.addRow('Urządzenie', self.cmb_device)
        ctrl_layout.addRow('Samplerate', self.cmb_rate)
        ctrl_layout.addRow('Tryb', self.cmb_mode)
        ctrl_layout.addRow('Buffer (frames)', self.cmb_buffer)
        ctrl_layout.addRow(self.btn_start, self.btn_stop)
        ctrl_layout.addRow('Poziom (VU)', self.vu_meter)
        ctrl_layout.addRow('Input Monitor', self.lbl_rms)
        ctrl_layout.addRow(self.btn_list, self.btn_test_tone)
        ctrl_layout.addRow('Log', self.txt_log)
        # Radar tab
        radar_widget = QtWidgets.QWidget()
        tabs.addTab(radar_widget, 'Radar')
        radar_layout = QtWidgets.QVBoxLayout(radar_widget)
        self.radar = RadarWidget()
        radar_layout.addWidget(self.radar, 1)
        # Sensitivity slider
        sens_layout = QtWidgets.QHBoxLayout()
        sens_layout.addWidget(QtWidgets.QLabel('Sensitivity'))
        self.sl_sensitivity = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_sensitivity.setRange(50, 400)
        self.sl_sensitivity.setValue(150)
        sens_layout.addWidget(self.sl_sensitivity)
        radar_layout.addLayout(sens_layout)
        # Timer for periodic updates
        self.level_buffer = LevelBuffer()
        self.backend: Optional[any] = None
        self.update_timer = QtCore.QTimer(self)
        self.update_timer.setInterval(20)
        self.update_timer.timeout.connect(self.on_timer)
        self.update_timer.start()
        # Baseline threshold for classification (adapted over time)
        self._base_threshold: float = 0.02
        # Flag to accumulate initial noise to set baseline
        self._init_counter: int = 0
        # Connectors for events
        self._pending_events: list = []
        # Signal connections
        self.btn_start.clicked.connect(self.on_start)
        self.btn_stop.clicked.connect(self.on_stop)
        self.btn_list.clicked.connect(self.on_list)
        self.btn_test_tone.clicked.connect(self.on_test_tone)
        self.sl_sensitivity.valueChanged.connect(self.on_sensitivity_changed)
        # Set initial sensitivity
        self.on_sensitivity_changed(self.sl_sensitivity.value())

    def log(self, message: str) -> None:
        """Append a message to the GUI log and propagate to logger."""
        self.txt_log.appendPlainText(message)
        self.logger.info(message)

    def banner(self, backend: str, channels: int, rate: int, buf: int) -> None:
        """Update the status bar with stream parameters."""
        self.status.showMessage(
            f'Backend: {backend} | Ch: {channels} | Rate: {rate} Hz | Buffer: {buf} frames'
        )

    def on_sensitivity_changed(self, value: int) -> None:
        self.radar.setSensitivity(value / 100.0)

    def on_list(self) -> None:
        self.log('--- PyAudio devices ---')
        for idx, name, info in list_devices_pyaudio():
            self.log(f'[{idx}] {name} | in={info.get("maxInputChannels")} sr={info.get("defaultSampleRate")}')
        self.log('--- sounddevice devices ---')
        for idx, name, info in list_devices_sounddevice():
            self.log(
                f'[{idx}] {name} | in={info.get("max_input_channels")} out={info.get("max_output_channels")}'
            )

    def on_test_tone(self) -> None:
        """Play a 1 kHz test tone for three seconds on the system default output."""
        sr = 48000
        dur = 3.0
        samples = int(sr * dur)
        t = _np.arange(samples)
        tone = (0.5 * _np.sin(2 * _np.pi * 1000.0 * t / sr)).astype('float32')
        try:
            import sounddevice as sd  # local import to avoid import if not installed
            sd.play(tone, sr, blocking=False)
            self.log('TEST TONE: 1 kHz test tone played for 3 seconds.')
        except Exception as ex:
            QtWidgets.QMessageBox.critical(self, 'Test Tone Error', str(ex))

    def on_start(self) -> None:
        """Start audio capture using the selected backend and parameters."""
        if self.backend is not None:
            return
        idx = self.cmb_device.currentData()
        rate = int(self.cmb_rate.currentData())
        mode = self.cmb_mode.currentText()
        buf = int(self.cmb_buffer.currentData())
        # Retrieve name and info to deduce channels
        name, info = '', {}
        for dev_idx, dev_name, dev_info in self.devices:
            if dev_idx == idx:
                name, info = dev_name, dev_info
                break
        channels = normalize_channels(name, int(info.get('maxInputChannels', 2) or 2))
        self.log(
            f'START requested: dev={idx} name={name} ch={channels} rate={rate} mode={mode} buf={buf}'
        )
        # Try PyAudio first
        try:
            self.backend = PyAudioInput(
                device_index=idx,
                channels=channels,
                rate=rate,
                frames_per_buffer=buf,
                level_sink=self.level_buffer,
                logger=self.logger,
                use_callback=(mode == 'callback'),
                frame_sink=self.on_audio_frame,
            )
            self.backend.start()
            self.btn_start.setEnabled(False)
            self.btn_stop.setEnabled(True)
            self.log('PyAudio backend started.')
            self.banner('PyAudio', channels, self.backend.rate, buf)
            return
        except Exception as ex:
            self.backend = None
            self.log(f'PyAudio failed: {ex}')
        # Fallback to sounddevice
        try:
            self.backend = SoundDeviceInput(
                device_index=None,
                channels=channels,
                rate=rate,
                frames_per_buffer=buf,
                level_sink=self.level_buffer,
                logger=self.logger,
                frame_sink=self.on_audio_frame,
            )
            self.backend.start()
            self.btn_start.setEnabled(False)
            self.btn_stop.setEnabled(True)
            self.log('Fallback sounddevice backend started.')
            self.banner('sounddevice', channels, rate, buf)
        except Exception as ex:
            self.backend = None
            QtWidgets.QMessageBox.critical(
                self,
                'Audio error',
                f'Nie udało się uruchomić wejścia audio.\nSzczegóły: {ex}',
            )
            self.log(f'Fallback sounddevice failed: {ex}')

    def on_stop(self) -> None:
        """Stop audio capture and reset UI state."""
        try:
            if self.backend is not None:
                self.backend.stop()
        finally:
            self.backend = None
            self.btn_start.setEnabled(True)
            self.btn_stop.setEnabled(False)
            self.vu_meter.setValue(0)
            self.lbl_rms.setText('RMS: 0.000')
            self.status.clearMessage()
            self.log('Stopped.')
            # Reset baseline and clear radar events
            self._base_threshold = 0.02
            self._init_counter = 0
            try:
                # Clear markers
                self.radar._markers.clear()
            except Exception:
                pass

    def on_timer(self) -> None:
        """Periodic update of UI elements."""
        # Fetch the most recent level
        val = self.level_buffer.pop_latest()
        if val is not None:
            # Update progress bar (0-100), overscale slight to show peaks
            self.vu_meter.setValue(max(0, min(100, int(val * 120))))
            # Update RMS label
            self.lbl_rms.setText(f'RMS: {val:.3f}')
            # Update radar
            self.radar.setLevel(val)

    def on_audio_frame(self, frame, rate) -> None:
        """Process a raw audio frame for event detection and direction.

        This method is invoked from the audio backend with each captured
        block of audio data. It performs adaptive thresholding to
        estimate the ambient noise level, classifies the frame based on
        its RMS and spectral content, estimates the direction of arrival
        using the first two channels and posts events to the radar
        display. Detected events are also logged in the GUI.

        Args:
            frame: Numpy array of shape (frames, channels) containing
                int16 samples.
            rate: Sampling rate in Hz.
        """
        # Compute RMS on mono mix
        try:
            import numpy as _np
            if frame is None or frame.size == 0:
                return
            # Mono mix
            mono = frame.astype(_np.float32).mean(axis=1) / 32768.0
            rms = float(_np.sqrt(_np.mean(mono ** 2))) if mono.size > 0 else 0.0
        except Exception:
            return
        # Update baseline threshold using a slow filter
        # During the first 50 frames, accumulate baseline estimate
        if self._init_counter < 50:
            self._init_counter += 1
            # Use a running average
            self._base_threshold = (self._base_threshold * (self._init_counter - 1) + rms) / self._init_counter
        else:
            # Adapt threshold slowly to track noise floor changes
            self._base_threshold = 0.99 * self._base_threshold + 0.01 * rms
        # Classify event
        try:
            event = classify_event(frame, rate, rms, self._base_threshold)
        except Exception:
            event = None
        # Estimate direction of arrival
        try:
            angle = estimate_angle(frame, rate)
        except Exception:
            angle = None
        # If an event is detected, dispatch it to the radar and log
        if event:
            level_norm = 0.0
            # Normalise level relative to baseline threshold
            if self._base_threshold > 0:
                level_norm = min(1.0, max(0.0, (rms / self._base_threshold) - 1.0))
            self.radar.add_event(angle if angle is not None else 0.0, level_norm, event)
            try:
                self.log(f'Event detected: {event} at {angle:.1f}° (level={rms:.3f}, threshold={self._base_threshold:.3f})')
            except Exception:
                self.log(f'Event detected: {event} at unknown angle')
import os
import sys
import logging
import logging.handlers
import time


def _base_dir() -> str:
    """Determine the base directory for logs depending on whether the
    application is running in a frozen (PyInstaller) context.
    In a frozen context, logs are stored next to the executable in a
    `logs` folder. Otherwise, when running from source, logs are placed
    under `portable/logs` relative to the repository root.
    Returns:
        str: Path to the base log directory.
    """
    if getattr(sys, 'frozen', False):
        # When frozen, place logs next to the executable
        return os.path.dirname(sys.executable)
    # Otherwise, assume the repo layout
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'portable'))


def init_logging():
    """Initialise application wide logging.

    Sets up both a rotating file handler and a console handler. The file
    handler writes to a timestamped log file within a `logs` directory.
    The console handler prints to stderr. Multiple calls to this function
    will reuse existing handlers rather than attach duplicates.
    Returns:
        Tuple[logging.Logger, str]: Configured logger and the base log directory.
    """
    base_dir = os.path.join(_base_dir(), 'logs')
    os.makedirs(base_dir, exist_ok=True)
    log_path = os.path.join(base_dir, f"session_{time.strftime('%Y%m%d_%H%M%S')}.log")
    logger = logging.getLogger('audioradar')
    logger.setLevel(logging.INFO)
    # Only attach handlers once
    if not any(isinstance(h, logging.handlers.RotatingFileHandler) for h in logger.handlers):
        file_handler = logging.handlers.RotatingFileHandler(
            log_path, maxBytes=2 * 1024 * 1024, backupCount=5, encoding='utf-8'
        )
        file_handler.setFormatter(
            logging.Formatter('%(asctime)s | %(levelname)-8s | %(name)s | %(message)s')
        )
        logger.addHandler(file_handler)
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(logging.Formatter('[%(levelname)s] %(message)s'))
        logger.addHandler(stream_handler)
    logger.info('Logger initialised. session_log=%s', log_path)
    return logger, base_dir
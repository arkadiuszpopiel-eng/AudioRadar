"""
Entry point for AudioRadar.

This script configures Qt to use software rendering on Windows when
appropriate, installs a global exception hook to capture and log
uncaught exceptions, and either runs a self-test or launches the
application's main window. The self-test simply creates a file in
the log directory to indicate success.
"""
import os
import sys
import traceback
from PyQt5 import QtWidgets, QtCore

# Ensure this source directory is on sys.path so that modules such as
# logging_setup and gui can be imported when running directly from
# ``src``. Without this, Python may raise ``ModuleNotFoundError`` for
# these imports when the application is executed outside of a package
# context (e.g. during development or syntax checking).
sys.path.insert(0, os.path.dirname(__file__))

from logging_setup import init_logging
from gui import MainWindow


def selftest(log_dir: str) -> bool:
    """Perform a simple self-test by writing a file into the log directory."""
    try:
        with open(os.path.join(log_dir, 'selftest.log'), 'w', encoding='utf-8') as f:
            f.write('SELFTEST_OK\n')
        return True
    except Exception:
        return False


def _global_excepthook(exc_type, exc_value, exc_traceback) -> None:
    """Global handler for uncaught exceptions.

    Logs the exception via our logger and pops up a dialog. This ensures
    that unexpected exceptions are visible to the user instead of
    causing a silent crash.
    """
    logger, _ = init_logging()
    logger.error(
        'UNCAUGHT: %s', ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    )
    try:
        QtWidgets.QMessageBox.critical(
            None, 'Nieoczekiwany błąd', f'{exc_value}'
        )
    except Exception:
        pass


def main() -> int:
    """Application entry point."""
    logger, log_dir = init_logging()
    # Install global exception hook
    sys.excepthook = _global_excepthook
    # Parse args for self-test
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--selftest', action='store_true', help='Run a self-test and exit')
    args = parser.parse_args()
    if args.selftest:
        return 0 if selftest(log_dir) else 1
    # Ensure software rendering is used (avoids OpenGL issues on some GPUs)
    os.environ.setdefault('QT_OPENGL', 'software')
    os.environ.setdefault('QT_QUICK_BACKEND', 'software')
    os.environ.setdefault('QT_ANGLE_PLATFORM', 'd3d11')
    try:
        QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseSoftwareOpenGL, on=True)
    except Exception:
        pass
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec_()


if __name__ == '__main__':
    sys.exit(main())
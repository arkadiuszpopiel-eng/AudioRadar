"""
Radar display widget for AudioRadar.

This widget renders a circular radar with a sweeping line. Detected
events are displayed as fading blips at their estimated angle of
arrival. Each blip's colour corresponds to the classified event
category (footsteps, running or gunshots) and its size and opacity
depend on the event level and a user adjustable sensitivity.
"""

from PyQt5 import QtWidgets, QtGui, QtCore
import math
import time
from typing import List, Dict, Any


class RadarWidget(QtWidgets.QWidget):
    def __init__(self) -> None:
        super().__init__()
        # Sweeping line angle and background level for scanning indicator
        self._angle: float = 0.0
        self._level: float = 0.0
        self._sensitivity: float = 1.5
        self._decay: float = 0.85
        # List of event markers; each marker is a dict with keys:
        # 'angle': float, 'level': float, 'type': str, 'time': float
        self._markers: List[Dict[str, Any]] = []
        # Timer to schedule repaint and sweep
        self._timer: QtCore.QTimer = QtCore.QTimer(self)
        self._timer.setInterval(20)  # 50 FPS
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def setSensitivity(self, value: float) -> None:
        """Set the sensitivity multiplier for event marker intensity."""
        self._sensitivity = max(0.5, min(4.0, float(value)))

    def setLevel(self, value: float) -> None:
        """Update the sweeping line intensity based on background level."""
        if value is None:
            value = 0.0
        value = max(0.0, min(1.0, float(value)))
        target = math.sqrt(value * self._sensitivity)
        self._level = max(target, self._level * self._decay)
        if self._level < 0.005:
            self._level = 0.0

    def add_event(self, angle: float, level: float, ev_type: str) -> None:
        """Add an event marker to the radar.

        Args:
            angle: Estimated direction of arrival in degrees. Negative
                values indicate left; positive indicate right.
            level: Normalised signal level (0.0–1.0).
            ev_type: Event type string ('footstep', 'running', 'gunshot', etc.).
        """
        self._markers.append({
            'angle': float(angle) if angle is not None else 0.0,
            'level': max(0.0, min(1.0, float(level))),
            'type': ev_type or 'other',
            'time': time.time()
        })

    def _tick(self) -> None:
        """Advance the sweep and request a repaint."""
        self._angle = (self._angle + 3.6) % 360.0
        self.update()

    def sizeHint(self) -> QtCore.QSize:
        return QtCore.QSize(400, 400)

    def paintEvent(self, event) -> None:
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        # Geometry
        w = float(self.width())
        h = float(self.height())
        r = float(min(w, h) - 10)
        cx = w / 2.0
        cy = h / 2.0
        radius = r / 2.0
        # Background
        painter.fillRect(self.rect(), QtGui.QColor(10, 15, 20))
        # Grid circles and axes
        grid_pen = QtGui.QPen(QtGui.QColor(70, 90, 110))
        grid_pen.setWidth(1)
        painter.setPen(grid_pen)
        for k in range(1, 5):
            rr = radius * k / 4.0
            painter.drawEllipse(QtCore.QPointF(cx, cy), rr, rr)
        painter.drawLine(QtCore.QPointF(cx - radius, cy), QtCore.QPointF(cx + radius, cy))
        painter.drawLine(QtCore.QPointF(cx, cy - radius), QtCore.QPointF(cx, cy + radius))
        # Draw sweeping line
        beam_pen = QtGui.QPen(QtGui.QColor(120, 220, 255))
        beam_pen.setWidth(2)
        painter.setPen(beam_pen)
        x2 = cx + radius * math.cos(math.radians(self._angle))
        y2 = cy - radius * math.sin(math.radians(self._angle))
        painter.drawLine(QtCore.QPointF(cx, cy), QtCore.QPointF(x2, y2))
        # Draw event markers
        now = time.time()
        remove_indices = []
        for i, m in enumerate(self._markers):
            age = now - m['time']
            if age > 1.5:
                remove_indices.append(i)
                continue
            fade = max(0.0, min(1.0, 1.0 - age / 1.5))
            lvl = max(0.0, min(1.0, m['level'] * self._sensitivity))
            # Choose base colour based on type
            if m['type'] == 'gunshot':
                base = QtGui.QColor(255, 80, 80)  # red
            elif m['type'] == 'running':
                base = QtGui.QColor(255, 200, 80)  # orange/yellow
            elif m['type'] == 'footstep':
                base = QtGui.QColor(80, 255, 120)  # green
            else:
                base = QtGui.QColor(80, 180, 255)  # blue
            alpha = int(60 + 195 * lvl * fade)
            color = QtGui.QColor(base.red(), base.green(), base.blue(), alpha)
            painter.setBrush(color)
            painter.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 0)))
            # Position along 65% of radius
            ang_rad = math.radians(m['angle'])
            px = cx + (radius * 0.65) * math.cos(ang_rad)
            py = cy - (radius * 0.65) * math.sin(ang_rad)
            size = 6.0 + 30.0 * lvl
            painter.drawEllipse(QtCore.QPointF(px, py), size, size)
        # Remove old markers
        for idx in reversed(remove_indices):
            try:
                del self._markers[idx]
            except Exception:
                pass
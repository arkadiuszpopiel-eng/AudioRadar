"""
A simple syntax checker for the AudioRadar project.

This script recursively imports Python files under the specified directory
to ensure they do not contain syntax errors. It can be run as part of
a build process to fail early if there are problems.
"""
import importlib.util
import os
import sys


def check_syntax(path: str) -> None:
    """Import all Python files under `path` to check for syntax errors."""
    failures = []
    # Ensure the target path is on sys.path so that modules in the source
    # tree can be imported without relative import errors. Without this,
    # files that perform `import features` or `import logging_setup` would
    # fail to resolve when loaded in isolation via importlib. Prepending
    # the source directory makes those imports work during the syntax
    # checking phase. This modification does not persist outside of the
    # checker.
    if path not in sys.path:
        sys.path.insert(0, path)
    for root, _, files in os.walk(path):
        for f in files:
            if not f.endswith('.py'):
                continue
            fname = os.path.join(root, f)
            spec = importlib.util.spec_from_file_location('_chk_', fname)
            try:
                _mod = importlib.util.module_from_spec(spec)  # type: ignore
                assert spec.loader  # type: ignore
                spec.loader.exec_module(_mod)
            except Exception as ex:
                failures.append((fname, ex))
    if failures:
        for fname, ex in failures:
            print(f'[SYNTAX_ERROR] {fname}: {ex}')
        sys.exit(1)
    print('[OK] SYNTAX_OK')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python syntax_check.py <path>')
        sys.exit(1)
    check_syntax(sys.argv[1])
# AudioRadar v10.0 - Complete Package

## Quick Start

### Windows Users (Easiest Method)
1. Extract this ZIP to your desired location
2. Double-click `START_V10_GUI.bat`
3. The launcher will automatically install dependencies and start the GUI

### Alternative Methods

**Method 2: Command Line**
```bash
cd AudioRadar_v10.0_Package
python main.py
```

**Method 3: Direct Launcher**
```bash
python START_V10_GUI.py
```

## What's Included

- **main.py** - Main entry point (launches PyQt5 GUI)
- **gui.py** - PyQt5 GUI with dark theme
- **theme_manager.py** - Dark theme stylesheet
- **performance_monitor.py** - CPU/latency monitoring
- **audio_capture.py** - Audio device handling
- **sound_analysis.py** - Sound event detection
- **visualization.py** - Original Pygame visualization (reference)
- **START_V10_GUI.bat** - Windows launcher
- **START_V10_GUI.py** - Python launcher
- **RUN_BUILD_ALL.cmd** - Build script with PyInstaller support
- **README_PL.txt** - Polish documentation with troubleshooting
- **QUICK_START.txt** - Quick start guide
- **config.json** - Configuration file

## Requirements

- Python 3.8 or newer
- PyQt5
- sounddevice
- numpy
- psutil
- scipy (optional)

All dependencies will be installed automatically by START_V10_GUI.bat

## Features

✓ Modern dark theme (gray/black with cyan accents)
✓ Audio device selection
✓ Start/Stop monitoring controls
✓ Real-time CPU and latency display
✓ Keyboard shortcuts (SPACE = Start/Stop, F5 = Refresh)
✓ Polish language tooltips
✓ Status indicators (🔴 Disconnected / 🟢 Connected)

## Troubleshooting

See README_PL.txt for detailed troubleshooting in Polish, including:
- Black screen issues
- Missing dependencies
- Audio device configuration
- High CPU usage

## Build Executable

To create a standalone EXE:
```bash
RUN_BUILD_ALL.cmd build
```

The executable will be created in `dist\AudioRadar_v10_GUI.exe`

## Version

AudioRadar v10.0 - Optimized Core + Modern GUI
Created: November 2024
License: See original repository

---

For more information, see README_PL.txt and QUICK_START.txt
